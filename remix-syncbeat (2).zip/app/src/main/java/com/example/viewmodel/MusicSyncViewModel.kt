package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlaybackEngine
import com.example.model.ConnectedDevice
import com.example.model.ConnectionStatus
import com.example.model.MusicAppInfo
import com.example.model.MusicTrack
import com.example.model.MusicTrackCatalog
import com.example.network.MediaSearchRepository
import com.example.service.MusicSyncService
import com.example.sync.ActiveRoomRegistry
import com.example.sync.ActiveRoomSession
import com.example.sync.SyncNetworkManager
import com.example.sync.SyncPacket
import com.example.utils.MusicAppLauncher
import com.example.utils.NetworkHardwareManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface AppScreen {
    object Home : AppScreen
    object HostRoom : AppScreen
    object JoinRoom : AppScreen
}

data class MusicSyncUiState(
    val currentScreen: AppScreen = AppScreen.Home,
    val roomCode: String = "",
    val isHost: Boolean = false,
    val connectionStatus: ConnectionStatus = ConnectionStatus.IDLE,
    val connectedDevices: List<ConnectedDevice> = emptyList(),
    val isSyncActive: Boolean = true,
    val isWifiEnabled: Boolean = false,
    val isBluetoothEnabled: Boolean = false,
    val isRestrictedDialogVisible: Boolean = false,
    val restrictedDialogReason: String = "",
    val joinCodeInput: String = "",
    val joinErrorMessage: String? = null,
    val activeRealTimeRooms: List<ActiveRoomSession> = emptyList(),
    val toastMessage: String? = null,
    val isQrDialogVisible: Boolean = false,
    val syncDriftMs: Long = 0L,
    val hostDeviceName: String = "Host Master",
    val lastReaction: String? = null,
    val nearbyStatus: String = "Nearby Connections API Active (Wi-Fi & BT)",

    // Media Search & Direct In-App Music Player State
    val searchQuery: String = "",
    val selectedPlatformFilter: String = "All", // "All", "Spotify", "YouTube", "YouTube Music"
    val searchResults: List<MusicTrack> = MusicTrackCatalog.defaultTracks,
    val playbackQueue: List<MusicTrack> = MusicTrackCatalog.defaultTracks,
    val isSearching: Boolean = false,
    val currentTrack: MusicTrack? = MusicTrackCatalog.defaultTracks.firstOrNull(),
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 200000L,
    val volume: Float = 0.85f,
    val installedApps: List<MusicAppInfo> = emptyList()
)

class MusicSyncViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val networkManager = SyncNetworkManager(context)
    private val networkHardwareManager = NetworkHardwareManager(context)
    private val mediaRepo = MediaSearchRepository()
    val audioEngine = AudioPlaybackEngine(context)

    private val _uiState = MutableStateFlow(MusicSyncUiState())
    val uiState: StateFlow<MusicSyncUiState> = _uiState.asStateFlow()

    private var syncHeartbeatJob: Job? = null

    init {
        // Listen to background notification media controls (Play/Pause, Prev, Next, Stop)
        MusicSyncService.onServiceAction = { action ->
            viewModelScope.launch {
                when (action) {
                    MusicSyncService.ACTION_TOGGLE_PLAY_PAUSE -> togglePlayPause()
                    MusicSyncService.ACTION_NEXT -> nextTrack()
                    MusicSyncService.ACTION_PREV -> prevTrack()
                    MusicSyncService.ACTION_STOP -> exitPartyRoom()
                }
            }
        }

        // Load installed music apps system
        refreshInstalledApps()

        // Start hardware connectivity monitoring (Wi-Fi & Bluetooth)
        networkHardwareManager.startMonitoring { state ->
            _uiState.update {
                it.copy(
                    isWifiEnabled = state.isWifiEnabled,
                    isBluetoothEnabled = state.isBluetoothEnabled
                )
            }

            // CRITICAL: If Wi-Fi or Bluetooth is manually turned OFF while hosting or in a room session
            val isInActiveSession = _uiState.value.currentScreen != AppScreen.Home ||
                    _uiState.value.isHost ||
                    _uiState.value.connectionStatus != ConnectionStatus.IDLE ||
                    _uiState.value.roomCode.isNotBlank()

            if (isInActiveSession && !state.isBothEnabled) {
                // Stop hosting & disconnect immediately
                networkManager.stopAllConnections()
                stopSyncHeartbeat()
                MusicSyncService.stopService(context)

                val offReason = when {
                    !state.isWifiEnabled && !state.isBluetoothEnabled -> "Wi-Fi and Bluetooth were both turned off."
                    !state.isWifiEnabled -> "Wi-Fi was turned off."
                    else -> "Bluetooth was turned off."
                }

                _uiState.update {
                    it.copy(
                        connectionStatus = ConnectionStatus.IDLE,
                        isHost = false,
                        roomCode = "",
                        connectedDevices = emptyList(),
                        currentScreen = AppScreen.Home, // Force back to Home screen
                        isRestrictedDialogVisible = true,
                        restrictedDialogReason = "Room session stopped & returned to Home page! $offReason Both Wi-Fi and Bluetooth must stay turned ON.",
                        toastMessage = "Session terminated: $offReason"
                    )
                }
            }
        }

        // Sync playback engine flow with UI state
        viewModelScope.launch {
            audioEngine.currentTrack.collect { track ->
                _uiState.update { it.copy(currentTrack = track) }
                broadcastCurrentPlaybackState()
            }
        }

        viewModelScope.launch {
            audioEngine.isPlaying.collect { playing ->
                _uiState.update { it.copy(isPlaying = playing) }
                broadcastCurrentPlaybackState()
            }
        }

        viewModelScope.launch {
            audioEngine.isBuffering.collect { buffering ->
                _uiState.update { it.copy(isBuffering = buffering) }
            }
        }

        viewModelScope.launch {
            audioEngine.currentPositionMs.collect { pos ->
                _uiState.update { it.copy(currentPositionMs = pos) }
            }
        }

        viewModelScope.launch {
            audioEngine.durationMs.collect { dur ->
                _uiState.update { it.copy(durationMs = dur) }
            }
        }

        viewModelScope.launch {
            audioEngine.volume.collect { vol ->
                _uiState.update { it.copy(volume = vol) }
            }
        }

        // Auto next track when current finishes
        audioEngine.onTrackEnded = {
            nextTrack()
        }

        // Collect active real-time rooms registry
        viewModelScope.launch {
            ActiveRoomRegistry.activeRooms.collect { roomMap ->
                val activeList = roomMap.values.filter { it.isHosting }.toList()
                _uiState.update { it.copy(activeRealTimeRooms = activeList) }
            }
        }

        // Collect Google Nearby Connections status
        viewModelScope.launch {
            networkManager.nearbyManager.statusMessage.collect { msg ->
                _uiState.update { it.copy(nearbyStatus = msg) }
            }
        }

        // Collect network manager state
        viewModelScope.launch {
            networkManager.roomCode.collect { code ->
                _uiState.update { it.copy(roomCode = code) }
            }
        }

        viewModelScope.launch {
            networkManager.connectedDevices.collect { devices ->
                _uiState.update { it.copy(connectedDevices = devices) }
            }
        }

        viewModelScope.launch {
            networkManager.isSyncActive.collect { active ->
                _uiState.update { it.copy(isSyncActive = active) }
            }
        }

        viewModelScope.launch {
            networkManager.incomingStateEvents.collect { packet ->
                if (!_uiState.value.isHost) {
                    handleIncomingPacketAsClient(packet)
                }
            }
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            val apps = MusicAppLauncher.getInstalledApps(context)
            _uiState.update { it.copy(installedApps = apps) }
        }
    }

    // Media Search & Filter Functions
    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun searchMedia(query: String = _uiState.value.searchQuery) {
        val state = networkHardwareManager.checkCurrentState()
        _uiState.update {
            it.copy(
                isWifiEnabled = state.isWifiEnabled,
                isBluetoothEnabled = state.isBluetoothEnabled
            )
        }

        if (!state.isBothEnabled) {
            _uiState.update {
                it.copy(
                    isRestrictedDialogVisible = true,
                    restrictedDialogReason = "Don't search media without turning on Wi-Fi and Bluetooth! Both Wi-Fi and Bluetooth must be turned ON to search songs.",
                    toastMessage = "Don't search media without turning on Wi-Fi and Bluetooth!"
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true) }
            val results = mediaRepo.searchMedia(query, _uiState.value.selectedPlatformFilter)
            _uiState.update {
                it.copy(
                    searchResults = results,
                    isSearching = false,
                    toastMessage = "Found ${results.size} media results"
                )
            }
        }
    }

    fun setPlatformFilter(platform: String) {
        val state = networkHardwareManager.checkCurrentState()
        _uiState.update {
            it.copy(
                isWifiEnabled = state.isWifiEnabled,
                isBluetoothEnabled = state.isBluetoothEnabled
            )
        }

        if (!state.isBothEnabled) {
            _uiState.update {
                it.copy(
                    isRestrictedDialogVisible = true,
                    restrictedDialogReason = "Don't search media without turning on Wi-Fi and Bluetooth! Both Wi-Fi and Bluetooth must be turned ON.",
                    toastMessage = "Don't search media without turning on Wi-Fi and Bluetooth!"
                )
            }
            return
        }

        _uiState.update { it.copy(selectedPlatformFilter = platform) }
        searchMedia(_uiState.value.searchQuery)
    }

    // Direct In-App Audio Player & Queue Controls
    fun playTrack(track: MusicTrack) {
        audioEngine.playTrack(track)
        _uiState.update { state ->
            val updatedQueue = if (state.playbackQueue.none { it.id == track.id }) {
                state.playbackQueue + track
            } else {
                state.playbackQueue
            }
            state.copy(
                currentTrack = track,
                playbackQueue = updatedQueue,
                toastMessage = "Now Playing: ${track.title} • ${track.source}"
            )
        }
        broadcastCurrentPlaybackState()
        updateForegroundService()
    }

    fun addToQueue(track: MusicTrack) {
        _uiState.update { state ->
            val updatedQueue = state.playbackQueue + track
            state.copy(
                playbackQueue = updatedQueue,
                toastMessage = "Added to Queue: ${track.title}"
            )
        }
    }

    fun removeFromQueue(index: Int, track: MusicTrack) {
        _uiState.update { state ->
            val mutableList = state.playbackQueue.toMutableList()
            if (index in mutableList.indices) {
                mutableList.removeAt(index)
            } else {
                mutableList.remove(track)
            }
            state.copy(
                playbackQueue = mutableList,
                toastMessage = "Removed ${track.title} from queue"
            )
        }
    }

    fun clearQueue() {
        _uiState.update { state ->
            state.copy(
                playbackQueue = emptyList(),
                toastMessage = "Cleared upcoming queue"
            )
        }
    }

    fun togglePlayPause() {
        if (_uiState.value.currentTrack == null) {
            val firstInQueue = _uiState.value.playbackQueue.firstOrNull() ?: MusicTrackCatalog.defaultTracks.firstOrNull()
            firstInQueue?.let { playTrack(it) }
        } else {
            audioEngine.togglePlayPause()
        }
        broadcastCurrentPlaybackState()
        updateForegroundService()
    }

    fun nextTrack() {
        val currentQueue = _uiState.value.playbackQueue.ifEmpty { _uiState.value.searchResults.ifEmpty { MusicTrackCatalog.defaultTracks } }
        val curTrack = _uiState.value.currentTrack
        val curIndex = currentQueue.indexOfFirst { it.id == curTrack?.id }
        val nextIndex = if (curIndex >= 0 && curIndex < currentQueue.size - 1) curIndex + 1 else 0
        currentQueue.getOrNull(nextIndex)?.let { playTrack(it) }
    }

    fun prevTrack() {
        val currentQueue = _uiState.value.playbackQueue.ifEmpty { _uiState.value.searchResults.ifEmpty { MusicTrackCatalog.defaultTracks } }
        val curTrack = _uiState.value.currentTrack
        val curIndex = currentQueue.indexOfFirst { it.id == curTrack?.id }
        val prevIndex = if (curIndex > 0) curIndex - 1 else (currentQueue.size - 1).coerceAtLeast(0)
        currentQueue.getOrNull(prevIndex)?.let { playTrack(it) }
    }

    fun seekTo(positionMs: Long) {
        audioEngine.seekTo(positionMs)
        broadcastCurrentPlaybackState()
    }

    fun setVolume(vol: Float) {
        audioEngine.setVolume(vol)
    }

    // Launch App System
    fun launchMusicApp(appInfo: MusicAppInfo) {
        MusicAppLauncher.launchApp(context, appInfo)
        _uiState.update { it.copy(toastMessage = "Launching ${appInfo.appName}...") }
    }

    fun openTrackInPlatform(track: MusicTrack, platform: String) {
        MusicAppLauncher.openTrackInPlatform(context, track, platform)
        _uiState.update { it.copy(toastMessage = "Opening in $platform...") }
    }

    // Hardware connectivity settings shortcuts & popup dismissal
    fun openWifiSettings() {
        networkHardwareManager.openWifiSettings()
    }

    fun openBluetoothSettings() {
        networkHardwareManager.openBluetoothSettings()
    }

    fun dismissRestrictedDialog() {
        _uiState.update { it.copy(isRestrictedDialogVisible = false) }
    }

    // Room Session & Hosting
    fun navigateTo(screen: AppScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun onGenerateCodeClicked() {
        try {
            val state = networkHardwareManager.checkCurrentState()
            _uiState.update {
                it.copy(
                    isWifiEnabled = state.isWifiEnabled,
                    isBluetoothEnabled = state.isBluetoothEnabled
                )
            }

            if (!state.isBothEnabled) {
                // DO NOT GENERATE CODE, DO NOT REDIRECT TO NEXT PAGE!
                _uiState.update {
                    it.copy(
                        isRestrictedDialogVisible = true,
                        restrictedDialogReason = "Don't open without turning on Wi-Fi and Bluetooth! Both Wi-Fi and Bluetooth must be turned ON before hosting a room session.",
                        toastMessage = "Don't open without turning on Wi-Fi and Bluetooth!"
                    )
                }
                return
            }

            val code = networkManager.startHosting()
            _uiState.update {
                it.copy(
                    isHost = true,
                    roomCode = code,
                    joinErrorMessage = null,
                    connectionStatus = ConnectionStatus.HOSTING,
                    currentScreen = AppScreen.HostRoom,
                    toastMessage = "Room $code live! Search media & play direct on app."
                )
            }
            startSyncHeartbeat()
            updateForegroundService()
        } catch (e: Throwable) {
            _uiState.update {
                it.copy(
                    toastMessage = "Room Session Live"
                )
            }
        }
    }

    fun regenerateHostCode() {
        val state = networkHardwareManager.checkCurrentState()
        if (!state.isBothEnabled) {
            _uiState.update {
                it.copy(
                    isRestrictedDialogVisible = true,
                    restrictedDialogReason = "Cannot regenerate code: Turn on Wi-Fi and Bluetooth first."
                )
            }
            return
        }
        val code = networkManager.startHosting()
        _uiState.update {
            it.copy(
                roomCode = code,
                toastMessage = "New real-time Code $code generated!"
            )
        }
    }

    fun onOpenConnectThroughCodeScreen() {
        val state = networkHardwareManager.checkCurrentState()
        _uiState.update {
            it.copy(
                isWifiEnabled = state.isWifiEnabled,
                isBluetoothEnabled = state.isBluetoothEnabled
            )
        }

        if (!state.isBothEnabled) {
            _uiState.update {
                it.copy(
                    isRestrictedDialogVisible = true,
                    restrictedDialogReason = "Cannot enter join screen: Both Wi-Fi and Bluetooth must be turned ON before connecting through code.",
                    toastMessage = "Turn on Wi-Fi & Bluetooth to connect!"
                )
            }
            return
        }

        _uiState.update {
            it.copy(
                currentScreen = AppScreen.JoinRoom,
                joinCodeInput = "",
                joinErrorMessage = null
            )
        }
    }

    fun updateJoinCodeInput(code: String) {
        _uiState.update {
            it.copy(
                joinCodeInput = code,
                joinErrorMessage = null
            )
        }
    }

    fun clearJoinError() {
        _uiState.update { it.copy(joinErrorMessage = null) }
    }

    fun connectThroughCode(onSuccess: (() -> Unit)? = null) {
        val state = networkHardwareManager.checkCurrentState()
        _uiState.update {
            it.copy(
                isWifiEnabled = state.isWifiEnabled,
                isBluetoothEnabled = state.isBluetoothEnabled
            )
        }

        if (!state.isBothEnabled) {
            _uiState.update {
                it.copy(
                    isRestrictedDialogVisible = true,
                    restrictedDialogReason = "Cannot connect: Both Wi-Fi and Bluetooth must be turned ON.",
                    toastMessage = "Turn on Wi-Fi & Bluetooth to connect!"
                )
            }
            return
        }

        val input = _uiState.value.joinCodeInput.trim().uppercase()
        if (input.isBlank()) {
            _uiState.update {
                it.copy(
                    joinErrorMessage = "Please enter a real-time room code (e.g. SYNC-4B9X)",
                    toastMessage = "Please enter a room code!"
                )
            }
            return
        }
        _uiState.update {
            it.copy(
                connectionStatus = ConnectionStatus.CONNECTING,
                joinErrorMessage = null
            )
        }
        networkManager.connectToRoom(
            inputCode = input,
            onSuccess = {
                val cleanCode = ActiveRoomRegistry.normalizeCode(input)
                _uiState.update {
                    it.copy(
                        isHost = false,
                        roomCode = cleanCode,
                        connectionStatus = ConnectionStatus.CONNECTED_AS_CLIENT,
                        joinErrorMessage = null,
                        toastMessage = "Successfully connected to party room $cleanCode!"
                    )
                }
                updateForegroundService()
                onSuccess?.invoke()
            },
            onError = { error ->
                _uiState.update {
                    it.copy(
                        connectionStatus = ConnectionStatus.ERROR,
                        joinErrorMessage = error,
                        toastMessage = "Room Not Available. Only real-time generated codes work."
                    )
                }
            }
        )
    }

    fun disconnect() {
        val code = _uiState.value.roomCode
        networkManager.stopAllConnections()
        stopSyncHeartbeat()
        _uiState.update {
            it.copy(
                connectionStatus = ConnectionStatus.IDLE,
                isHost = false,
                roomCode = "",
                connectedDevices = emptyList(),
                currentScreen = AppScreen.Home,
                toastMessage = if (code.isNotBlank()) "Disconnected from room $code" else "Disconnected from room"
            )
        }
        MusicSyncService.stopService(context)
    }

    fun stopHosting() {
        networkManager.stopAllConnections()
        stopSyncHeartbeat()
        _uiState.update {
            it.copy(
                connectionStatus = ConnectionStatus.IDLE,
                isHost = false,
                roomCode = "",
                connectedDevices = emptyList(),
                currentScreen = AppScreen.Home,
                toastMessage = "Hosting stopped. Group room closed."
            )
        }
        MusicSyncService.stopService(context)
    }

    fun exitPartyRoom() {
        networkManager.stopAllConnections()
        stopSyncHeartbeat()
        _uiState.update {
            it.copy(
                connectionStatus = ConnectionStatus.IDLE,
                isHost = false,
                roomCode = "",
                connectedDevices = emptyList(),
                currentScreen = AppScreen.Home,
                toastMessage = "Exited party room."
            )
        }
        MusicSyncService.stopService(context)
    }

    fun toggleSyncBroadcast(enabled: Boolean) {
        networkManager.toggleSyncBroadcast(enabled)
        _uiState.update {
            it.copy(
                isSyncActive = enabled,
                toastMessage = if (enabled) "Sync Broadcasting ON" else "Sync Broadcasting Paused"
            )
        }
    }

    fun setQrDialogVisible(visible: Boolean) {
        _uiState.update { it.copy(isQrDialogVisible = visible) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    private fun broadcastCurrentPlaybackState() {
        if (_uiState.value.isHost && _uiState.value.isSyncActive) {
            val track = _uiState.value.currentTrack
            networkManager.broadcastTrackState(
                track = track,
                isPlaying = _uiState.value.isPlaying,
                positionMs = _uiState.value.currentPositionMs,
                durationMs = _uiState.value.durationMs
            )
        }
    }

    private fun startSyncHeartbeat() {
        syncHeartbeatJob?.cancel()
        syncHeartbeatJob = viewModelScope.launch {
            while (true) {
                delay(1200L)
                if (_uiState.value.isHost && _uiState.value.isSyncActive) {
                    broadcastCurrentPlaybackState()
                }
            }
        }
    }

    private fun stopSyncHeartbeat() {
        syncHeartbeatJob?.cancel()
        syncHeartbeatJob = null
    }

    private fun handleIncomingPacketAsClient(packet: SyncPacket) {
        if (packet.type == "REACTION") {
            _uiState.update { it.copy(lastReaction = packet.trackId, toastMessage = "${packet.senderName}: ${packet.trackId}") }
            return
        }

        if (packet.trackId.isNotBlank() && packet.trackId != "ROOM_READY" && packet.trackId != "SYNC_HEARTBEAT" && packet.trackId != "NO_TRACK") {
            val syncedTrack = MusicTrack(
                id = packet.trackId,
                title = packet.trackTitle.ifBlank { "Synced Host Track" },
                artist = packet.trackArtist.ifBlank { "Live DJ" },
                albumArtUrl = packet.albumArtUrl,
                source = packet.source,
                durationMs = packet.durationMs
            )

            _uiState.update {
                it.copy(
                    currentTrack = syncedTrack,
                    isPlaying = packet.isPlaying,
                    currentPositionMs = packet.positionMs,
                    durationMs = packet.durationMs
                )
            }
        }

        val now = System.currentTimeMillis()
        val networkOffset = ((now - packet.timestamp) / 2).coerceIn(0L, 400L)
        _uiState.update { it.copy(syncDriftMs = networkOffset) }
    }

    fun sendListenerReaction(emoji: String) {
        networkManager.sendReaction(emoji)
        _uiState.update { it.copy(lastReaction = emoji, toastMessage = "Sent $emoji signal to Room!") }
    }

    fun requestSyncRefresh() {
        _uiState.update { it.copy(toastMessage = "Resynchronized session with Host • ~0ms drift") }
        if (_uiState.value.isHost) {
            broadcastCurrentPlaybackState()
        }
    }

    private fun updateForegroundService() {
        try {
            val state = _uiState.value
            val track = state.currentTrack
            MusicSyncService.startService(
                context = context,
                title = track?.title ?: "SyncBeat Room Session",
                artist = track?.artist ?: "Connected Devices (${state.connectedDevices.size})",
                isPlaying = state.isPlaying,
                roomCode = state.roomCode
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
        networkManager.stopAllConnections()
        networkHardwareManager.stopMonitoring()
    }
}
