package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class MusicSyncService : Service() {

    companion object {
        const val CHANNEL_ID = "syncbeat_room_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_STOP = "com.example.syncbeat.ACTION_STOP"
        const val ACTION_TOGGLE_PLAY_PAUSE = "com.example.syncbeat.ACTION_TOGGLE_PLAY_PAUSE"
        const val ACTION_NEXT = "com.example.syncbeat.ACTION_NEXT"
        const val ACTION_PREV = "com.example.syncbeat.ACTION_PREV"

        const val EXTRA_TRACK_TITLE = "extra_track_title"
        const val EXTRA_TRACK_ARTIST = "extra_track_artist"
        const val EXTRA_IS_PLAYING = "extra_is_playing"
        const val EXTRA_ROOM_CODE = "extra_room_code"

        var onServiceAction: ((String) -> Unit)? = null

        fun startService(
            context: Context,
            title: String,
            artist: String,
            isPlaying: Boolean,
            roomCode: String
        ) {
            try {
                val intent = Intent(context, MusicSyncService::class.java).apply {
                    putExtra(EXTRA_TRACK_TITLE, title)
                    putExtra(EXTRA_TRACK_ARTIST, artist)
                    putExtra(EXTRA_IS_PLAYING, isPlaying)
                    putExtra(EXTRA_ROOM_CODE, roomCode)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun stopService(context: Context) {
            try {
                val intent = Intent(context, MusicSyncService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private val binder = LocalBinder()
    private var currentTitle = "SyncBeat Room"
    private var currentArtist = "Multi-Device Connection Active"
    private var isPlaying = false
    private var roomCode = ""

    inner class LocalBinder : Binder() {
        fun getService(): MusicSyncService = this@MusicSyncService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when (action) {
            ACTION_STOP -> {
                onServiceAction?.invoke(ACTION_STOP)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_PLAY_PAUSE -> {
                onServiceAction?.invoke(ACTION_TOGGLE_PLAY_PAUSE)
            }
            ACTION_NEXT -> {
                onServiceAction?.invoke(ACTION_NEXT)
            }
            ACTION_PREV -> {
                onServiceAction?.invoke(ACTION_PREV)
            }
            else -> {
                currentTitle = intent?.getStringExtra(EXTRA_TRACK_TITLE) ?: currentTitle
                currentArtist = intent?.getStringExtra(EXTRA_TRACK_ARTIST) ?: currentArtist
                isPlaying = intent?.getBooleanExtra(EXTRA_IS_PLAYING, isPlaying) ?: isPlaying
                roomCode = intent?.getStringExtra(EXTRA_ROOM_CODE) ?: roomCode
            }
        }

        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SyncBeat Background Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background room session, audio playback & network synchronization"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Previous Action
        val prevIntent = Intent(this, MusicSyncService::class.java).apply { action = ACTION_PREV }
        val prevPendingIntent = PendingIntent.getService(
            this, 1, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Play/Pause Action
        val playPauseIntent = Intent(this, MusicSyncService::class.java).apply { action = ACTION_TOGGLE_PLAY_PAUSE }
        val playPausePendingIntent = PendingIntent.getService(
            this, 2, playPauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Next Action
        val nextIntent = Intent(this, MusicSyncService::class.java).apply { action = ACTION_NEXT }
        val nextPendingIntent = PendingIntent.getService(
            this, 3, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Stop Action
        val stopIntent = Intent(this, MusicSyncService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 4, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val roomInfo = if (roomCode.isNotBlank()) " • Room $roomCode" else ""
        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseTitle = if (isPlaying) "Pause" else "Play"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(currentTitle)
            .setContentText("$currentArtist$roomInfo")
            .setSubText("SyncBeat Live Room")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(android.R.drawable.ic_media_previous, "Prev", prevPendingIntent)
            .addAction(playPauseIcon, playPauseTitle, playPausePendingIntent)
            .addAction(android.R.drawable.ic_media_next, "Next", nextPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .build()
    }
}
