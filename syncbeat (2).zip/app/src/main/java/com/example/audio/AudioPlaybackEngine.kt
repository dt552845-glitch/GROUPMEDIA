package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.MusicTrack
import com.example.model.WaveformType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

class AudioPlaybackEngine {

    companion object {
        const val SAMPLE_RATE = 44100
        const val CHANNELS = 1
        const val BUFFER_SIZE = 4096
    }

    private var audioTrack: AudioTrack? = null
    private var synthJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _visualizerLevels = MutableStateFlow(FloatArray(16) { 0.1f })
    val visualizerLevels: StateFlow<FloatArray> = _visualizerLevels.asStateFlow()

    private var currentTrack: MusicTrack? = null
    private var volume = 0.85f
    private var isMuted = false
    private var onSongCompleted: (() -> Unit)? = null

    fun setOnSongCompletedListener(listener: () -> Unit) {
        onSongCompleted = listener
    }

    fun setVolume(vol: Float) {
        volume = vol.coerceIn(0f, 1f)
    }

    fun setMuted(muted: Boolean) {
        isMuted = muted
    }

    fun playTrack(track: MusicTrack, startPositionMs: Long = 0L) {
        currentTrack = track
        _currentPositionMs.value = startPositionMs
        startSynthesis()
    }

    fun pause() {
        _isPlaying.value = false
        synthJob?.cancel()
        audioTrack?.pause()
        audioTrack?.flush()
        _visualizerLevels.value = FloatArray(16) { 0.05f }
    }

    fun resume() {
        if (currentTrack != null && !_isPlaying.value) {
            startSynthesis()
        }
    }

    fun seekTo(positionMs: Long) {
        val track = currentTrack ?: return
        val clampedPos = positionMs.coerceIn(0L, track.durationMs)
        _currentPositionMs.value = clampedPos
    }

    fun stop() {
        _isPlaying.value = false
        synthJob?.cancel()
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null
        _visualizerLevels.value = FloatArray(16) { 0f }
    }

    private fun initAudioTrack() {
        if (audioTrack == null) {
            val minBufSize = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(minBufSize, BUFFER_SIZE * 2)
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            audioTrack?.play()
        }
    }

    private fun midiToFreq(midiNote: Int): Double {
        return 440.0 * 2.0.pow((midiNote - 69).toDouble() / 12.0)
    }

    private fun startSynthesis() {
        synthJob?.cancel()
        _isPlaying.value = true
        try {
            initAudioTrack()
            audioTrack?.play()
        } catch (_: Exception) {}

        val track = currentTrack ?: return

        synthJob = scope.launch {
            val buffer = ShortArray(BUFFER_SIZE)
            var sampleIndex = (_currentPositionMs.value * SAMPLE_RATE / 1000).toDouble()
            val totalSamples = (track.durationMs * SAMPLE_RATE / 1000).toDouble()
            val bpm = track.bpm.toDouble()
            val samplesPerBeat = (60.0 / bpm) * SAMPLE_RATE
            val melodyLength = track.melodyNotes.size
            val bassLength = track.bassNotes.size
            val barLevels = FloatArray(16)

            while (isActive && _isPlaying.value) {
                if (sampleIndex >= totalSamples) {
                    _currentPositionMs.value = 0L
                    sampleIndex = 0.0
                    onSongCompleted?.invoke()
                    break
                }

                val effectiveVol = if (isMuted) 0f else volume

                for (i in 0 until BUFFER_SIZE) {
                    val currentSample = sampleIndex + i
                    val beatTime = (currentSample % (samplesPerBeat * 4)) / samplesPerBeat
                    val beatIndex = (currentSample / (samplesPerBeat / 4)).toInt()

                    // Melody note calculation
                    val melodyIdx = (beatIndex / 2) % melodyLength
                    val melodyNote = track.melodyNotes[melodyIdx]
                    val melodyFreq = midiToFreq(melodyNote)
                    val noteFraction = ((currentSample % (samplesPerBeat / 2)) / (samplesPerBeat / 2)).toFloat()
                    val melodyEnv = (1f - noteFraction).coerceIn(0f, 1f).pow(0.7f)

                    // Melody wave
                    val melodyPhase = (currentSample * melodyFreq / SAMPLE_RATE) % 1.0
                    val melodyWave = when (track.waveformType) {
                        WaveformType.SINE -> sin(2.0 * PI * melodyPhase)
                        WaveformType.TRIANGLE -> 4.0 * kotlin.math.abs(melodyPhase - 0.5) - 1.0
                        WaveformType.SAWTOOTH -> 2.0 * melodyPhase - 1.0
                        WaveformType.SQUARE -> if (melodyPhase < 0.5) 0.8 else -0.8
                    }

                    // Bass note
                    val bassIdx = (beatIndex / 4) % bassLength
                    val bassNote = track.bassNotes[bassIdx]
                    val bassFreq = midiToFreq(bassNote)
                    val bassFraction = ((currentSample % samplesPerBeat) / samplesPerBeat).toFloat()
                    val bassEnv = (1f - bassFraction).coerceIn(0f, 1f).pow(0.5f)
                    val bassPhase = (currentSample * bassFreq / SAMPLE_RATE) % 1.0
                    val bassWave = sin(2.0 * PI * bassPhase) * 0.9 + (if (bassPhase < 0.5) 0.3 else -0.3)

                    // Percussion Kick & Hi-hat
                    val kickEnv = exp(-beatTime.rem(1.0) * 14.0)
                    val kickWave = sin(2.0 * PI * 55.0 * (1.0 + kickEnv * 3.0) * (beatTime.rem(1.0))) * kickEnv

                    // Snare / HiHat
                    val isSnareBeat = (beatTime >= 1.0 && beatTime < 1.3) || (beatTime >= 3.0 && beatTime < 3.3)
                    val snareNoise = if (isSnareBeat) (Math.random() * 2.0 - 1.0) * exp(-(beatTime % 2.0 - 1.0).coerceAtLeast(0.0) * 18.0) else 0.0

                    val mix = (melodyWave * melodyEnv * 0.38 + bassWave * bassEnv * 0.32 + kickWave * 0.28 + snareNoise * 0.16) * effectiveVol
                    val sampleValue = (mix.coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
                    buffer[i] = sampleValue
                }

                // Write to AudioTrack
                val written = try {
                    audioTrack?.write(buffer, 0, BUFFER_SIZE) ?: -1
                } catch (_: Exception) {
                    -1
                }
                sampleIndex += BUFFER_SIZE

                val currentMs = (sampleIndex * 1000 / SAMPLE_RATE).toLong()
                _currentPositionMs.value = currentMs

                // Generate visualizer bars
                val beatPulse = sin(sampleIndex * (bpm / 60.0) * 2.0 * PI / SAMPLE_RATE).toFloat().coerceAtLeast(0f)
                for (b in 0 until 16) {
                    val raw = (sin(sampleIndex * 0.005 + b * 0.6).toFloat() * 0.5f + 0.5f) * (0.4f + beatPulse * 0.6f) * effectiveVol
                    barLevels[b] = raw.coerceIn(0.08f, 1.0f)
                }
                _visualizerLevels.value = barLevels.copyOf()

                // Crucial fix: if written bytes is non-positive or audio track is not consuming at realtime rate,
                // delay for buffer duration to prevent 100% CPU thread starvation loop in container environment
                if (written <= 0) {
                    kotlinx.coroutines.delay(92L)
                }
            }
        }
    }
}
