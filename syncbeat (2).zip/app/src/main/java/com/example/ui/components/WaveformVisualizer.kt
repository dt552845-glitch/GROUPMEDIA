package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleLight

@Composable
fun WaveformVisualizer(
    levels: FloatArray,
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    barColor1: Color = MinimalPurple,
    barColor2: Color = MinimalPurpleLight,
    barColor3: Color = MinimalPurpleContainer
) {
    val barCount = levels.size.coerceAtLeast(8)
    val animatedPulse = remember { Animatable(0.5f) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            animatedPulse.animateTo(
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        } else {
            animatedPulse.snapTo(0.2f)
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val totalWidth = size.width
        val canvasHeight = size.height
        val barSpacing = 4.dp.toPx()
        val availableWidth = totalWidth - (barSpacing * (barCount - 1))
        val barWidth = (availableWidth / barCount).coerceAtLeast(2.dp.toPx())

        val brush = Brush.verticalGradient(
            colors = listOf(barColor2, barColor1, barColor3),
            startY = 0f,
            endY = canvasHeight
        )

        for (i in 0 until barCount) {
            val level = if (isPlaying) {
                val raw = if (i < levels.size) levels[i] else 0.2f
                (raw * animatedPulse.value).coerceIn(0.1f, 1f)
            } else {
                0.08f
            }

            val barH = (canvasHeight * level).coerceAtLeast(4.dp.toPx())
            val x = i * (barWidth + barSpacing)
            val y = (canvasHeight - barH) / 2f

            drawRoundRect(
                brush = brush,
                topLeft = Offset(x, y),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )
        }
    }
}
