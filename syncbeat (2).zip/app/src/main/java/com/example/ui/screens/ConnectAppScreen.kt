package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.InstalledAppInfo
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalOnPurpleContainer
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalPurpleLight
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalSurfaceVariant
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.ModdedBadgeColor
import com.example.ui.theme.StatusActive
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MusicSyncUiState
import com.example.viewmodel.MusicSyncViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectAppScreen(
    uiState: MusicSyncUiState,
    viewModel: MusicSyncViewModel,
    modifier: Modifier = Modifier
) {
    val categories = listOf("All", "Modded Apps", "Music & Audio", "All Installed")

    val filteredApps = uiState.detectedApps.filter { app ->
        val matchesQuery = uiState.appSearchQuery.isBlank() ||
                app.name.contains(uiState.appSearchQuery, ignoreCase = true) ||
                app.packageName.contains(uiState.appSearchQuery, ignoreCase = true) ||
                app.category.contains(uiState.appSearchQuery, ignoreCase = true)

        val matchesCategory = when (uiState.selectedAppCategory) {
            "All" -> true
            "Modded Apps" -> app.isModded
            "Music & Audio" -> app.isMusicOrVideoApp
            "All Installed" -> true
            else -> true
        }

        matchesQuery && matchesCategory
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBackground)
    ) {
        // Top App Bar
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "Connect Mobile App",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = "Detected ${uiState.detectedApps.size} apps on Android device",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextSecondary,
                        fontSize = 11.sp
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.Home) },
                    modifier = Modifier.testTag("connect_app_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MinimalTextPrimary
                    )
                }
            },
            actions = {
                IconButton(
                    onClick = { viewModel.scanDetectedApps() },
                    modifier = Modifier.testTag("refresh_detected_apps_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Re-scan Device Apps",
                        tint = MinimalPurple
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MinimalBackground)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Info Banner
            item {
                ConnectedAppHeroBanner(
                    connectedApp = uiState.connectedApp,
                    onGoToHostRoom = {
                        if (uiState.isHost) {
                            viewModel.navigateTo(AppScreen.HostRoom)
                        } else {
                            viewModel.onGenerateCodeClicked()
                        }
                    }
                )
            }

            // Search Bar for Detected Apps
            item {
                OutlinedTextField(
                    value = uiState.appSearchQuery,
                    onValueChange = { viewModel.updateAppSearchQuery(it) },
                    placeholder = {
                        Text(
                            text = "Search downloaded apps (e.g. YouTube, Spotify, ReVanced)...",
                            color = MinimalTextMuted,
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search Apps",
                            tint = MinimalPurple,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    trailingIcon = {
                        if (uiState.appSearchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateAppSearchQuery("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = MinimalTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MinimalSurface,
                        unfocusedContainerColor = MinimalSurface,
                        focusedBorderColor = MinimalPurple,
                        unfocusedBorderColor = MinimalBorder,
                        focusedTextColor = MinimalTextPrimary,
                        unfocusedTextColor = MinimalTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("app_search_field")
                )
            }

            // Category Filters Row
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(categories) { category ->
                        val isSelected = uiState.selectedAppCategory == category
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setSelectedAppCategory(category) },
                            label = { Text(category, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MinimalPurpleContainer,
                                selectedLabelColor = MinimalOnPurpleContainer,
                                containerColor = MinimalSurface,
                                labelColor = MinimalTextSecondary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = MinimalBorder,
                                selectedBorderColor = MinimalPurple
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }

            // Section Title
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DETECTED APPS ON MOBILE (${filteredApps.size})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalPurpleDark,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Tap to Connect",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextSecondary
                    )
                }
            }

            // List of detected mobile apps
            items(filteredApps, key = { it.packageName }) { app ->
                val isConnected = uiState.connectedApp?.packageName == app.packageName
                DetectedAppCardItem(
                    app = app,
                    isConnected = isConnected,
                    onConnect = { viewModel.connectToApp(app) }
                )
            }

            // Bottom CTA: Go to Host Room
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (uiState.isHost) {
                            viewModel.navigateTo(AppScreen.HostRoom)
                        } else {
                            viewModel.onGenerateCodeClicked()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("go_to_host_room_from_connect_app_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Search Songs in Host Room via ${uiState.connectedApp?.name ?: "Connected App"}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Go",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ConnectedAppHeroBanner(
    connectedApp: InstalledAppInfo?,
    onGoToHostRoom: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalPurpleContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("connected_app_hero_banner")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(StatusActive)
                    )
                    Text(
                        text = "ACTIVE CONNECTED APP",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusActive,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                if (connectedApp?.isModded == true) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(ModdedBadgeColor)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "MODDED ACTIVE",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (connectedApp != null) Color(connectedApp.brandColor) else MinimalPurple
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                connectedApp?.name?.contains("YouTube", ignoreCase = true) == true -> Icons.Default.SmartDisplay
                                connectedApp?.name?.contains("Spotify", ignoreCase = true) == true -> Icons.Default.MusicNote
                                else -> Icons.Default.Link
                            },
                            contentDescription = "App Icon",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = connectedApp?.name ?: "YouTube (Modded / ReVanced)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MinimalTextPrimary
                        )
                        Text(
                            text = connectedApp?.packageName ?: "app.revanced.android.youtube",
                            style = MaterialTheme.typography.bodySmall,
                            color = MinimalTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Button(
                    onClick = onGoToHostRoom,
                    colors = ButtonDefaults.buttonColors(containerColor = MinimalPurpleContainer),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Search Songs",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalOnPurpleContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "✨ When you search for any song in the Host Room, SyncBeat will fetch & stream the song through this connected app in real-time across all party mobiles!",
                style = MaterialTheme.typography.bodySmall,
                color = MinimalTextSecondary,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun DetectedAppCardItem(
    app: InstalledAppInfo,
    isConnected: Boolean,
    onConnect: () -> Unit
) {
    val brandColor = Color(app.brandColor)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isConnected) MinimalPurpleContainer.copy(alpha = 0.45f) else MinimalSurface
        ),
        border = BorderStroke(
            1.dp,
            if (isConnected) MinimalPurple else MinimalBorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isConnected) 2.dp else 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onConnect)
            .testTag("app_item_${app.packageName.replace(".", "_")}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // App Icon Box with Brand Color
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(brandColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            app.name.contains("YouTube", ignoreCase = true) -> Icons.Default.SmartDisplay
                            app.name.contains("Spotify", ignoreCase = true) -> Icons.Default.MusicNote
                            app.name.contains("Apple", ignoreCase = true) -> Icons.Default.GraphicEq
                            app.name.contains("SoundCloud", ignoreCase = true) -> Icons.Default.GraphicEq
                            app.isMusicOrVideoApp -> Icons.Default.Headphones
                            else -> Icons.Default.Apps
                        },
                        contentDescription = app.name,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = app.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MinimalTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (app.isModded) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(ModdedBadgeColor)
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "MODDED",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "${app.category} • v${app.versionName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        fontSize = 11.sp
                    )

                    Text(
                        text = app.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextMuted,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Connect Button / Status Indicator
            if (isConnected) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(StatusActive.copy(alpha = 0.15f))
                        .border(BorderStroke(1.dp, StatusActive.copy(alpha = 0.5f)), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Connected",
                            tint = StatusActive,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "CONNECTED",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = StatusActive,
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                Button(
                    onClick = onConnect,
                    colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("connect_btn_${app.packageName.replace(".", "_")}")
                ) {
                    Text(
                        text = "CONNECT",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
