package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import coil.compose.AsyncImage
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectedDevice
import com.example.model.ConnectionType
import com.example.model.InstalledAppInfo
import com.example.model.MusicTrack
import com.example.model.RepeatMode
import com.example.utils.formatTimeMs
import com.example.ui.components.ConnectedAppBadge
import com.example.ui.components.MusicAppRow
import com.example.ui.components.QrCodeDialog
import com.example.ui.components.WaveformVisualizer
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalOnPurpleContainer
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalPurpleLight
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalSurfaceVariant
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.ModdedBadgeColor
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusError
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MusicSyncUiState
import com.example.viewmodel.MusicSyncViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HostRoomScreen(
    uiState: MusicSyncUiState,
    viewModel: MusicSyncViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val genreCategories = listOf("All", "Pop / Synthwave", "Indie Pop", "Disco Pop", "Pop Hits", "Dance Pop", "R&B / Electronic", "Pop / Rock", "Electropop")

    val connectedAppName = uiState.connectedApp?.name ?: "YouTube (Modded)"

    // Filter suggested tracks based on category & search query
    val filteredTracks = uiState.suggestedTracks.filter { track ->
        val matchesGenre = uiState.selectedGenre == "All" || track.genre.equals(uiState.selectedGenre, ignoreCase = true)
        matchesGenre
    }

    // QR Code Dialog
    if (uiState.isQrDialogVisible) {
        QrCodeDialog(
            roomCode = uiState.roomCode,
            onDismiss = { viewModel.setQrDialogVisible(false) },
            onCopyToast = { viewModel.clearToast() }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBackground)
    ) {
        // Top App Bar with CONNECT APP button & Stop Hosting Button
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "Host Music Room",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (uiState.isSyncActive) StatusActive else MinimalTextMuted)
                        )
                        Text(
                            text = if (uiState.isSyncActive) "Broadcasting via $connectedAppName" else "Broadcast Paused",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (uiState.isSyncActive) StatusActive else MinimalTextMuted,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.Home) },
                    modifier = Modifier.testTag("host_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MinimalTextPrimary
                    )
                }
            },
            actions = {
                // Small Button:-Name[CONNECT APP] in Host Room top bar
                Button(
                    onClick = { viewModel.onOpenConnectAppScreen() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MinimalPurpleContainer,
                        contentColor = MinimalOnPurpleContainer
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("host_connect_app_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = "Connect App",
                        modifier = Modifier.size(14.dp),
                        tint = MinimalOnPurpleContainer
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "CONNECT APP",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = MinimalOnPurpleContainer
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Stop Hosting Button
                Button(
                    onClick = { viewModel.stopHosting() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StatusError.copy(alpha = 0.15f),
                        contentColor = StatusError
                    ),
                    border = BorderStroke(1.dp, StatusError.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("host_stop_hosting_topbar_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.StopCircle,
                        contentDescription = "Stop Hosting",
                        tint = StatusError,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "Stop",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = StatusError,
                        fontSize = 10.sp
                    )
                }

                IconButton(
                    onClick = { viewModel.setQrDialogVisible(true) },
                    modifier = Modifier.testTag("host_qr_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = "QR Code",
                        tint = MinimalPurple
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MinimalBackground)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Room Code Hero Card
            item {
                HostRoomCodeCard(
                    roomCode = uiState.roomCode,
                    isSyncActive = uiState.isSyncActive,
                    connectedDevices = uiState.connectedDevices,
                    lastReaction = uiState.lastReaction,
                    connectedApp = uiState.connectedApp,
                    nearbyStatus = uiState.nearbyStatus,
                    onOpenConnectApp = { viewModel.onOpenConnectAppScreen() },
                    onToggleSync = { viewModel.toggleSyncBroadcast(it) },
                    onRegenerateCode = { viewModel.regenerateHostCode() },
                    onCopyCode = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        val clip = ClipData.newPlainText("SyncBeat Room Code", uiState.roomCode)
                        clipboard?.setPrimaryClip(clip)
                    },
                    onShareCode = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "Join my SyncBeat Music Session")
                            putExtra(Intent.EXTRA_TEXT, "Join my live music room on SyncBeat with code: ${uiState.roomCode}")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Room Code"))
                    },
                    onShowQr = { viewModel.setQrDialogVisible(true) },
                    onStopHosting = { viewModel.stopHosting() }
                )
            }

            // 2. Full Music Player Card with connected app stream indicator
            item {
                SpotifyMusicPlayerCard(
                    currentTrack = uiState.currentTrack,
                    isPlaying = uiState.isPlaying,
                    currentPositionMs = uiState.currentPositionMs,
                    durationMs = uiState.durationMs,
                    volume = uiState.volume,
                    isMuted = uiState.isMuted,
                    shuffleMode = uiState.shuffleMode,
                    repeatMode = uiState.repeatMode,
                    visualizerLevels = uiState.visualizerLevels,
                    onPlayPause = { viewModel.togglePlayPause() },
                    onNext = { viewModel.nextTrack() },
                    onPrev = { viewModel.prevTrack() },
                    onSeek = { viewModel.seekTo(it) },
                    onVolumeChange = { viewModel.setVolume(it) },
                    onToggleMute = { viewModel.toggleMute() },
                    onToggleShuffle = { viewModel.toggleShuffle() },
                    onToggleRepeat = { viewModel.toggleRepeat() },
                    onOpenInConnectedApp = { viewModel.launchSongInConnectedApp(uiState.currentTrack) }
                )
            }

            // 3. MUSIC SEARCH BUTTON & SEARCH BAR THROUGH CONNECTED APP
            item {
                HostMusicSearchThroughAppSection(
                    searchQuery = uiState.searchQuery,
                    connectedApp = uiState.connectedApp,
                    isSearchingMedia = uiState.isSearchingMedia,
                    onQueryChange = { viewModel.searchSongsThroughConnectedApp(it) },
                    onSearchClicked = { viewModel.searchSongsThroughConnectedApp(uiState.searchQuery) },
                    onOpenConnectApp = { viewModel.onOpenConnectAppScreen() },
                    selectedGenre = uiState.selectedGenre,
                    genres = genreCategories,
                    onSelectGenre = { viewModel.setSelectedGenre(it) }
                )
            }

            // 4. Searched / Suggested Songs List routed through Connected App
            if (filteredTracks.isNotEmpty()) {
                items(filteredTracks, key = { it.id }) { track ->
                    HostSongItemThroughApp(
                        track = track,
                        connectedAppName = uiState.connectedApp?.name ?: "YouTube Modded",
                        isCurrentPlaying = uiState.currentTrack.id == track.id,
                        isPlaying = uiState.isPlaying && uiState.currentTrack.id == track.id,
                        onPlayTrack = { viewModel.playTrack(track) },
                        onLaunchInApp = { viewModel.launchSongInConnectedApp(track) },
                        onToggleEnabled = { viewModel.toggleTrackEnabled(track.id) }
                    )
                }
            } else {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
                        border = BorderStroke(1.dp, MinimalBorderLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = if (uiState.isSearchingMedia) Icons.Default.Search else Icons.Default.MusicNote,
                                contentDescription = "Search API",
                                tint = MinimalPurple,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = when {
                                    uiState.isSearchingMedia -> "Searching YouTube, Spotify & Apple Music APIs..."
                                    uiState.searchQuery.isNotBlank() -> "No API media found for '${uiState.searchQuery}'"
                                    else -> "Search any song above to fetch live API media"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MinimalTextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Results are directly fetched from official YouTube, Spotify & Apple Music APIs.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MinimalTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // 5. Quick Launch Music Apps
            item {
                Spacer(modifier = Modifier.height(8.dp))
                MusicAppRow(
                    apps = uiState.availableMusicApps,
                    onLaunchApp = { viewModel.launchMusicApp(it) }
                )
            }
        }
    }
}

@Composable
fun HostRoomCodeCard(
    roomCode: String,
    isSyncActive: Boolean,
    connectedDevices: List<ConnectedDevice>,
    lastReaction: String? = null,
    connectedApp: InstalledAppInfo?,
    nearbyStatus: String = "Nearby Connections API Active (Wi-Fi & BT)",
    onOpenConnectApp: () -> Unit,
    onToggleSync: (Boolean) -> Unit,
    onRegenerateCode: () -> Unit,
    onCopyCode: () -> Unit,
    onShareCode: () -> Unit,
    onShowQr: () -> Unit,
    onStopHosting: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag("host_room_code_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Master Role Header & Sync Broadcast Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(StatusActive)
                        )
                        Text(
                            text = "REAL-TIME PARTY ROOM",
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusActive,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        )
                    }
                    Text(
                        text = "Host DJ controls music playback across all mobiles",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (isSyncActive) "Sync ON" else "Sync OFF",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isSyncActive) StatusActive else MinimalTextMuted
                    )
                    Switch(
                        checked = isSyncActive,
                        onCheckedChange = onToggleSync,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MinimalPurple,
                            uncheckedThumbColor = MinimalTextMuted,
                            uncheckedTrackColor = MinimalSurfaceVariant
                        ),
                        modifier = Modifier.testTag("toggle_sync_broadcast_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Connected App Status in Room Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MinimalPurpleContainer.copy(alpha = 0.45f))
                    .clickable(onClick = onOpenConnectApp)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = "Connected App",
                        tint = MinimalPurpleDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Music Source: ${connectedApp?.name ?: "YouTube (Modded)"}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalPurpleDark
                    )
                    if (connectedApp?.isModded == true) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(ModdedBadgeColor)
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "MODDED",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
                Text(
                    text = "Change App →",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalPurple,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Giant Room Code Display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MinimalSurfaceVariant)
                    .border(BorderStroke(1.dp, MinimalPurpleContainer), RoundedCornerShape(14.dp))
                    .padding(vertical = 12.dp, horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = roomCode,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MinimalPurpleDark,
                        letterSpacing = 2.sp,
                        modifier = Modifier.testTag("room_code_display_text")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = onRegenerateCode,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MinimalSurface)
                                .border(BorderStroke(1.dp, MinimalBorderLight), CircleShape)
                                .testTag("regenerate_room_code_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Regenerate Code",
                                tint = MinimalPurple,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = onCopyCode,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MinimalSurface)
                                .border(BorderStroke(1.dp, MinimalBorderLight), CircleShape)
                                .testTag("copy_room_code_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy Code",
                                tint = MinimalPurpleDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = onShareCode,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MinimalSurface)
                                .border(BorderStroke(1.dp, MinimalBorderLight), CircleShape)
                                .testTag("share_room_code_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share Code",
                                tint = MinimalPurpleDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = onShowQr,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MinimalPurpleContainer)
                                .testTag("show_qr_code_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = "Show QR",
                                tint = MinimalOnPurpleContainer,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Nearby Connections API Multi-Device Discovery Status Badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFF0FDF4))
                    .border(BorderStroke(1.dp, Color(0xFFBBF7D0)), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Devices,
                    contentDescription = "Nearby Connections API",
                    tint = Color(0xFF16A34A),
                    modifier = Modifier.size(16.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "NEARBY CONNECTIONS API (WiFi & Bluetooth Multi-Device P2P)",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF15803D),
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = nearbyStatus,
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = Color(0xFF166534)
                    )
                }
            }

            // Live Reaction Pill
            if (!lastReaction.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MinimalPurpleContainer)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = lastReaction, fontSize = 18.sp)
                    Text(
                        text = "Connected mobile reacted with cheer!",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalOnPurpleContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Connected Devices Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Devices,
                        contentDescription = "Devices",
                        tint = MinimalTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Connected Mobiles (${connectedDevices.size})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MinimalTextPrimary
                    )
                }

                Text(
                    text = "Wi-Fi & Bluetooth Sync",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalPurple
                )
            }

            if (connectedDevices.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(connectedDevices) { device ->
                        ConnectedDeviceChip(device = device)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Stop Hosting Group Room Button
            Button(
                onClick = onStopHosting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = StatusError,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("host_stop_hosting_card_button")
            ) {
                Icon(
                    imageVector = Icons.Default.StopCircle,
                    contentDescription = "Stop Hosting Group",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Stop Hosting (End Group Room)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun ConnectedDeviceChip(device: ConnectedDevice) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MinimalSurface)
            .border(BorderStroke(1.dp, MinimalBorderLight), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = if (device.connectionType == ConnectionType.WIFI) Icons.Default.Wifi else Icons.Default.Bluetooth,
                contentDescription = "Connection Type",
                tint = if (device.connectionType == ConnectionType.WIFI) MinimalPurple else MinimalPurpleLight,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = device.name,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Medium,
                color = MinimalTextPrimary
            )
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Synced",
                tint = StatusActive,
                modifier = Modifier.size(12.dp)
            )
        }
    }
}

@Composable
fun SpotifyMusicPlayerCard(
    currentTrack: MusicTrack,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    volume: Float,
    isMuted: Boolean,
    shuffleMode: Boolean,
    repeatMode: RepeatMode,
    visualizerLevels: FloatArray,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onSeek: (Long) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onOpenInConnectedApp: () -> Unit
) {
    var isDraggingSlider by remember { mutableStateOf(false) }
    var dragPositionMs by remember { mutableFloatStateOf(0f) }
    val effectivePosition = if (isDraggingSlider) dragPositionMs.toLong() else currentPositionMs
    val progressFraction = if (durationMs > 0) (effectivePosition.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag("spotify_music_player_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Source App Tag
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MinimalPurpleContainer)
                    .clickable(onClick = onOpenInConnectedApp)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SmartDisplay,
                        contentDescription = "Source App",
                        tint = MinimalOnPurpleContainer,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "Streaming via ${currentTrack.sourceApp}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalOnPurpleContainer,
                        fontSize = 11.sp
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "Open App",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalPurple,
                        fontSize = 10.sp
                    )
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Open",
                        tint = MinimalPurple,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Waveform Box & Live Visualizer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MinimalPurpleDark)
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "LIVE SYNC WAVE",
                            style = MaterialTheme.typography.labelSmall,
                            color = MinimalPurpleContainer,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                        Text(
                            text = "${currentTrack.bpm} BPM",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 9.sp
                        )
                    }

                    WaveformVisualizer(
                        levels = visualizerLevels,
                        isPlaying = isPlaying,
                        height = 36.dp,
                        barColor1 = MinimalPurpleContainer,
                        barColor2 = Color.White,
                        barColor3 = MinimalPurpleLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Track Title & Artist
            Text(
                text = currentTrack.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MinimalTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "${currentTrack.artist} • ${currentTrack.genre}",
                style = MaterialTheme.typography.bodyMedium,
                color = MinimalTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Timeline Seek Bar
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = progressFraction,
                    onValueChange = { frac ->
                        isDraggingSlider = true
                        dragPositionMs = frac * durationMs
                    },
                    onValueChangeFinished = {
                        isDraggingSlider = false
                        onSeek(dragPositionMs.toLong())
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = MinimalPurple,
                        activeTrackColor = MinimalPurple,
                        inactiveTrackColor = MinimalSurfaceVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .testTag("timeline_seek_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatTimeMs(effectivePosition),
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextSecondary
                    )
                    Text(
                        text = formatTimeMs(durationMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Spotify-style Transport Controls Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shuffle Button
                IconButton(
                    onClick = onToggleShuffle,
                    modifier = Modifier.testTag("player_shuffle_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (shuffleMode) MinimalPurple else MinimalTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Previous Track Button
                IconButton(
                    onClick = onPrev,
                    modifier = Modifier.testTag("player_prev_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Previous Song",
                        tint = MinimalTextPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Main Play / Pause Button
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(MinimalPurple, MinimalPurpleLight)
                            )
                        )
                        .clickable(onClick = onPlayPause)
                        .testTag("player_play_pause_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Next Track Button
                IconButton(
                    onClick = onNext,
                    modifier = Modifier.testTag("player_next_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Next Song",
                        tint = MinimalTextPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Repeat Mode Button
                IconButton(
                    onClick = onToggleRepeat,
                    modifier = Modifier.testTag("player_repeat_button")
                ) {
                    Icon(
                        imageVector = if (repeatMode == RepeatMode.ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        contentDescription = "Repeat",
                        tint = if (repeatMode != RepeatMode.OFF) MinimalPurple else MinimalTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Volume Control Slider
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (isMuted || volume == 0f) Icons.AutoMirrored.Filled.VolumeMute else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Volume",
                        tint = MinimalTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Slider(
                    value = if (isMuted) 0f else volume,
                    onValueChange = onVolumeChange,
                    colors = SliderDefaults.colors(
                        thumbColor = MinimalPurple,
                        activeTrackColor = MinimalPurple,
                        inactiveTrackColor = MinimalSurfaceVariant
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(20.dp)
                        .testTag("volume_slider")
                )

                Text(
                    text = "${(volume * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalTextSecondary,
                    modifier = Modifier.width(36.dp)
                )
            }
        }
    }
}

@Composable
fun HostMusicSearchThroughAppSection(
    searchQuery: String,
    connectedApp: InstalledAppInfo?,
    isSearchingMedia: Boolean = false,
    onQueryChange: (String) -> Unit,
    onSearchClicked: () -> Unit,
    onOpenConnectApp: () -> Unit,
    selectedGenre: String,
    genres: List<String>,
    onSelectGenre: (String) -> Unit
) {
    val appName = connectedApp?.name ?: "YouTube (Modded)"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Real Media Search via $appName & APIs",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (connectedApp?.isModded == true) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(ModdedBadgeColor)
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "MODDED",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
                Text(
                    text = "Searches live YouTube & Spotify media APIs across all connected rooms",
                    style = MaterialTheme.typography.bodySmall,
                    color = MinimalTextSecondary
                )
            }

            OutlinedButton(
                onClick = onOpenConnectApp,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MinimalPurple),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.testTag("switch_connected_app_button")
            ) {
                Text(
                    text = "Connect App",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MinimalPurple
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Bar with dedicated Search Button & Loading Indicator
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onQueryChange,
                placeholder = {
                    Text(
                        text = "Search YouTube, Spotify, or Apple Music...",
                        color = MinimalTextMuted,
                        fontSize = 13.sp
                    )
                },
                leadingIcon = {
                    if (isSearchingMedia) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = MinimalPurple,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MinimalPurple,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onQueryChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear",
                                tint = MinimalTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearchClicked() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MinimalSurface,
                    unfocusedContainerColor = MinimalSurface,
                    focusedBorderColor = MinimalPurple,
                    unfocusedBorderColor = MinimalBorder,
                    focusedTextColor = MinimalTextPrimary,
                    unfocusedTextColor = MinimalTextPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("host_music_search_bar")
            )

            Button(
                onClick = onSearchClicked,
                colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                modifier = Modifier
                    .height(52.dp)
                    .testTag("host_music_search_action_button")
            ) {
                if (isSearchingMedia) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search Now",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isSearchingMedia) "Searching..." else "Search API",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Genre Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(genres) { genre ->
                val isSelected = selectedGenre == genre
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectGenre(genre) },
                    label = { Text(genre, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MinimalPurpleContainer,
                        selectedLabelColor = MinimalOnPurpleContainer,
                        containerColor = MinimalSurface,
                        labelColor = MinimalTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = MinimalBorder,
                        selectedBorderColor = MinimalPurple
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }
    }
}

@Composable
fun HostSongItemThroughApp(
    track: MusicTrack,
    connectedAppName: String,
    isCurrentPlaying: Boolean,
    isPlaying: Boolean,
    onPlayTrack: () -> Unit,
    onLaunchInApp: () -> Unit,
    onToggleEnabled: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentPlaying) MinimalSurfaceVariant else MinimalSurface
        ),
        border = BorderStroke(
            1.dp,
            if (isCurrentPlaying) MinimalPurple else MinimalBorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 3.dp)
            .testTag("track_item_${track.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onPlayTrack)
            ) {
                // Play Icon Box with Real Artwork Thumbnail
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (isCurrentPlaying) MinimalPurple else MinimalPurpleContainer
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (track.artworkUrl.isNotBlank()) {
                        AsyncImage(
                            model = track.artworkUrl,
                            contentDescription = track.title,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isCurrentPlaying && isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play status",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    } else {
                        Icon(
                            imageVector = if (isCurrentPlaying && isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play status",
                            tint = if (isCurrentPlaying) Color.White else MinimalOnPurpleContainer,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = if (isCurrentPlaying) MinimalPurple else MinimalTextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(track.accentColor).copy(alpha = 0.15f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = track.mediaType.ifBlank { "via ${track.sourceApp}" },
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(track.accentColor)
                            )
                        }

                        Text(
                            text = "${track.artist} • ${track.genre}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MinimalTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Action Buttons: Open In Connected App & Toggle
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Button to open / stream directly in YouTube Modded / Spotify / connected app
                IconButton(
                    onClick = onLaunchInApp,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(MinimalSurfaceVariant)
                        .testTag("launch_song_app_${track.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Open in $connectedAppName",
                        tint = MinimalPurple,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Switch(
                    checked = track.isEnabled,
                    onCheckedChange = { onToggleEnabled() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = MinimalPurple,
                        uncheckedThumbColor = MinimalTextMuted,
                        uncheckedTrackColor = MinimalSurfaceVariant
                    ),
                    modifier = Modifier.testTag("toggle_track_${track.id}")
                )
            }
        }
    }
}
