package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.model.InstalledAppInfo
import com.example.ui.components.ConnectedAppBadge
import com.example.ui.components.MiniPlayerBar
import com.example.ui.components.MusicAppRow
import com.example.ui.components.WaveformVisualizer
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalBorderOutline
import com.example.ui.theme.MinimalOnPurpleContainer
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalPurpleLight
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalSurfaceVariant
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusError
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MusicSyncUiState
import com.example.viewmodel.MusicSyncViewModel

@Composable
fun HomeScreen(
    uiState: MusicSyncUiState,
    viewModel: MusicSyncViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = if (uiState.isPlaying || uiState.currentPositionMs > 0) 90.dp else 24.dp)
        ) {
            // App Header with CONNECT APP Small Button & status
            HomeTopHeader(
                isWifiEnabled = uiState.isWifiEnabled,
                isBluetoothEnabled = uiState.isBluetoothEnabled,
                connectedApp = uiState.connectedApp,
                onConnectAppClicked = { viewModel.onOpenConnectAppScreen() }
            )

            // Small Button: CONNECT APP Banner / Action Bar
            ConnectAppSmallActionBar(
                connectedApp = uiState.connectedApp,
                onConnectAppClicked = { viewModel.onOpenConnectAppScreen() }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Hero Banner with Waveform Pulse
            HeroCardBanner(
                isPlaying = uiState.isPlaying,
                connectedAppName = uiState.connectedApp?.name ?: "YouTube Modded",
                visualizerLevels = uiState.visualizerLevels,
                onPlaySample = { viewModel.togglePlayPause() }
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Section: Main Actions
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // BUTTON 1: "Generate Code" (Host Mode)
                GenerateCodeCardButton(
                    onGenerateCode = { viewModel.onGenerateCodeClicked() }
                )

                // BUTTON 2: "Connect Through Code" (Client Mode with mini space and connect button)
                ConnectThroughCodeCard(
                    codeInput = uiState.joinCodeInput,
                    errorMessage = uiState.joinErrorMessage,
                    onCodeChange = { viewModel.updateJoinCodeInput(it) },
                    onConnect = {
                        viewModel.connectThroughCode(
                            onSuccess = {
                                viewModel.navigateTo(AppScreen.JoinRoom)
                            }
                        )
                    },
                    onBrowseRooms = {
                        viewModel.onOpenConnectThroughCodeScreen()
                    },
                    isConnecting = uiState.connectionStatus == ConnectionStatus.CONNECTING
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Quick Music Apps Launcher Carousel
            MusicAppRow(
                apps = uiState.availableMusicApps,
                onLaunchApp = { viewModel.launchMusicApp(it) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Background & Sync Capabilities Features Banner
            SyncFeaturesCard()

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Floating Mini Player Bar if music active
        AnimatedVisibility(
            visible = uiState.isPlaying || uiState.currentPositionMs > 0,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        ) {
            MiniPlayerBar(
                track = uiState.currentTrack,
                isPlaying = uiState.isPlaying,
                currentPositionMs = uiState.currentPositionMs,
                durationMs = uiState.durationMs,
                onPlayPause = { viewModel.togglePlayPause() },
                onNext = { viewModel.nextTrack() },
                onClick = {
                    if (uiState.isHost) {
                        viewModel.navigateTo(AppScreen.HostRoom)
                    } else if (uiState.connectionStatus == ConnectionStatus.CONNECTED_AS_CLIENT) {
                        viewModel.navigateTo(AppScreen.JoinRoom)
                    } else {
                        viewModel.onGenerateCodeClicked()
                    }
                }
            )
        }
    }
}

@Composable
fun HomeTopHeader(
    isWifiEnabled: Boolean,
    isBluetoothEnabled: Boolean,
    connectedApp: InstalledAppInfo?,
    onConnectAppClicked: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(MinimalPurpleContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "App Logo",
                    tint = MinimalOnPurpleContainer,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "SyncBeat",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MinimalTextPrimary,
                    letterSpacing = (-0.25).sp
                )
                Text(
                    text = "Multi-Device Party Audio",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalTextSecondary
                )
            }
        }

        // Small Button: Name [CONNECT APP] in the top header
        Button(
            onClick = onConnectAppClicked,
            colors = ButtonDefaults.buttonColors(
                containerColor = MinimalPurpleContainer,
                contentColor = MinimalOnPurpleContainer
            ),
            border = BorderStroke(1.dp, MinimalPurple.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(10.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.testTag("connect_app_header_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Link,
                    contentDescription = "Connect App",
                    tint = MinimalOnPurpleContainer,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = "CONNECT APP",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MinimalOnPurpleContainer,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun ConnectAppSmallActionBar(
    connectedApp: InstalledAppInfo?,
    onConnectAppClicked: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurfaceVariant),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onConnectAppClicked)
            .testTag("connect_app_bar_container")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(
                            if (connectedApp != null) Color(connectedApp.brandColor) else MinimalPurple
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            connectedApp?.name?.contains("YouTube", ignoreCase = true) == true -> Icons.Default.SmartDisplay
                            connectedApp?.name?.contains("Spotify", ignoreCase = true) == true -> Icons.Default.MusicNote
                            else -> Icons.Default.Link
                        },
                        contentDescription = "Connected App Icon",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = if (connectedApp != null) "Connected Mobile App:" else "No App Connected",
                            style = MaterialTheme.typography.labelSmall,
                            color = MinimalTextSecondary,
                            fontSize = 11.sp
                        )
                        if (connectedApp?.isModded == true) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFFE50914))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "MODDED",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                    Text(
                        text = connectedApp?.name ?: "Tap to detect & connect downloaded apps",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                }
            }

            // Small Button Name [CONNECT APP]
            Button(
                onClick = onConnectAppClicked,
                colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("connect_app_small_button")
            ) {
                Text(
                    text = "CONNECT APP",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun HeroCardBanner(
    isPlaying: Boolean,
    connectedAppName: String,
    visualizerLevels: FloatArray,
    onPlaySample: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalPurpleDark),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(StatusActive)
                        )
                        Text(
                            text = "CONNECTED VIA $connectedAppName".uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MinimalPurpleContainer,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Play Music in Perfect Sync",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable(onClick = onPlaySample)
                        .testTag("hero_play_sample_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.MusicNote else Icons.Default.CastConnected,
                        contentDescription = "Quick Audio",
                        tint = MinimalPurpleDark,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            WaveformVisualizer(
                levels = visualizerLevels,
                isPlaying = isPlaying,
                height = 30.dp,
                barColor1 = MinimalPurpleContainer,
                barColor2 = Color.White,
                barColor3 = MinimalPurpleLight
            )
        }
    }
}

@Composable
fun GenerateCodeCardButton(
    onGenerateCode: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalPurple),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onGenerateCode)
            .testTag("generate_code_button")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = "Generate Code",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Generate Code",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Host a new music room & stream songs to party mobiles",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f),
                        fontWeight = FontWeight.Normal
                    )
                }
            }
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Go",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun ConnectThroughCodeCard(
    codeInput: String,
    errorMessage: String? = null,
    onCodeChange: (String) -> Unit,
    onConnect: () -> Unit,
    onBrowseRooms: () -> Unit,
    isConnecting: Boolean
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurfaceVariant),
        border = BorderStroke(
            1.dp,
            if (!errorMessage.isNullOrBlank()) StatusError.copy(alpha = 0.6f) else MinimalBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("connect_through_code_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MinimalPurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = "Connect Code",
                        tint = MinimalOnPurpleContainer,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Connect through code",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = "Only real-time generated codes from active hosts work",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Mini space to write the code
            OutlinedTextField(
                value = codeInput,
                onValueChange = { input ->
                    if (input.length <= 12) {
                        onCodeChange(input.uppercase())
                    }
                },
                placeholder = {
                    Text(
                        text = "Enter real-time code (e.g. SYNC-4B9X)",
                        color = MinimalTextMuted,
                        fontSize = 14.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "Key Icon",
                        tint = if (!errorMessage.isNullOrBlank()) StatusError else MinimalPurple,
                        modifier = Modifier.size(20.dp)
                    )
                },
                isError = !errorMessage.isNullOrBlank(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { onConnect() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MinimalSurface,
                    unfocusedContainerColor = MinimalSurface,
                    focusedBorderColor = MinimalPurple,
                    unfocusedBorderColor = MinimalBorderOutline,
                    errorBorderColor = StatusError,
                    errorContainerColor = MinimalSurface,
                    focusedTextColor = MinimalTextPrimary,
                    unfocusedTextColor = MinimalTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("join_code_input")
            )

            // "Not Available" Error Warning Banner
            if (!errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(StatusError.copy(alpha = 0.10f))
                        .border(BorderStroke(1.dp, StatusError.copy(alpha = 0.3f)), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = "Not Available",
                        tint = StatusError,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = StatusError
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Direct Connect Button Underneath
            Button(
                onClick = onConnect,
                enabled = codeInput.isNotBlank() && !isConnecting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MinimalPurple,
                    disabledContainerColor = MinimalBorderLight
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("connect_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CastConnected,
                        contentDescription = "Connect",
                        tint = if (codeInput.isNotBlank()) Color.White else MinimalTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isConnecting) "Validating Code..." else "Connect",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (codeInput.isNotBlank()) Color.White else MinimalTextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Secondary option to view active broadcasted rooms
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onBrowseRooms)
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "View all active real-time rooms →",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalPurple,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SyncFeaturesCard() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "⚡ Background Streaming & Wi-Fi/Bluetooth",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MinimalTextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "• Runs in background with media notification controls\n• Connect mobiles across same Wi-Fi network or Bluetooth\n• Connect to YouTube Modded, Spotify, or any detected mobile app\n• Search in host room routes songs through your connected app",
                style = MaterialTheme.typography.bodySmall,
                color = MinimalTextSecondary,
                lineHeight = 20.sp
            )
        }
    }
}
