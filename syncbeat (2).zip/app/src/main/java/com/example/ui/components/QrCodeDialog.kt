package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import kotlin.math.abs

@Composable
fun QrCodeDialog(
    roomCode: String,
    onDismiss: () -> Unit,
    onCopyToast: () -> Unit
) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MinimalSurface),
            border = BorderStroke(1.dp, MinimalBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Scan to Connect",
                        style = MaterialTheme.typography.titleLarge,
                        color = MinimalTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_qr_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MinimalTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Canvas QR Code Generator
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(BorderStroke(1.dp, MinimalBorderLight), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(168.dp)) {
                        val gridSize = 17
                        val cellSize = size.width / gridSize
                        val seed = abs(roomCode.hashCode())

                        for (r in 0 until gridSize) {
                            for (c in 0 until gridSize) {
                                val isCorner = (r < 4 && c < 4) || (r < 4 && c >= gridSize - 4) || (r >= gridSize - 4 && c < 4)
                                val isCornerBorder = (r == 0 || r == 3 || c == 0 || c == 3) && (r < 4 && c < 4) ||
                                        (r == 0 || r == 3 || c == gridSize - 4 || c == gridSize - 1) && (r < 4 && c >= gridSize - 4) ||
                                        (r == gridSize - 4 || r == gridSize - 1 || c == 0 || c == 3) && (r >= gridSize - 4 && c < 4)
                                val isCornerCenter = (r == 1 && c == 1) || (r == 1 && c == gridSize - 2) || (r == gridSize - 2 && c == 1)

                                val shouldFill = if (isCorner) {
                                    isCornerBorder || isCornerCenter
                                } else {
                                    ((seed xor (r * 31 + c * 17)) % 3) != 0
                                }

                                if (shouldFill) {
                                    drawRect(
                                        color = MinimalPurpleDark,
                                        topLeft = Offset(c * cellSize, r * cellSize),
                                        size = Size(cellSize * 0.95f, cellSize * 0.95f)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "ROOM CODE",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalPurple,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = roomCode,
                    style = MaterialTheme.typography.displayMedium,
                    color = MinimalPurpleDark,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Ask other devices to open SyncBeat and enter this code",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MinimalTextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            val clip = ClipData.newPlainText("SyncBeat Room Code", roomCode)
                            clipboard?.setPrimaryClip(clip)
                            onCopyToast()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("copy_qr_code_button"),
                        border = BorderStroke(1.dp, MinimalBorder),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            modifier = Modifier.size(18.dp),
                            tint = MinimalTextPrimary
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Copy", color = MinimalTextPrimary)
                    }

                    Button(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Join my SyncBeat Music Room")
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "Join my live synchronized music session on SyncBeat with room code: $roomCode"
                                )
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Room Code"))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("share_qr_code_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            modifier = Modifier.size(18.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("Share", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
