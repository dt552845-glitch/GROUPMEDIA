package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.VolumeMute
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.model.MusicTrack
import com.example.utils.formatTimeMs
import com.example.ui.components.MusicAppRow
import com.example.ui.components.WaveformVisualizer
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalOnPurpleContainer
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalPurpleLight
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalSurfaceVariant
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusError
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MusicSyncUiState
import com.example.viewmodel.MusicSyncViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JoinRoomScreen(
    uiState: MusicSyncUiState,
    viewModel: MusicSyncViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isConnected = uiState.connectionStatus == ConnectionStatus.CONNECTED_AS_CLIENT

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBackground)
    ) {
        // Top App Bar
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = if (isConnected) "Synced Party Room" else "Connect Through Code",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    if (isConnected) {
                        Text(
                            text = "Connected Mobile • Streamed by Host",
                            style = MaterialTheme.typography.labelSmall,
                            color = MinimalPurple,
                            fontSize = 11.sp
                        )
                    }
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.Home) },
                    modifier = Modifier.testTag("join_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MinimalTextPrimary
                    )
                }
            },
            actions = {
                if (isConnected) {
                    Button(
                        onClick = { viewModel.exitPartyRoom() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusError.copy(alpha = 0.15f),
                            contentColor = StatusError
                        ),
                        border = BorderStroke(1.dp, StatusError.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("exit_party_topbar_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Exit Party",
                            tint = StatusError,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Exit",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = StatusError
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MinimalBackground)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (!isConnected) {
                // Section 1: Code Input Mini Space & Connect Button
                item {
                    JoinCodeInputCard(
                        codeInput = uiState.joinCodeInput,
                        errorMessage = uiState.joinErrorMessage,
                        onCodeChange = { viewModel.updateJoinCodeInput(it) },
                        onConnect = { viewModel.connectThroughCode() },
                        isConnecting = uiState.connectionStatus == ConnectionStatus.CONNECTING,
                        onPaste = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            val clip = clipboard?.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                            if (clip.isNotBlank()) {
                                viewModel.updateJoinCodeInput(clip)
                            }
                        }
                    )
                }

                // Section 2: Real-time active host rooms
                item {
                    ActiveRealTimeRoomsCard(
                        activeRooms = uiState.activeRealTimeRooms,
                        onSelectRoom = { roomCode ->
                            viewModel.updateJoinCodeInput(roomCode)
                            viewModel.connectThroughCode()
                        },
                        onHostRoom = {
                            viewModel.onGenerateCodeClicked()
                        }
                    )
                }
            } else {
                // Connected Listener Mode View
                item {
                    ConnectedRoomHeaderCard(
                        roomCode = uiState.roomCode,
                        driftMs = uiState.syncDriftMs,
                        isPlaying = uiState.isPlaying,
                        onDisconnect = { viewModel.exitPartyRoom() },
                        onExitParty = { viewModel.exitPartyRoom() },
                        onRefreshSync = { viewModel.requestSyncRefresh() }
                    )
                }

                item {
                    ClientSynchronizedPlayerCard(
                        currentTrack = uiState.currentTrack,
                        isPlaying = uiState.isPlaying,
                        currentPositionMs = uiState.currentPositionMs,
                        durationMs = uiState.durationMs,
                        volume = uiState.volume,
                        isMuted = uiState.isMuted,
                        visualizerLevels = uiState.visualizerLevels,
                        listenerAudioMode = uiState.listenerAudioMode,
                        onVolumeChange = { viewModel.setVolume(it) },
                        onToggleMute = { viewModel.toggleMute() },
                        onSelectAudioMode = { viewModel.setListenerAudioMode(it) },
                        onSendReaction = { viewModel.sendListenerReaction(it) },
                        onRefreshSync = { viewModel.requestSyncRefresh() }
                    )
                }

                item {
                    Column(modifier = Modifier.padding(top = 4.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Host Party Playlist",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MinimalTextPrimary
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MinimalPurpleContainer)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "In Sync",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MinimalOnPurpleContainer,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Text(
                            text = "The room host controls and syncs songs across all mobiles via ${uiState.connectedApp?.name ?: "Connected App"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MinimalTextSecondary
                        )
                    }
                }

                items(uiState.suggestedTracks.filter { it.isEnabled }, key = { it.id }) { track ->
                    ClientTrackItem(
                        track = track,
                        isCurrentPlaying = uiState.currentTrack.id == track.id
                    )
                }
            }

            // Quick Music Apps Launcher
            item {
                Spacer(modifier = Modifier.height(8.dp))
                MusicAppRow(
                    apps = uiState.availableMusicApps,
                    onLaunchApp = { viewModel.launchMusicApp(it) }
                )
            }
        }
    }
}

@Composable
fun JoinCodeInputCard(
    codeInput: String,
    errorMessage: String? = null,
    onCodeChange: (String) -> Unit,
    onConnect: () -> Unit,
    isConnecting: Boolean,
    onPaste: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(
            1.dp,
            if (!errorMessage.isNullOrBlank()) StatusError.copy(alpha = 0.6f) else MinimalBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MinimalPurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = "Key",
                        tint = MinimalOnPurpleContainer,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Enter Room Code",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = "Only real-time generated codes from active hosts work",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Nearby Connections API Scanner Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF0FDF4))
                    .border(BorderStroke(1.dp, Color(0xFFBBF7D0)), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Devices,
                    contentDescription = "Nearby Connections API",
                    tint = Color(0xFF16A34A),
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Nearby P2P (Wi-Fi & Bluetooth): Ready to pair",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF15803D)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Mini space to write the code
            OutlinedTextField(
                value = codeInput,
                onValueChange = { input ->
                    if (input.length <= 12) {
                        onCodeChange(input.uppercase())
                    }
                },
                placeholder = {
                    Text("e.g. SYNC-8291", color = MinimalTextMuted)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "Key",
                        tint = if (!errorMessage.isNullOrBlank()) StatusError else MinimalPurple,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        if (codeInput.isNotEmpty()) {
                            IconButton(onClick = { onCodeChange("") }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = MinimalTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        IconButton(onClick = onPaste) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = "Paste",
                                tint = MinimalPurple,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                isError = !errorMessage.isNullOrBlank(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { onConnect() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MinimalSurface,
                    unfocusedContainerColor = MinimalSurface,
                    focusedBorderColor = MinimalPurple,
                    unfocusedBorderColor = MinimalBorder,
                    errorBorderColor = StatusError,
                    errorContainerColor = MinimalSurface,
                    focusedTextColor = MinimalTextPrimary,
                    unfocusedTextColor = MinimalTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("join_page_code_input")
            )

            // Prominent "Code Not Available" banner when an invalid or expired code is entered
            if (!errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(StatusError.copy(alpha = 0.10f))
                        .border(BorderStroke(1.dp, StatusError.copy(alpha = 0.3f)), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = "Not Available",
                        tint = StatusError,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "Code Not Available",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusError
                        )
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = StatusError
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Connect Button Underneath
            Button(
                onClick = onConnect,
                enabled = codeInput.isNotBlank() && !isConnecting,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MinimalPurple,
                    disabledContainerColor = MinimalSurfaceVariant
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("join_page_connect_button")
            ) {
                if (isConnecting) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Validating & Connecting...",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.CastConnected,
                        contentDescription = "Connect",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Connect",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun ActiveRealTimeRoomsCard(
    activeRooms: List<com.example.sync.ActiveRoomSession>,
    onSelectRoom: (String) -> Unit,
    onHostRoom: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Sensors,
                    contentDescription = "Active Real-Time Rooms",
                    tint = MinimalPurple,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Active Real-Time Rooms",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MinimalTextPrimary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (activeRooms.isEmpty()) {
                // Empty state when no real-time rooms are hosted yet
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MinimalSurfaceVariant)
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Info",
                        tint = MinimalPurpleLight,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Only Real-Time Generated Codes Work",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "All other arbitrary codes will show 'Not Available'. Start a session by generating a real code on the host mobile.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = onHostRoom,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MinimalPurple)
                    ) {
                        Text(
                            text = "Host & Generate Code",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MinimalPurple
                        )
                    }
                }
            } else {
                activeRooms.forEach { session ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MinimalSurfaceVariant)
                            .clickable { onSelectRoom(session.roomCode) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(StatusActive)
                            )
                            Column {
                                Text(
                                    text = session.roomCode,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MinimalPurpleDark
                                )
                                Text(
                                    text = "${session.hostDeviceName} • Real-time Broadcast",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MinimalTextSecondary
                                )
                            }
                        }

                        Button(
                            onClick = { onSelectRoom(session.roomCode) },
                            colors = ButtonDefaults.buttonColors(containerColor = MinimalPurpleContainer),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Join",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MinimalOnPurpleContainer
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ConnectedRoomHeaderCard(
    roomCode: String,
    driftMs: Long,
    isPlaying: Boolean,
    onDisconnect: () -> Unit,
    onRefreshSync: () -> Unit,
    onExitParty: () -> Unit = onDisconnect
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalPurpleContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("connected_room_header_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MinimalPurpleContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Connected",
                            tint = MinimalOnPurpleContainer,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Room $roomCode",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MinimalTextPrimary
                        )
                        Text(
                            text = if (isPlaying) "Playing in Sync with Host" else "Host Playback Paused",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isPlaying) StatusActive else MinimalTextSecondary
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = onRefreshSync,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CastConnected,
                            contentDescription = "Resync",
                            tint = MinimalPurple,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    OutlinedButton(
                        onClick = onExitParty,
                        border = BorderStroke(1.dp, StatusError.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Exit", color = StatusError, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sync Drift telemetry badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MinimalSurfaceVariant)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(StatusActive)
                    )
                    Text(
                        text = "Real-time Multi-Device Sync Lock",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }

                Text(
                    text = "Drift: ~${driftMs}ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalPurple,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Exit Party Room Button for Connected Clients
            Button(
                onClick = onExitParty,
                colors = ButtonDefaults.buttonColors(
                    containerColor = StatusError,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("exit_party_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = "Exit Party",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Exit Party Room (Disconnect)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun ClientSynchronizedPlayerCard(
    currentTrack: MusicTrack,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    volume: Float,
    isMuted: Boolean,
    visualizerLevels: FloatArray,
    listenerAudioMode: String,
    onVolumeChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onSelectAudioMode: (String) -> Unit,
    onSendReaction: (String) -> Unit,
    onRefreshSync: () -> Unit
) {
    val progress = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Role Banner: Controlled by Host via Connected App
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MinimalPurpleContainer)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SmartDisplay,
                        contentDescription = "Host Controlled",
                        tint = MinimalOnPurpleContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Streaming in sync via ${currentTrack.sourceApp}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalOnPurpleContainer
                    )
                }

                Text(
                    text = if (isPlaying) "LIVE" else "PAUSED",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isPlaying) StatusActive else MinimalTextMuted
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Waveform Box & Live Visualizer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MinimalPurpleDark)
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "SYNCED STREAM",
                            style = MaterialTheme.typography.labelSmall,
                            color = MinimalPurpleContainer,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                        Text(
                            text = "${currentTrack.bpm} BPM",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 9.sp
                        )
                    }

                    WaveformVisualizer(
                        levels = visualizerLevels,
                        isPlaying = isPlaying,
                        height = 36.dp,
                        barColor1 = MinimalPurpleContainer,
                        barColor2 = Color.White,
                        barColor3 = MinimalPurpleLight
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = currentTrack.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MinimalTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "${currentTrack.artist} • ${currentTrack.genre}",
                style = MaterialTheme.typography.bodyMedium,
                color = MinimalTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Synchronized Timeline Progress
            Slider(
                value = progress,
                onValueChange = { /* Host controls seeking */ },
                enabled = false,
                colors = SliderDefaults.colors(
                    disabledThumbColor = MinimalPurple,
                    disabledActiveTrackColor = MinimalPurple,
                    disabledInactiveTrackColor = MinimalSurfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(24.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatTimeMs(currentPositionMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalPurple,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Synced Timeline",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalTextMuted
                )
                Text(
                    text = formatTimeMs(durationMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Local Device Volume Control
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MinimalSurfaceVariant),
                border = BorderStroke(1.dp, MinimalBorderLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "This Mobile's Speaker Volume",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MinimalTextPrimary
                        )
                        Text(
                            text = if (isMuted) "Muted" else "${(volume * 100).toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MinimalPurple
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onToggleMute, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = if (isMuted || volume == 0f) Icons.AutoMirrored.Filled.VolumeMute else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Mute",
                                tint = MinimalPurple,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Slider(
                            value = if (isMuted) 0f else volume,
                            onValueChange = onVolumeChange,
                            colors = SliderDefaults.colors(
                                thumbColor = MinimalPurple,
                                activeTrackColor = MinimalPurple,
                                inactiveTrackColor = MinimalBackground
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Audio Mode Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Device Speaker", "Headphones", "Bluetooth Amp").forEach { mode ->
                    val isSelected = listenerAudioMode == mode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) MinimalPurpleContainer else MinimalSurfaceVariant)
                            .border(
                                1.dp,
                                if (isSelected) MinimalPurple else MinimalBorderLight,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { onSelectAudioMode(mode) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) MinimalOnPurpleContainer else MinimalTextPrimary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Send Cheer Reaction to Room
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Cheer & React to Room Host",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalTextSecondary,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("🔥", "🎉", "👏", "❤️", "⚡", "🎵").forEach { emoji ->
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MinimalSurfaceVariant)
                                .clickable { onSendReaction(emoji) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = emoji, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ClientTrackItem(
    track: MusicTrack,
    isCurrentPlaying: Boolean
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentPlaying) MinimalSurfaceVariant else MinimalSurface
        ),
        border = BorderStroke(
            1.dp,
            if (isCurrentPlaying) MinimalPurple else MinimalBorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isCurrentPlaying) MinimalPurple else MinimalPurpleContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Note",
                    tint = if (isCurrentPlaying) Color.White else MinimalOnPurpleContainer,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (isCurrentPlaying) MinimalPurple else MinimalTextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(MinimalPurpleContainer)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "via ${track.sourceApp}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MinimalOnPurpleContainer
                        )
                    }
                    Text(
                        text = "${track.artist} • ${track.genre}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (isCurrentPlaying) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MinimalPurpleContainer)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "Playing",
                        tint = MinimalOnPurpleContainer,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Live In Sync",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalOnPurpleContainer,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
