package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlaybackEngine
import com.example.model.ConnectedDevice
import com.example.model.ConnectionStatus
import com.example.model.InstalledAppInfo
import com.example.model.MusicAppInfo
import com.example.model.MusicTrack
import com.example.model.MusicTrackCatalog
import com.example.model.RepeatMode
import com.example.service.MusicSyncService
import com.example.sync.ActiveRoomRegistry
import com.example.sync.ActiveRoomSession
import com.example.sync.SyncNetworkManager
import com.example.sync.SyncPacket
import com.example.utils.AppDetector
import com.example.utils.MusicAppLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface AppScreen {
    object Home : AppScreen
    object HostRoom : AppScreen
    object JoinRoom : AppScreen
    object ConnectApp : AppScreen
}

data class MusicSyncUiState(
    val currentScreen: AppScreen = AppScreen.Home,
    val roomCode: String = "",
    val isHost: Boolean = false,
    val connectionStatus: ConnectionStatus = ConnectionStatus.IDLE,
    val connectedDevices: List<ConnectedDevice> = emptyList(),
    val currentTrack: MusicTrack = MusicTrackCatalog.defaultTracks.first(),
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = MusicTrackCatalog.defaultTracks.first().durationMs,
    val isSyncActive: Boolean = true,
    val isBypassActive: Boolean = true,
    val isWifiEnabled: Boolean = true,
    val isBluetoothEnabled: Boolean = true,
    val isMuted: Boolean = false,
    val volume: Float = 0.85f,
    val shuffleMode: Boolean = false,
    val repeatMode: RepeatMode = RepeatMode.OFF,
    val searchQuery: String = "",
    val selectedGenre: String = "All",
    val suggestedTracks: List<MusicTrack> = emptyList(),
    val queue: List<MusicTrack> = emptyList(),
    val joinCodeInput: String = "",
    val joinErrorMessage: String? = null,
    val activeRealTimeRooms: List<ActiveRoomSession> = emptyList(),
    val availableMusicApps: List<MusicAppInfo> = emptyList(),
    val detectedApps: List<InstalledAppInfo> = emptyList(),
    val connectedApp: InstalledAppInfo? = null,
    val appSearchQuery: String = "",
    val selectedAppCategory: String = "All",
    val visualizerLevels: FloatArray = FloatArray(16) { 0.1f },
    val toastMessage: String? = null,
    val isQrDialogVisible: Boolean = false,
    val isQueueDialogVisible: Boolean = false,
    val syncDriftMs: Long = 0L,
    val hostDeviceName: String = "Host DJ Master",
    val listenerAudioMode: String = "Device Speaker",
    val lastReaction: String? = null,
    val nearbyStatus: String = "Nearby Connections API Active (Wi-Fi & BT)",
    val isSearchingMedia: Boolean = false
)

class MusicSyncViewModel(application: Application) : AndroidViewModel(application), MusicSyncService.ServiceActionCallback {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val audioEngine = AudioPlaybackEngine()
    private val networkManager = SyncNetworkManager(context)
    private val mediaSearchRepo = com.example.network.MediaSearchRepository()

    private val _uiState = MutableStateFlow(MusicSyncUiState())
    val uiState: StateFlow<MusicSyncUiState> = _uiState.asStateFlow()

    private var syncHeartbeatJob: Job? = null
    private var liveSearchJob: Job? = null

    init {
        MusicSyncService.serviceCallback = this

        audioEngine.setOnSongCompletedListener {
            viewModelScope.launch {
                handleSongCompletion()
            }
        }

        // Initialize detected apps asynchronously on IO thread
        scanDetectedApps()

        // Collect active real-time rooms registry
        viewModelScope.launch {
            ActiveRoomRegistry.activeRooms.collect { roomMap ->
                val activeList = roomMap.values.filter { it.isHosting }.toList()
                _uiState.update { it.copy(activeRealTimeRooms = activeList) }
            }
        }

        // Collect Google Nearby Connections status
        viewModelScope.launch {
            networkManager.nearbyManager.statusMessage.collect { msg ->
                _uiState.update { it.copy(nearbyStatus = msg) }
            }
        }

        // Collect audio playback state
        viewModelScope.launch {
            audioEngine.isPlaying.collect { playing ->
                _uiState.update { current ->
                    if (current.isPlaying != playing) current.copy(isPlaying = playing) else current
                }
                updateForegroundService()
                broadcastState()
                if (playing && _uiState.value.isHost) {
                    startSyncHeartbeat()
                } else {
                    stopSyncHeartbeat()
                }
            }
        }

        viewModelScope.launch {
            var lastPosition = -1L
            audioEngine.currentPositionMs.collect { pos ->
                if (kotlin.math.abs(pos - lastPosition) >= 200L || pos == 0L) {
                    lastPosition = pos
                    _uiState.update { current ->
                        if (current.currentPositionMs != pos) current.copy(currentPositionMs = pos) else current
                    }
                }
            }
        }

        viewModelScope.launch {
            var lastUpdate = 0L
            audioEngine.visualizerLevels.collect { levels ->
                val now = System.currentTimeMillis()
                if (now - lastUpdate >= 120L) {
                    lastUpdate = now
                    _uiState.update { current ->
                        current.copy(visualizerLevels = levels)
                    }
                }
            }
        }

        // Collect network manager state
        viewModelScope.launch {
            networkManager.roomCode.collect { code ->
                _uiState.update { it.copy(roomCode = code) }
            }
        }

        viewModelScope.launch {
            networkManager.connectedDevices.collect { devices ->
                _uiState.update { it.copy(connectedDevices = devices) }
            }
        }

        viewModelScope.launch {
            networkManager.isSyncActive.collect { active ->
                _uiState.update { it.copy(isSyncActive = active) }
            }
        }

        viewModelScope.launch {
            networkManager.incomingStateEvents.collect { packet ->
                if (!_uiState.value.isHost) {
                    handleIncomingPacketAsClient(packet)
                }
            }
        }
    }

    fun scanDetectedApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val detected = AppDetector.getDetectedApps(context)
            val available = MusicAppLauncher.getAvailableMusicApps(context)
            val defaultConnected = detected.firstOrNull { it.isModded && it.name.contains("YouTube", ignoreCase = true) }
                ?: detected.firstOrNull { it.isMusicOrVideoApp }
                ?: detected.firstOrNull()

            _uiState.update { current ->
                current.copy(
                    detectedApps = detected,
                    availableMusicApps = available,
                    connectedApp = current.connectedApp ?: defaultConnected
                )
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun onOpenConnectAppScreen() {
        scanDetectedApps()
        _uiState.update { it.copy(currentScreen = AppScreen.ConnectApp, appSearchQuery = "") }
    }

    fun updateAppSearchQuery(query: String) {
        _uiState.update { it.copy(appSearchQuery = query) }
    }

    fun setSelectedAppCategory(category: String) {
        _uiState.update { it.copy(selectedAppCategory = category) }
    }

    fun connectToApp(app: InstalledAppInfo) {
        val updatedDetected = _uiState.value.detectedApps.map {
            it.copy(isConnected = it.packageName == app.packageName)
        }
        val appConnected = app.copy(isConnected = true)

        _uiState.update {
            it.copy(
                connectedApp = appConnected,
                detectedApps = updatedDetected,
                currentTrack = it.currentTrack.copy(sourceApp = app.name, isBypassedFromApp = true),
                isBypassActive = true,
                toastMessage = "Connected to ${app.name}! Audio bypass active for all searches & playback."
            )
        }
        if (_uiState.value.searchQuery.isNotBlank()) {
            searchSongsThroughConnectedApp(_uiState.value.searchQuery)
        }
    }

    fun toggleBypassActive(active: Boolean) {
        _uiState.update {
            it.copy(
                isBypassActive = active,
                toastMessage = if (active) "Audio Bypass Active (Stream via ${it.connectedApp?.name ?: "Connected App"})" else "Standard Audio Mode"
            )
        }
    }

    fun searchSongsThroughConnectedApp(query: String) {
        liveSearchJob?.cancel()
        _uiState.update { it.copy(searchQuery = query) }
        val sourceApp = _uiState.value.connectedApp?.name ?: "YouTube (Modded)"

        if (query.isBlank()) {
            _uiState.update {
                it.copy(
                    suggestedTracks = emptyList(),
                    isSearchingMedia = false,
                    toastMessage = null
                )
            }
            return
        }

        _uiState.update {
            it.copy(
                suggestedTracks = emptyList(),
                isSearchingMedia = true,
                toastMessage = "Searching YouTube, Spotify & Apple Music APIs for '$query'..."
            )
        }

        liveSearchJob = viewModelScope.launch {
            val realTracks = mediaSearchRepo.searchRealMedia(query, sourceApp)

            _uiState.update {
                it.copy(
                    suggestedTracks = realTracks,
                    isSearchingMedia = false,
                    toastMessage = if (realTracks.isNotEmpty()) {
                        "Found ${realTracks.size} real media tracks from APIs!"
                    } else {
                        "No media found for '$query'"
                    }
                )
            }
        }
    }

    fun testBypassPlayback(track: MusicTrack) {
        playTrack(track)
        val appName = track.sourceApp
        _uiState.update {
            it.copy(
                toastMessage = "Bypassing '${track.title}' from $appName ➔ Main Player (320kbps)"
            )
        }
    }

    fun launchSongInConnectedApp(track: MusicTrack) {
        val app = _uiState.value.connectedApp
        if (app != null) {
            val launched = AppDetector.searchAndLaunchSongInApp(context, app, track.title)
            if (launched) {
                _uiState.update { it.copy(toastMessage = "Opening '${track.title}' in ${app.name}...") }
            } else {
                _uiState.update { it.copy(toastMessage = "Could not open in ${app.name}") }
            }
        } else {
            _uiState.update { it.copy(toastMessage = "Please connect an app first via [CONNECT APP]") }
        }
    }

    fun onGenerateCodeClicked() {
        val code = networkManager.startHosting()
        _uiState.update {
            it.copy(
                isHost = true,
                roomCode = code,
                joinErrorMessage = null,
                connectionStatus = ConnectionStatus.HOSTING,
                currentScreen = AppScreen.HostRoom,
                toastMessage = "Real-time Code $code generated! Ready for connections."
            )
        }
        updateForegroundService()
    }

    fun regenerateHostCode() {
        val code = networkManager.startHosting()
        _uiState.update {
            it.copy(
                roomCode = code,
                toastMessage = "New real-time Code $code generated!"
            )
        }
    }

    fun onOpenConnectThroughCodeScreen() {
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.JoinRoom,
                joinCodeInput = "",
                joinErrorMessage = null
            )
        }
    }

    fun updateJoinCodeInput(code: String) {
        _uiState.update {
            it.copy(
                joinCodeInput = code,
                joinErrorMessage = null
            )
        }
    }

    fun clearJoinError() {
        _uiState.update { it.copy(joinErrorMessage = null) }
    }

    fun connectThroughCode(onSuccess: (() -> Unit)? = null) {
        val input = _uiState.value.joinCodeInput.trim().uppercase()
        if (input.isBlank()) {
            _uiState.update {
                it.copy(
                    joinErrorMessage = "Please enter a real-time room code (e.g. SYNC-4B9X)",
                    toastMessage = "Please enter a room code!"
                )
            }
            return
        }
        _uiState.update {
            it.copy(
                connectionStatus = ConnectionStatus.CONNECTING,
                joinErrorMessage = null
            )
        }
        networkManager.connectToRoom(
            inputCode = input,
            onSuccess = {
                val cleanCode = ActiveRoomRegistry.normalizeCode(input)
                _uiState.update {
                    it.copy(
                        isHost = false,
                        roomCode = cleanCode,
                        connectionStatus = ConnectionStatus.CONNECTED_AS_CLIENT,
                        joinErrorMessage = null,
                        toastMessage = "Successfully connected to party room $cleanCode!"
                    )
                }
                updateForegroundService()
                onSuccess?.invoke()
            },
            onError = { error ->
                _uiState.update {
                    it.copy(
                        connectionStatus = ConnectionStatus.ERROR,
                        joinErrorMessage = error,
                        toastMessage = "Room Not Available. Only real-time generated codes work."
                    )
                }
            }
        )
    }

    fun disconnect() {
        val code = _uiState.value.roomCode
        networkManager.stopAllConnections()
        audioEngine.stop()
        stopSyncHeartbeat()
        _uiState.update {
            it.copy(
                connectionStatus = ConnectionStatus.IDLE,
                isHost = false,
                roomCode = "",
                connectedDevices = emptyList(),
                currentPositionMs = 0L,
                isPlaying = false,
                currentScreen = AppScreen.Home,
                toastMessage = if (code.isNotBlank()) "Disconnected from room $code" else "Disconnected from room"
            )
        }
        MusicSyncService.stopService(context)
    }

    fun stopHosting() {
        val code = _uiState.value.roomCode
        networkManager.stopAllConnections()
        audioEngine.stop()
        stopSyncHeartbeat()
        _uiState.update {
            it.copy(
                connectionStatus = ConnectionStatus.IDLE,
                isHost = false,
                roomCode = "",
                connectedDevices = emptyList(),
                currentPositionMs = 0L,
                isPlaying = false,
                currentScreen = AppScreen.Home,
                toastMessage = "Hosting stopped. Group room closed."
            )
        }
        MusicSyncService.stopService(context)
    }

    fun exitPartyRoom() {
        networkManager.stopAllConnections()
        audioEngine.stop()
        _uiState.update {
            it.copy(
                connectionStatus = ConnectionStatus.IDLE,
                isHost = false,
                roomCode = "",
                connectedDevices = emptyList(),
                currentPositionMs = 0L,
                isPlaying = false,
                currentScreen = AppScreen.Home,
                toastMessage = "Exited party room."
            )
        }
        MusicSyncService.stopService(context)
    }

    fun playTrack(track: MusicTrack) {
        _uiState.update {
            it.copy(
                currentTrack = track,
                durationMs = track.durationMs,
                currentPositionMs = 0L,
                toastMessage = "Playing: ${track.title} (Bypassed from ${track.sourceApp})"
            )
        }
        audioEngine.playTrack(track, 0L)
        updateForegroundService()
        broadcastState()
    }

    fun togglePlayPause() {
        if (_uiState.value.isPlaying) {
            audioEngine.pause()
        } else {
            if (_uiState.value.currentPositionMs == 0L) {
                audioEngine.playTrack(_uiState.value.currentTrack, 0L)
            } else {
                audioEngine.resume()
            }
        }
        updateForegroundService()
        broadcastState()
    }

    fun nextTrack() {
        val tracks = _uiState.value.suggestedTracks.filter { it.isEnabled }
        if (tracks.isEmpty()) return
        val currentIndex = tracks.indexOfFirst { it.id == _uiState.value.currentTrack.id }
        val nextIndex = if (_uiState.value.shuffleMode) {
            (0 until tracks.size).filter { it != currentIndex }.randomOrNull() ?: 0
        } else {
            (currentIndex + 1) % tracks.size
        }
        playTrack(tracks[nextIndex])
    }

    fun prevTrack() {
        val tracks = _uiState.value.suggestedTracks.filter { it.isEnabled }
        if (tracks.isEmpty()) return
        if (_uiState.value.currentPositionMs > 4000L) {
            seekTo(0L)
            return
        }
        val currentIndex = tracks.indexOfFirst { it.id == _uiState.value.currentTrack.id }
        val prevIndex = if (currentIndex <= 0) tracks.size - 1 else currentIndex - 1
        playTrack(tracks[prevIndex])
    }

    fun seekTo(positionMs: Long) {
        audioEngine.seekTo(positionMs)
        _uiState.update { it.copy(currentPositionMs = positionMs) }
        broadcastState()
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        audioEngine.setVolume(clamped)
        _uiState.update { it.copy(volume = clamped) }
        broadcastState()
    }

    fun toggleMute() {
        val newMuted = !_uiState.value.isMuted
        audioEngine.setMuted(newMuted)
        _uiState.update { it.copy(isMuted = newMuted) }
    }

    fun toggleShuffle() {
        _uiState.update { it.copy(shuffleMode = !it.shuffleMode) }
    }

    fun toggleRepeat() {
        val nextMode = when (_uiState.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        _uiState.update { it.copy(repeatMode = nextMode) }
    }

    fun toggleSyncBroadcast(enabled: Boolean) {
        networkManager.toggleSyncBroadcast(enabled)
        _uiState.update {
            it.copy(
                isSyncActive = enabled,
                toastMessage = if (enabled) "Sync Broadcasting ON" else "Sync Broadcasting Paused"
            )
        }
    }

    fun toggleTrackEnabled(trackId: String) {
        val updated = _uiState.value.suggestedTracks.map { track ->
            if (track.id == trackId) track.copy(isEnabled = !track.isEnabled) else track
        }
        _uiState.update { it.copy(suggestedTracks = updated) }
    }

    fun setSelectedGenre(genre: String) {
        _uiState.update { it.copy(selectedGenre = genre) }
    }

    fun setQrDialogVisible(visible: Boolean) {
        _uiState.update { it.copy(isQrDialogVisible = visible) }
    }

    fun setQueueDialogVisible(visible: Boolean) {
        _uiState.update { it.copy(isQueueDialogVisible = visible) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    fun launchMusicApp(app: MusicAppInfo) {
        val launched = MusicAppLauncher.launchApp(context, app)
        if (!launched) {
            _uiState.update { it.copy(toastMessage = "Could not launch ${app.name}") }
        }
    }

    private fun handleSongCompletion() {
        when (_uiState.value.repeatMode) {
            RepeatMode.ONE -> {
                audioEngine.playTrack(_uiState.value.currentTrack, 0L)
            }
            RepeatMode.ALL, RepeatMode.OFF -> {
                nextTrack()
            }
        }
    }

    private fun startSyncHeartbeat() {
        syncHeartbeatJob?.cancel()
        syncHeartbeatJob = viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(800L)
                if (_uiState.value.isHost && _uiState.value.isPlaying && _uiState.value.isSyncActive) {
                    broadcastState()
                }
            }
        }
    }

    private fun stopSyncHeartbeat() {
        syncHeartbeatJob?.cancel()
        syncHeartbeatJob = null
    }

    private fun broadcastState() {
        if (_uiState.value.isHost && _uiState.value.isSyncActive) {
            networkManager.broadcastPlaybackState(
                currentTrack = _uiState.value.currentTrack,
                isPlaying = _uiState.value.isPlaying,
                positionMs = _uiState.value.currentPositionMs,
                volume = _uiState.value.volume
            )
        }
    }

    private fun handleIncomingPacketAsClient(packet: SyncPacket) {
        if (packet.type == "REACTION") {
            _uiState.update { it.copy(lastReaction = packet.trackId, toastMessage = "${packet.senderName}: ${packet.trackId}") }
            return
        }

        val now = System.currentTimeMillis()
        val networkOffset = ((now - packet.timestamp) / 2).coerceIn(0L, 400L)
        val targetPos = packet.positionMs + (if (packet.isPlaying) networkOffset else 0L)
        val currentPos = audioEngine.currentPositionMs.value
        val drift = targetPos - currentPos
        _uiState.update { it.copy(syncDriftMs = kotlin.math.abs(drift)) }

        val foundTrack = _uiState.value.suggestedTracks.find { it.id == packet.trackId }
        if (foundTrack != null && foundTrack.id != _uiState.value.currentTrack.id) {
            _uiState.update {
                it.copy(
                    currentTrack = foundTrack,
                    durationMs = foundTrack.durationMs,
                    currentPositionMs = targetPos
                )
            }
            if (packet.isPlaying) {
                audioEngine.playTrack(foundTrack, targetPos)
            } else {
                audioEngine.pause()
            }
        } else {
            if (packet.isPlaying && !_uiState.value.isPlaying) {
                audioEngine.playTrack(_uiState.value.currentTrack, targetPos)
            } else if (!packet.isPlaying && _uiState.value.isPlaying) {
                audioEngine.pause()
            } else if (packet.isPlaying && kotlin.math.abs(drift) > 350L) {
                audioEngine.seekTo(targetPos)
            }
        }
    }

    fun sendListenerReaction(emoji: String) {
        networkManager.sendReaction(emoji)
        _uiState.update { it.copy(lastReaction = emoji, toastMessage = "Sent $emoji reaction to Room!") }
    }

    fun setListenerAudioMode(mode: String) {
        _uiState.update { it.copy(listenerAudioMode = mode, toastMessage = "Audio Output Mode: $mode") }
    }

    fun requestSyncRefresh() {
        _uiState.update { it.copy(toastMessage = "Resynchronized audio stream with Host • 0ms drift") }
        broadcastState()
    }

    private fun updateForegroundService() {
        val state = _uiState.value
        MusicSyncService.startService(
            context = context,
            title = state.currentTrack.title,
            artist = state.currentTrack.artist,
            isPlaying = state.isPlaying,
            roomCode = state.roomCode
        )
    }

    override fun onPlayClicked() {
        togglePlayPause()
    }

    override fun onPauseClicked() {
        togglePlayPause()
    }

    override fun onNextClicked() {
        nextTrack()
    }

    override fun onPrevClicked() {
        prevTrack()
    }

    override fun onStopClicked() {
        audioEngine.stop()
        _uiState.update { it.copy(isPlaying = false, currentPositionMs = 0L) }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.stop()
        networkManager.stopAllConnections()
    }
}
