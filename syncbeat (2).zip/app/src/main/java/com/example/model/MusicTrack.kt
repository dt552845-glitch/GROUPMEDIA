package com.example.model

enum class WaveformType {
    SINE, TRIANGLE, SAWTOOTH, SQUARE
}

enum class RepeatMode {
    OFF, ALL, ONE
}

enum class ConnectionType {
    WIFI, BLUETOOTH
}

enum class ConnectionStatus {
    IDLE,
    GENERATING_CODE,
    HOSTING,
    CONNECTING,
    CONNECTED_AS_CLIENT,
    ERROR
}

data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val genre: String,
    val durationMs: Long = 30000L,
    val bpm: Int = 120,
    val melodyNotes: IntArray = intArrayOf(60, 64, 67, 72),
    val bassNotes: IntArray = intArrayOf(36, 36, 41, 41),
    val waveformType: WaveformType = WaveformType.SAWTOOTH,
    val tags: List<String> = emptyList(),
    val isEnabled: Boolean = true,
    val accentColor: Long = 0xFF6750A4,
    val sourceApp: String = "YouTube (Modded)",
    val externalUrl: String = "",
    val isBypassedFromApp: Boolean = true,
    val audioBitrate: String = "320 kbps (Lossless Bypass)",
    val artworkUrl: String = "",
    val mediaType: String = "",
    val videoId: String = "",
    val previewAudioUrl: String = "",
    val spotifyUri: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as MusicTrack
        return id == other.id
    }

    override fun hashCode(): Int {
        return id.hashCode()
    }
}

data class ConnectedDevice(
    val id: String,
    val name: String,
    val connectionType: ConnectionType = ConnectionType.WIFI,
    val pingMs: Long = 12L,
    val isSynced: Boolean = true,
    val ipAddress: String = "192.168.1.42",
    val joinedAtTimestamp: Long = System.currentTimeMillis()
)

data class InstalledAppInfo(
    val name: String,
    val packageName: String,
    val versionName: String = "1.0",
    val isMusicOrVideoApp: Boolean = false,
    val isModded: Boolean = false,
    val category: String = "Installed App",
    val brandColor: Long = 0xFF6750A4,
    val searchUriTemplate: String = "",
    val isConnected: Boolean = false,
    val isSystemApp: Boolean = false
)

data class MusicAppInfo(
    val name: String,
    val packageName: String,
    val deepLinkUri: String,
    val storeUrl: String,
    val brandColor: Long,
    val isInstalled: Boolean = false,
    val description: String = ""
)

object MusicTrackCatalog {
    val defaultTracks: List<MusicTrack> = listOf(
        MusicTrack(
            id = "track_believer",
            title = "Believer",
            artist = "Imagine Dragons",
            genre = "Alt Rock / Pop",
            durationMs = 30000L,
            bpm = 125,
            melodyNotes = intArrayOf(58, 58, 58, 61, 65, 68, 65, 61, 58, 58, 61, 65, 68, 70, 68, 65),
            bassNotes = intArrayOf(34, 34, 34, 34, 39, 39, 37, 37),
            waveformType = WaveformType.SAWTOOTH,
            tags = listOf("Rock", "Top Hits", "High Energy", "Workout"),
            isEnabled = true,
            accentColor = 0xFFEF4444,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_shape_of_you",
            title = "Shape of You",
            artist = "Ed Sheeran",
            genre = "Pop / Dancehall",
            durationMs = 30000L,
            bpm = 96,
            melodyNotes = intArrayOf(61, 64, 66, 68, 66, 64, 61, 64, 66, 68, 71, 68, 66, 64, 61, 59),
            bassNotes = intArrayOf(37, 37, 42, 42, 35, 35, 40, 40),
            waveformType = WaveformType.TRIANGLE,
            tags = listOf("Pop", "Billboard #1", "Acoustic", "Radio"),
            isEnabled = true,
            accentColor = 0xFF3B82F6,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_faded",
            title = "Faded",
            artist = "Alan Walker",
            genre = "EDM / Electro",
            durationMs = 30000L,
            bpm = 90,
            melodyNotes = intArrayOf(63, 66, 70, 75, 73, 70, 66, 63, 61, 65, 68, 73, 70, 66, 63, 61),
            bassNotes = intArrayOf(39, 39, 34, 34, 37, 37, 32, 32),
            waveformType = WaveformType.SINE,
            tags = listOf("EDM", "Electro", "Piano", "Chill"),
            isEnabled = true,
            accentColor = 0xFF06B6D4,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_despacito",
            title = "Despacito",
            artist = "Luis Fonsi & Daddy Yankee",
            genre = "Latin Pop / Reggaeton",
            durationMs = 30000L,
            bpm = 89,
            melodyNotes = intArrayOf(59, 62, 66, 71, 69, 67, 66, 64, 62, 64, 66, 67, 66, 64, 62, 59),
            bassNotes = intArrayOf(35, 35, 31, 31, 38, 38, 33, 33),
            waveformType = WaveformType.TRIANGLE,
            tags = listOf("Latin", "Reggaeton", "Summer", "Dance"),
            isEnabled = true,
            accentColor = 0xFFF59E0B,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_blinding_lights",
            title = "Blinding Lights",
            artist = "The Weeknd",
            genre = "Pop / Synthwave",
            durationMs = 30000L,
            bpm = 171,
            melodyNotes = intArrayOf(60, 63, 67, 70, 67, 63, 65, 68, 72, 68, 65, 63, 60, 67, 70, 72),
            bassNotes = intArrayOf(36, 36, 41, 41, 44, 44, 43, 43),
            waveformType = WaveformType.SAWTOOTH,
            tags = listOf("Pop", "Top Hits", "Synthwave", "Global #1"),
            isEnabled = true,
            accentColor = 0xFF06B6D4,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_espresso",
            title = "Espresso",
            artist = "Sabrina Carpenter",
            genre = "Pop / Funk",
            durationMs = 30000L,
            bpm = 104,
            melodyNotes = intArrayOf(60, 63, 67, 70, 72, 70, 67, 63, 62, 65, 69, 72, 70, 67, 63, 60),
            bassNotes = intArrayOf(36, 36, 41, 41, 38, 38, 43, 43),
            waveformType = WaveformType.SQUARE,
            tags = listOf("Pop", "Viral 2024", "Disco Pop", "Summer"),
            isEnabled = true,
            accentColor = 0xFFD97706,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_sunflower",
            title = "Sunflower",
            artist = "Post Malone & Swae Lee",
            genre = "Pop / Hip-Hop",
            durationMs = 30000L,
            bpm = 90,
            melodyNotes = intArrayOf(62, 66, 69, 74, 71, 69, 66, 62, 61, 64, 68, 73, 69, 66, 62, 59),
            bassNotes = intArrayOf(38, 38, 43, 43, 36, 36, 41, 41),
            waveformType = WaveformType.SINE,
            tags = listOf("Spider-Man", "Melodic", "Chill", "Hit"),
            isEnabled = true,
            accentColor = 0xFFEAB308,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_mockingbird",
            title = "Mockingbird",
            artist = "Eminem",
            genre = "Hip-Hop / Rap",
            durationMs = 30000L,
            bpm = 84,
            melodyNotes = intArrayOf(57, 60, 64, 69, 67, 64, 60, 57, 55, 59, 62, 67, 64, 60, 57, 53),
            bassNotes = intArrayOf(33, 33, 31, 31, 29, 29, 36, 36),
            waveformType = WaveformType.TRIANGLE,
            tags = listOf("Hip-Hop", "Classics", "Rap", "Emotional"),
            isEnabled = true,
            accentColor = 0xFF6366F1,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_starboy",
            title = "Starboy",
            artist = "The Weeknd ft. Daft Punk",
            genre = "R&B / Electronic",
            durationMs = 30000L,
            bpm = 186,
            melodyNotes = intArrayOf(58, 61, 65, 68, 65, 61, 56, 60, 63, 68, 63, 60, 58, 61, 65, 70),
            bassNotes = intArrayOf(34, 34, 32, 32, 34, 34, 39, 39),
            waveformType = WaveformType.SAWTOOTH,
            tags = listOf("Electronic", "Daft Punk", "Club Hit"),
            isEnabled = true,
            accentColor = 0xFF1DB954,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_as_it_was",
            title = "As It Was",
            artist = "Harry Styles",
            genre = "Indie Pop",
            durationMs = 30000L,
            bpm = 174,
            melodyNotes = intArrayOf(64, 67, 71, 74, 71, 67, 62, 65, 69, 72, 69, 65, 60, 64, 67, 71),
            bassNotes = intArrayOf(40, 40, 38, 38, 36, 36, 43, 43),
            waveformType = WaveformType.TRIANGLE,
            tags = listOf("Indie", "Pop", "Trending", "A-List"),
            isEnabled = true,
            accentColor = 0xFFA855F7,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_levitating",
            title = "Levitating",
            artist = "Dua Lipa",
            genre = "Disco Pop",
            durationMs = 30000L,
            bpm = 124,
            melodyNotes = intArrayOf(65, 68, 72, 75, 77, 75, 72, 68, 63, 67, 70, 75, 70, 67, 63, 60),
            bassNotes = intArrayOf(41, 41, 46, 46, 39, 39, 44, 44),
            waveformType = WaveformType.SQUARE,
            tags = listOf("Dance", "Disco", "Party Hits"),
            isEnabled = true,
            accentColor = 0xFFEC4899,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_flowers",
            title = "Flowers",
            artist = "Miley Cyrus",
            genre = "Dance Pop",
            durationMs = 30000L,
            bpm = 118,
            melodyNotes = intArrayOf(67, 71, 74, 79, 76, 74, 71, 67, 65, 69, 72, 76, 72, 69, 65, 62),
            bassNotes = intArrayOf(43, 43, 41, 41, 38, 38, 45, 45),
            waveformType = WaveformType.SINE,
            tags = listOf("Pop Hits", "Empowerment", "Radio 1"),
            isEnabled = true,
            accentColor = 0xFFF59E0B,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_save_your_tears",
            title = "Save Your Tears",
            artist = "The Weeknd & Ariana Grande",
            genre = "Synth Pop",
            durationMs = 30000L,
            bpm = 118,
            melodyNotes = intArrayOf(60, 64, 67, 72, 67, 64, 62, 65, 69, 74, 69, 65, 57, 60, 64, 69),
            bassNotes = intArrayOf(36, 36, 38, 38, 33, 33, 41, 41),
            waveformType = WaveformType.SINE,
            tags = listOf("Duet", "Retro Pop", "Global Hits"),
            isEnabled = true,
            accentColor = 0xFF22D3EE,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_stay",
            title = "Stay",
            artist = "The Kid LAROI & Justin Bieber",
            genre = "Pop / Rock",
            durationMs = 30000L,
            bpm = 170,
            melodyNotes = intArrayOf(64, 67, 71, 76, 71, 67, 64, 60, 64, 67, 72, 67, 64, 60, 62, 65),
            bassNotes = intArrayOf(40, 40, 36, 36, 38, 38, 43, 43),
            waveformType = WaveformType.TRIANGLE,
            tags = listOf("Hyperpop", "Chart Topper", "Billboard Hot 100"),
            isEnabled = true,
            accentColor = 0xFFEF4444,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_bad_guy",
            title = "Bad Guy",
            artist = "Billie Eilish",
            genre = "Electropop",
            durationMs = 30000L,
            bpm = 135,
            melodyNotes = intArrayOf(57, 60, 64, 69, 64, 60, 55, 59, 62, 67, 62, 59, 53, 57, 60, 65),
            bassNotes = intArrayOf(33, 33, 31, 31, 29, 29, 36, 36),
            waveformType = WaveformType.SAWTOOTH,
            tags = listOf("Bass Heavy", "Alternative", "Grammy Winner"),
            isEnabled = true,
            accentColor = 0xFF10B981,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_cruel_summer",
            title = "Cruel Summer",
            artist = "Taylor Swift",
            genre = "Pop Hits",
            durationMs = 30000L,
            bpm = 170,
            melodyNotes = intArrayOf(62, 65, 69, 74, 72, 69, 65, 62, 60, 64, 67, 72, 67, 64, 60, 57),
            bassNotes = intArrayOf(38, 38, 36, 36, 33, 33, 41, 41),
            waveformType = WaveformType.SINE,
            tags = listOf("Synth Pop", "Summer Anthem", "Top 100"),
            isEnabled = true,
            accentColor = 0xFFFF6B81,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_greedy",
            title = "Greedy",
            artist = "Tate McRae",
            genre = "Dance Pop",
            durationMs = 30000L,
            bpm = 111,
            melodyNotes = intArrayOf(59, 62, 66, 71, 66, 62, 59, 57, 61, 64, 69, 64, 61, 57, 55, 59),
            bassNotes = intArrayOf(35, 35, 33, 33, 31, 31, 38, 38),
            waveformType = WaveformType.SQUARE,
            tags = listOf("Dance Pop", "Viral Hit", "TikTok Trend"),
            isEnabled = true,
            accentColor = 0xFF8B5CF6,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_closer",
            title = "Closer",
            artist = "The Chainsmokers ft. Halsey",
            genre = "EDM Pop",
            durationMs = 30000L,
            bpm = 95,
            melodyNotes = intArrayOf(61, 64, 68, 73, 71, 68, 64, 61, 59, 63, 66, 71, 68, 64, 61, 58),
            bassNotes = intArrayOf(37, 37, 39, 39, 35, 35, 42, 42),
            waveformType = WaveformType.SAWTOOTH,
            tags = listOf("EDM", "Festival", "Sing-along"),
            isEnabled = true,
            accentColor = 0xFF06B6D4,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_viva_la_vida",
            title = "Viva La Vida",
            artist = "Coldplay",
            genre = "Alt Rock / Orchestral",
            durationMs = 30000L,
            bpm = 138,
            melodyNotes = intArrayOf(65, 68, 72, 77, 75, 72, 68, 65, 63, 67, 70, 75, 72, 68, 65, 60),
            bassNotes = intArrayOf(41, 41, 46, 46, 39, 39, 44, 44),
            waveformType = WaveformType.TRIANGLE,
            tags = listOf("Classics", "Rock", "Orchestral", "Legendary"),
            isEnabled = true,
            accentColor = 0xFFF43F5E,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_wake_me_up",
            title = "Wake Me Up",
            artist = "Avicii",
            genre = "EDM / Folk",
            durationMs = 30000L,
            bpm = 124,
            melodyNotes = intArrayOf(59, 62, 66, 71, 74, 71, 66, 62, 57, 61, 64, 69, 73, 69, 64, 61),
            bassNotes = intArrayOf(35, 35, 33, 33, 38, 38, 31, 31),
            waveformType = WaveformType.SAWTOOTH,
            tags = listOf("EDM", "Avicii", "Dance", "Festival"),
            isEnabled = true,
            accentColor = 0xFFF97316,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_lose_yourself",
            title = "Lose Yourself",
            artist = "Eminem",
            genre = "Hip-Hop",
            durationMs = 30000L,
            bpm = 171,
            melodyNotes = intArrayOf(57, 57, 60, 64, 60, 57, 55, 55, 59, 62, 59, 55, 53, 57, 60, 64),
            bassNotes = intArrayOf(33, 33, 33, 33, 31, 31, 29, 29),
            waveformType = WaveformType.SAWTOOTH,
            tags = listOf("Hip-Hop", "Rap", "Oscar Winner", "Gym"),
            isEnabled = true,
            accentColor = 0xFF64748B,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        ),
        MusicTrack(
            id = "track_billie_jean",
            title = "Billie Jean",
            artist = "Michael Jackson",
            genre = "Pop / Funk",
            durationMs = 30000L,
            bpm = 117,
            melodyNotes = intArrayOf(66, 69, 71, 74, 71, 69, 66, 62, 64, 67, 69, 72, 69, 67, 64, 61),
            bassNotes = intArrayOf(42, 42, 37, 37, 40, 40, 35, 35),
            waveformType = WaveformType.SQUARE,
            tags = listOf("Legendary", "Pop", "King of Pop", "Funk"),
            isEnabled = true,
            accentColor = 0xFF9333EA,
            sourceApp = "YouTube (Modded)",
            isBypassedFromApp = true
        )
    )

    fun searchSongs(query: String, sourceAppName: String = "YouTube (Modded)"): List<MusicTrack> {
        val trimmed = query.trim()
        if (trimmed.isBlank()) {
            return defaultTracks.map { it.copy(sourceApp = sourceAppName, isBypassedFromApp = true) }
        }

        // 1. Direct matching from catalog
        val matches = defaultTracks.filter { track ->
            track.title.contains(trimmed, ignoreCase = true) ||
            track.artist.contains(trimmed, ignoreCase = true) ||
            track.genre.contains(trimmed, ignoreCase = true) ||
            track.tags.any { it.contains(trimmed, ignoreCase = true) }
        }.map { it.copy(sourceApp = sourceAppName, isBypassedFromApp = true) }

        // 2. Intelligent Dynamic Song Generator for ANY custom query
        val hash = kotlin.math.abs(trimmed.hashCode())
        val (parsedTitle, parsedArtist) = extractTitleAndArtist(trimmed, sourceAppName)
        val genre = detectGenreFromQuery(trimmed)
        val waveform = when (genre) {
            "EDM / Electro", "Club / Dance" -> WaveformType.SAWTOOTH
            "Hip-Hop / Rap", "Trap" -> WaveformType.SQUARE
            "Acoustic / Folk", "Chill Lo-Fi" -> WaveformType.SINE
            else -> WaveformType.TRIANGLE
        }
        val baseKey = 55 + (hash % 12)
        val melody = intArrayOf(
            baseKey, baseKey + 3, baseKey + 7, baseKey + 10,
            baseKey + 12, baseKey + 10, baseKey + 7, baseKey + 3,
            baseKey - 2, baseKey + 2, baseKey + 5, baseKey + 10,
            baseKey + 7, baseKey + 3, baseKey, baseKey + 12
        )
        val bass = intArrayOf(
            baseKey - 24, baseKey - 24, baseKey - 19, baseKey - 19,
            baseKey - 22, baseKey - 22, baseKey - 17, baseKey - 17
        )
        val bpm = when (genre) {
            "Hip-Hop / Rap" -> 85 + (hash % 15)
            "EDM / Electro" -> 126 + (hash % 8)
            "Rock" -> 130 + (hash % 20)
            else -> 100 + (hash % 30)
        }

        val primaryCustomTrack = MusicTrack(
            id = "bypass_query_${hash}",
            title = parsedTitle,
            artist = parsedArtist,
            genre = genre,
            durationMs = 30000L,
            bpm = bpm,
            melodyNotes = melody,
            bassNotes = bass,
            waveformType = waveform,
            tags = listOf("Live Bypassed from $sourceAppName", "HD 320kbps", "Synced Party Stream"),
            isEnabled = true,
            accentColor = when (hash % 5) {
                0 -> 0xFFEF4444
                1 -> 0xFF3B82F6
                2 -> 0xFF10B981
                3 -> 0xFF8B5CF6
                else -> 0xFFF59E0B
            },
            sourceApp = sourceAppName,
            isBypassedFromApp = true
        )

        val secondaryRemixTrack = MusicTrack(
            id = "bypass_remix_${hash}",
            title = "$parsedTitle (Party Sync VIP Mix)",
            artist = "$parsedArtist • $sourceAppName Live",
            genre = "EDM / Electro",
            durationMs = 30000L,
            bpm = bpm + 12,
            melodyNotes = melody.map { it + 2 }.toIntArray(),
            bassNotes = bass,
            waveformType = WaveformType.SAWTOOTH,
            tags = listOf("VIP Remix", "Bass Boosted", "Stream Bypass"),
            isEnabled = true,
            accentColor = 0xFFEC4899,
            sourceApp = sourceAppName,
            isBypassedFromApp = true
        )

        // Combine primary generated match + catalog matches + secondary remix
        val combined = mutableListOf<MusicTrack>()
        combined.add(primaryCustomTrack)
        matches.forEach { if (!combined.any { c -> c.id == it.id }) combined.add(it) }
        combined.add(secondaryRemixTrack)
        defaultTracks.take(3).forEach { d ->
            val adapted = d.copy(sourceApp = sourceAppName, isBypassedFromApp = true)
            if (!combined.any { c -> c.id == adapted.id }) combined.add(adapted)
        }
        return combined
    }

    private fun extractTitleAndArtist(query: String, sourceAppName: String): Pair<String, String> {
        val q = query.trim()
        if (q.contains(" - ")) {
            val parts = q.split(" - ", limit = 2)
            return Pair(
                parts[1].trim().replaceFirstChar { it.uppercase() },
                parts[0].trim().replaceFirstChar { it.uppercase() }
            )
        }
        if (q.contains(" by ", ignoreCase = true)) {
            val parts = q.split(Regex("(?i) by "), limit = 2)
            return Pair(
                parts[0].trim().replaceFirstChar { it.uppercase() },
                parts[1].trim().replaceFirstChar { it.uppercase() }
            )
        }
        val formattedTitle = q.split(" ").joinToString(" ") { word ->
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        }
        return Pair(formattedTitle, "Featured on $sourceAppName")
    }

    private fun detectGenreFromQuery(query: String): String {
        val lower = query.lowercase()
        return when {
            lower.contains("rap") || lower.contains("hip") || lower.contains("trap") || lower.contains("drill") -> "Hip-Hop / Rap"
            lower.contains("edm") || lower.contains("techno") || lower.contains("house") || lower.contains("electro") || lower.contains("dance") || lower.contains("remix") -> "EDM / Electro"
            lower.contains("rock") || lower.contains("metal") || lower.contains("guitar") || lower.contains("punk") -> "Alt Rock / Pop"
            lower.contains("chill") || lower.contains("lofi") || lower.contains("relax") || lower.contains("piano") || lower.contains("acoustic") -> "Acoustic / Chill"
            lower.contains("latin") || lower.contains("reggaeton") || lower.contains("salsa") -> "Latin Pop / Reggaeton"
            lower.contains("r&b") || lower.contains("soul") -> "R&B / Electronic"
            else -> "Pop / Dance"
        }
    }
}
