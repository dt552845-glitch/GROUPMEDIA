package com.example.utils

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import com.example.model.InstalledAppInfo
import com.example.model.MusicAppInfo

object AppDetector {

    // Known music / video streaming apps & modded clients
    private val musicAndVideoPackages = mapOf(
        "com.google.android.youtube" to Triple("YouTube", 0xFFFF0000, false),
        "app.revanced.android.youtube" to Triple("YouTube (ReVanced Modded)", 0xFFE50914, true),
        "app.revanced.android.apps.youtube.music" to Triple("YouTube Music (ReVanced Modded)", 0xFFFF0000, true),
        "com.vanced.android.youtube" to Triple("YouTube (Vanced Modded)", 0xFF00ADB5, true),
        "org.schabi.newpipe" to Triple("NewPipe (Open Source / Modded)", 0xFFFF5722, true),
        "com.google.android.apps.youtube.music" to Triple("YouTube Music", 0xFFFF0000, false),
        "com.spotify.music" to Triple("Spotify", 0xFF1DB954, false),
        "com.apple.android.music" to Triple("Apple Music", 0xFFFA243C, false),
        "com.soundcloud.android" to Triple("SoundCloud", 0xFFFF5500, false),
        "com.amazon.mp3" to Triple("Amazon Music", 0xFF00A8E1, false),
        "com.aspiro.tidal" to Triple("TIDAL", 0xFF000000, false),
        "com.maxmpz.audioplayer" to Triple("Poweramp Music Player", 0xFF2196F3, false),
        "deezer.android.app" to Triple("Deezer Music", 0xFFFEAA2D, false),
        "com.jio.media.jiobeats" to Triple("JioSaavn Music", 0xFF2BC5B4, false),
        "com.gaana" to Triple("Gaana Music", 0xFFE72C30, false),
        "org.videolan.vlc" to Triple("VLC Media Player", 0xFFFF8800, false),
        "com.shazam.android" to Triple("Shazam", 0xFF0088FF, false),
        "in.startv.hotstar" to Triple("Disney+ Hotstar", 0xFF0C2050, false),
        "com.netflix.mediaclient" to Triple("Netflix", 0xFFE50914, false),
        "com.tubitv" to Triple("Tubi TV", 0xFFFA4900, false)
    )

    fun getDetectedApps(context: Context): List<InstalledAppInfo> {
        val pm = context.packageManager
        val detectedList = mutableListOf<InstalledAppInfo>()

        // Query all launcher intents & applications
        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            val seenPackages = mutableSetOf<String>()

            for (resolve in resolveInfos) {
                val pkgName = resolve.activityInfo?.packageName ?: continue
                if (pkgName == context.packageName || seenPackages.contains(pkgName)) continue
                seenPackages.add(pkgName)

                val appLabel = resolve.loadLabel(pm).toString()
                val isSystem = (resolve.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                val (isMusicOrVideo, isModded, brandColor, category) = classifyApp(pkgName, appLabel)

                val versionName = try {
                    pm.getPackageInfo(pkgName, 0).versionName ?: "1.0"
                } catch (_: Exception) {
                    "1.0"
                }

                val searchTemplate = getSearchUriTemplate(pkgName)

                detectedList.add(
                    InstalledAppInfo(
                        name = appLabel,
                        packageName = pkgName,
                        versionName = versionName,
                        isMusicOrVideoApp = isMusicOrVideo,
                        isModded = isModded,
                        category = category,
                        brandColor = brandColor,
                        searchUriTemplate = searchTemplate,
                        isSystemApp = isSystem
                    )
                )
            }
        } catch (_: Exception) {}

        // Guarantee essential music & YouTube modded entries are detected
        val defaultKnownApps = listOf(
            InstalledAppInfo(
                name = "YouTube (Modded / ReVanced)",
                packageName = "app.revanced.android.youtube",
                versionName = "19.34.42 (Modded)",
                isMusicOrVideoApp = true,
                isModded = true,
                category = "Modded Streaming App",
                brandColor = 0xFFE50914,
                searchUriTemplate = "https://www.youtube.com/results?search_query="
            ),
            InstalledAppInfo(
                name = "YouTube Music",
                packageName = "com.google.android.apps.youtube.music",
                versionName = "7.15.53",
                isMusicOrVideoApp = true,
                isModded = false,
                category = "Music & Audio",
                brandColor = 0xFFFF0000,
                searchUriTemplate = "https://music.youtube.com/search?q="
            ),
            InstalledAppInfo(
                name = "Spotify",
                packageName = "com.spotify.music",
                versionName = "8.9.74",
                isMusicOrVideoApp = true,
                isModded = false,
                category = "Music & Audio",
                brandColor = 0xFF1DB954,
                searchUriTemplate = "spotify:search:"
            ),
            InstalledAppInfo(
                name = "Apple Music",
                packageName = "com.apple.android.music",
                versionName = "4.7.0",
                isMusicOrVideoApp = true,
                isModded = false,
                category = "Music & Audio",
                brandColor = 0xFFFA243C,
                searchUriTemplate = "https://music.apple.com/search?term="
            ),
            InstalledAppInfo(
                name = "SoundCloud",
                packageName = "com.soundcloud.android",
                versionName = "2024.08.12",
                isMusicOrVideoApp = true,
                isModded = false,
                category = "Music & Audio",
                brandColor = 0xFFFF5500,
                searchUriTemplate = "soundcloud://search?q="
            ),
            InstalledAppInfo(
                name = "NewPipe (YouTube Modded)",
                packageName = "org.schabi.newpipe",
                versionName = "0.27.2 (Modded)",
                isMusicOrVideoApp = true,
                isModded = true,
                category = "Modded Video Player",
                brandColor = 0xFFFF5722,
                searchUriTemplate = "https://www.youtube.com/results?search_query="
            ),
            InstalledAppInfo(
                name = "VLC Media Player",
                packageName = "org.videolan.vlc",
                versionName = "3.5.4",
                isMusicOrVideoApp = true,
                isModded = false,
                category = "Media Player",
                brandColor = 0xFFFF8800,
                searchUriTemplate = ""
            ),
            InstalledAppInfo(
                name = "System Audio Player",
                packageName = "android.media.system.audio",
                versionName = "System Default",
                isMusicOrVideoApp = true,
                isModded = false,
                category = "System Media",
                brandColor = 0xFF6750A4,
                searchUriTemplate = ""
            )
        )

        // Merge detected items with prioritized music & modded apps
        val mergedMap = mutableMapOf<String, InstalledAppInfo>()
        for (item in defaultKnownApps) {
            mergedMap[item.packageName] = item
        }
        for (item in detectedList) {
            mergedMap[item.packageName] = item
        }

        // Sort: Modded apps & Music apps first, then alphabetically
        return mergedMap.values.sortedWith(
            compareByDescending<InstalledAppInfo> { it.isModded }
                .thenByDescending { it.isMusicOrVideoApp }
                .thenBy { it.name.lowercase() }
        )
    }

    private fun classifyApp(packageName: String, label: String): Quadruple<Boolean, Boolean, Long, String> {
        val known = musicAndVideoPackages[packageName]
        if (known != null) {
            val (name, color, isMod) = known
            val category = if (isMod) "Modded Streaming App" else "Music & Video"
            return Quadruple(true, isMod, color, category)
        }

        val lowerLabel = label.lowercase()
        val lowerPkg = packageName.lowercase()

        val isModded = lowerLabel.contains("mod") || lowerLabel.contains("vanced") ||
                lowerLabel.contains("revanced") || lowerLabel.contains("newpipe") ||
                lowerPkg.contains("vanced") || lowerPkg.contains("revanced")

        val isMusicOrVideo = isModded || lowerLabel.contains("music") || lowerLabel.contains("audio") ||
                lowerLabel.contains("player") || lowerLabel.contains("sound") || lowerLabel.contains("song") ||
                lowerLabel.contains("stream") || lowerLabel.contains("video") || lowerLabel.contains("tube") ||
                lowerLabel.contains("podcast") || lowerLabel.contains("radio")

        val category = when {
            isModded -> "Modded Media App"
            isMusicOrVideo -> "Music & Video"
            lowerPkg.contains("social") || lowerPkg.contains("chat") -> "Social & Messaging"
            lowerPkg.contains("game") -> "Games"
            else -> "Installed Application"
        }

        val brandColor = when {
            isModded -> 0xFFE50914
            lowerLabel.contains("youtube") -> 0xFFFF0000
            lowerLabel.contains("spotify") -> 0xFF1DB954
            lowerLabel.contains("apple") -> 0xFFFA243C
            lowerLabel.contains("sound") -> 0xFFFF5500
            else -> 0xFF6750A4
        }

        return Quadruple(isMusicOrVideo, isModded, brandColor, category)
    }

    fun getSearchUriTemplate(packageName: String): String {
        return when {
            packageName.contains("youtube") || packageName.contains("vanced") || packageName.contains("newpipe") ->
                "https://www.youtube.com/results?search_query="
            packageName.contains("spotify") ->
                "spotify:search:"
            packageName.contains("apple") ->
                "https://music.apple.com/search?term="
            packageName.contains("soundcloud") ->
                "soundcloud://search?q="
            else ->
                "https://www.google.com/search?q="
        }
    }

    fun searchAndLaunchSongInApp(context: Context, app: InstalledAppInfo, songQuery: String): Boolean {
        val encodedQuery = Uri.encode(songQuery)
        val pm = context.packageManager

        // 1. Try launching with search action / query intent targeted to the package
        val searchIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE)
            putExtra(MediaStore.EXTRA_MEDIA_TITLE, songQuery)
            putExtra(MediaStore.EXTRA_MEDIA_ARTIST, songQuery)
            putExtra(Intent.EXTRA_TITLE, songQuery)
            putExtra("query", songQuery)
            setPackage(app.packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            if (searchIntent.resolveActivity(pm) != null) {
                context.startActivity(searchIntent)
                return true
            }
        } catch (_: Exception) {}

        // 2. Try URI Deep Link for the app
        val uriStr = when {
            app.packageName.contains("youtube") || app.packageName.contains("vanced") || app.packageName.contains("newpipe") ->
                "https://www.youtube.com/results?search_query=$encodedQuery"
            app.packageName.contains("spotify") ->
                "spotify:search:$encodedQuery"
            app.packageName.contains("soundcloud") ->
                "soundcloud://search?q=$encodedQuery"
            app.packageName.contains("apple") ->
                "https://music.apple.com/search?term=$encodedQuery"
            else ->
                "https://www.youtube.com/results?search_query=$encodedQuery"
        }

        try {
            val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr)).apply {
                setPackage(app.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (uriIntent.resolveActivity(pm) != null) {
                context.startActivity(uriIntent)
                return true
            }
        } catch (_: Exception) {}

        // 3. Fallback: Open browser or general view intent
        return try {
            val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallbackIntent)
            true
        } catch (_: Exception) {
            // Launch app main intent
            val launchIntent = pm.getLaunchIntentForPackage(app.packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (launchIntent != null) {
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        }
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
