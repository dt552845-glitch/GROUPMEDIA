package com.example.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.example.model.MusicAppInfo

object MusicAppLauncher {

    private val supportedMusicApps = listOf(
        MusicAppInfo(
            name = "YouTube (Modded)",
            packageName = "app.revanced.android.youtube",
            deepLinkUri = "https://www.youtube.com",
            storeUrl = "https://revanced.app",
            brandColor = 0xFFE50914,
            description = "Ad-free background audio & video playback"
        ),
        MusicAppInfo(
            name = "YouTube Music",
            packageName = "com.google.android.apps.youtube.music",
            deepLinkUri = "https://music.youtube.com",
            storeUrl = "https://play.google.com/store/apps/details?id=com.google.android.apps.youtube.music",
            brandColor = 0xFFFF0000,
            description = "Official YouTube Music streaming library"
        ),
        MusicAppInfo(
            name = "Spotify",
            packageName = "com.spotify.music",
            deepLinkUri = "spotify:",
            storeUrl = "https://play.google.com/store/apps/details?id=com.spotify.music",
            brandColor = 0xFF1DB954,
            description = "Global music, podcasts and playlists"
        ),
        MusicAppInfo(
            name = "Apple Music",
            packageName = "com.apple.android.music",
            deepLinkUri = "https://music.apple.com",
            storeUrl = "https://play.google.com/store/apps/details?id=com.apple.android.music",
            brandColor = 0xFFFA243C,
            description = "High-fidelity lossless streaming"
        ),
        MusicAppInfo(
            name = "SoundCloud",
            packageName = "com.soundcloud.android",
            deepLinkUri = "soundcloud:",
            storeUrl = "https://play.google.com/store/apps/details?id=com.soundcloud.android",
            brandColor = 0xFFFF5500,
            description = "Independent tracks, remixes and DJ sets"
        ),
        MusicAppInfo(
            name = "NewPipe (Modded)",
            packageName = "org.schabi.newpipe",
            deepLinkUri = "https://www.youtube.com",
            storeUrl = "https://newpipe.net",
            brandColor = 0xFFFF5722,
            description = "Lightweight YouTube client without ads"
        ),
        MusicAppInfo(
            name = "Amazon Music",
            packageName = "com.amazon.mp3",
            deepLinkUri = "amznmp3:",
            storeUrl = "https://play.google.com/store/apps/details?id=com.amazon.mp3",
            brandColor = 0xFF00A8E1,
            description = "HD audio and curated playlists"
        ),
        MusicAppInfo(
            name = "VLC Media Player",
            packageName = "org.videolan.vlc",
            deepLinkUri = "vlc:",
            storeUrl = "https://play.google.com/store/apps/details?id=org.videolan.vlc",
            brandColor = 0xFFFF8800,
            description = "Universal local & network media playback"
        )
    )

    fun getAvailableMusicApps(context: Context): List<MusicAppInfo> {
        val pm = context.packageManager
        return supportedMusicApps.map { app ->
            val isInstalled = isPackageInstalled(pm, app.packageName)
            app.copy(isInstalled = isInstalled)
        }
    }

    fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return try {
            pm.getPackageInfo(packageName, 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchApp(context: Context, app: MusicAppInfo): Boolean {
        val pm = context.packageManager

        // 1. Try launching by package launch intent
        val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try {
                context.startActivity(launchIntent)
                true
            } catch (_: Exception) {
                false
            }
        }

        // 2. Try deep link URI
        if (app.deepLinkUri.isNotBlank()) {
            val deepLinkIntent = Intent(Intent.ACTION_VIEW, Uri.parse(app.deepLinkUri)).apply {
                setPackage(app.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                if (deepLinkIntent.resolveActivity(pm) != null) {
                    context.startActivity(deepLinkIntent)
                    return true
                }
            } catch (_: Exception) {}
        }

        // 3. Fallback: Open web or app store
        val fallbackUrl = if (app.storeUrl.isNotBlank()) app.storeUrl else app.deepLinkUri
        if (fallbackUrl.isNotBlank()) {
            return try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
                true
            } catch (_: Exception) {
                false
            }
        }

        return false
    }
}
