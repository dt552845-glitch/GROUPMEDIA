package com.example

import com.example.model.InstalledAppInfo
import com.example.model.MusicTrackCatalog
import com.example.sync.ActiveRoomRegistry
import com.example.utils.AppDetector
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class ExampleUnitTest {

    @Before
    fun setup() {
        ActiveRoomRegistry.clearAll()
    }

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testSongSearchThroughConnectedApp_defaultYouTubeModded() {
        val tracks = MusicTrackCatalog.searchSongs("Blinding Lights", sourceAppName = "YouTube (Modded / ReVanced)")
        assertTrue("Search results should not be empty", tracks.isNotEmpty())
        val first = tracks.first()
        assertTrue("Title should contain search query", first.title.contains("Blinding Lights", ignoreCase = true))
        assertEquals("YouTube (Modded / ReVanced)", first.sourceApp)
    }

    @Test
    fun testSongSearchThroughConnectedApp_spotify() {
        val tracks = MusicTrackCatalog.searchSongs("Starboy", sourceAppName = "Spotify")
        assertTrue("Search results should not be empty", tracks.isNotEmpty())
        for (track in tracks) {
            assertEquals("Spotify", track.sourceApp)
        }
    }

    @Test
    fun testCustomQuerySearch_generatesTrackThroughConnectedApp() {
        val customQuery = "Despacito Remix Party"
        val results = MusicTrackCatalog.searchSongs(customQuery, sourceAppName = "YouTube (Modded / ReVanced)")
        assertTrue("Results should contain customized track", results.isNotEmpty())
        val customTrack = results.first()
        assertTrue(customTrack.title.contains("Despacito", ignoreCase = true))
        assertEquals("YouTube (Modded / ReVanced)", customTrack.sourceApp)
        assertTrue(customTrack.tags.any { it.contains("YouTube (Modded / ReVanced)") })
    }

    @Test
    fun testSearchUriTemplate_generation() {
        val youtubeModdedTemplate = AppDetector.getSearchUriTemplate("app.revanced.android.youtube")
        assertTrue(youtubeModdedTemplate.contains("youtube.com/results?search_query="))

        val spotifyTemplate = AppDetector.getSearchUriTemplate("com.spotify.music")
        assertTrue(spotifyTemplate.contains("spotify:search:"))

        val appleTemplate = AppDetector.getSearchUriTemplate("com.apple.android.music")
        assertTrue(appleTemplate.contains("music.apple.com/search?term="))
    }

    @Test
    fun testRealTimeGeneratedCodes_onlyActiveCodesWork() {
        // Arbitrary ungenerated code should return not active
        assertFalse(ActiveRoomRegistry.isRoomActive("SYNC-9999"))
        assertFalse(ActiveRoomRegistry.isRoomActive("1234"))
        assertNull(ActiveRoomRegistry.getRoom("SYNC-9999"))

        // Register a real-time generated host session
        val session = ActiveRoomRegistry.registerRoom(
            code = "SYNC-4589",
            hostName = "Pixel 8 Pro (Host)",
            hostIp = "192.168.1.50"
        )

        // Verify it is recognized as active with both full and normalized inputs
        assertTrue(ActiveRoomRegistry.isRoomActive("SYNC-4589"))
        assertTrue(ActiveRoomRegistry.isRoomActive("sync-4589"))
        assertTrue(ActiveRoomRegistry.isRoomActive("4589"))
        assertEquals("Pixel 8 Pro (Host)", ActiveRoomRegistry.getRoom("SYNC-4589")?.hostDeviceName)

        // Unregister room when host session ends
        ActiveRoomRegistry.unregisterRoom("SYNC-4589")

        // The code should now be not available
        assertFalse(ActiveRoomRegistry.isRoomActive("SYNC-4589"))
        assertNull(ActiveRoomRegistry.getRoom("SYNC-4589"))
    }
}
