package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.utils.AppDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SyncBeat", appName)
    }

    @Test
    fun `detect mobile apps on Android device`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val apps = AppDetector.getDetectedApps(context)
        assertTrue("Detected apps list should not be empty", apps.isNotEmpty())

        val moddedYouTube = apps.find { it.isModded && it.name.contains("YouTube", ignoreCase = true) }
        assertTrue("Should detect modded YouTube client", moddedYouTube != null)
        assertTrue("Modded flag should be true", moddedYouTube?.isModded == true)

        val spotify = apps.find { it.name.contains("Spotify", ignoreCase = true) }
        assertTrue("Should detect Spotify app", spotify != null)
    }
}
