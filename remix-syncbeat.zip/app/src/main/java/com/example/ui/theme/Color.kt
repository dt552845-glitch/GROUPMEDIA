package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Primary & Brand Colors
val MinimalPurple = Color(0xFF6750A4)
val MinimalPurpleLight = Color(0xFF7C64B8)
val MinimalPurpleDark = Color(0xFF21005D)
val MinimalPurpleContainer = Color(0xFFEADDFF)
val MinimalOnPurpleContainer = Color(0xFF21005D)

// Clean Minimalism Surfaces & Backgrounds
val MinimalBackground = Color(0xFFFEF7FF)
val MinimalSurface = Color(0xFFFFFFFF)
val MinimalSurfaceVariant = Color(0xFFF3EDF7)
val MinimalSurfaceElevated = Color(0xFFF7F2FA)
val MinimalSurfaceCard = Color(0xFFFFFFFF)
val MinimalSurfaceCardAlt = Color(0xFFF3EDF7)
val MinimalSurfaceDark = Color(0xFF21005D)

// Borders & Outlines
val MinimalBorder = Color(0xFFCAC4D0)
val MinimalBorderLight = Color(0xFFECF0F1)
val MinimalBorderOutline = Color(0xFF79747E)

// Text & Content Colors
val MinimalTextPrimary = Color(0xFF1D1B20)
val MinimalTextSecondary = Color(0xFF49454F)
val MinimalTextMuted = Color(0xFF79747E)
val MinimalTextOnDark = Color(0xFFFFFFFF)
val MinimalTextSecondaryOnDark = Color(0xCCFFFFFF)

// Gradients & Art Tints
val GradientPinkStart = Color(0xFFFFD8E4)
val GradientPurpleEnd = Color(0xFF6750A4)
val GradientLavenderStart = Color(0xFFE8DEF8)
val GradientMidnightEnd = Color(0xFF21005D)
val SoftGray = Color(0xFFE1E2E1)

// Status & Indicators
val StatusActive = Color(0xFF146C2E)
val StatusActiveLight = Color(0xFF2E7D32)
val StatusConnecting = Color(0xFFB26A00)
val StatusError = Color(0xFFB3261E)
val ModdedBadgeColor = Color(0xFFE50914)

// Waveform & Visualizer Colors
val VisualizerBar1 = Color(0xFF6750A4)
val VisualizerBar2 = Color(0xFFEADDFF)
val VisualizerBar3 = Color(0xFF21005D)
val VisualizerBar4 = Color(0xFFFFD8E4)

// Compatibility Tokens
val DarkObsidian = MinimalBackground
val DarkSurface = MinimalSurface
val DarkSurfaceElevated = MinimalSurfaceVariant
val DarkSurfaceCard = MinimalSurfaceCard
val DarkSurfaceBorder = MinimalBorder
val DarkSurfaceBorderLight = MinimalBorderLight
val TextPrimary = MinimalTextPrimary
val TextSecondary = MinimalTextSecondary
val TextMuted = MinimalTextMuted
val NeonEmerald = MinimalPurple
val NeonEmeraldLight = MinimalPurpleLight
val ElectricCyan = MinimalPurple
val ElectricCyanGlow = MinimalPurpleContainer
val NeonPurple = MinimalPurpleDark
val NeonPink = GradientPinkStart
val NeonAmber = StatusConnecting
