package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusError
import com.example.viewmodel.AppScreen
import com.example.ui.components.HeroMusicPlayerCard
import com.example.ui.components.LaunchAppSection
import com.example.ui.components.MediaSearchCard
import com.example.ui.components.RestrictedConnectivityDialog
import com.example.viewmodel.MusicSyncUiState
import com.example.viewmodel.MusicSyncViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JoinRoomScreen(
    uiState: MusicSyncUiState,
    viewModel: MusicSyncViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isConnected = uiState.connectionStatus == ConnectionStatus.CONNECTED_AS_CLIENT || !uiState.isHost && uiState.roomCode.isNotBlank()

    if (uiState.isRestrictedDialogVisible) {
        RestrictedConnectivityDialog(
            isWifiEnabled = uiState.isWifiEnabled,
            isBluetoothEnabled = uiState.isBluetoothEnabled,
            reasonMessage = uiState.restrictedDialogReason,
            onOpenWifiSettings = { viewModel.openWifiSettings() },
            onOpenBluetoothSettings = { viewModel.openBluetoothSettings() },
            onDismiss = { viewModel.dismissRestrictedDialog() }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBackground)
    ) {
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = if (isConnected) "Connected Room Session" else "Connect Through Code",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = if (isConnected) "Room ${uiState.roomCode} • P2P Synced" else "Enter a Host's room code",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextSecondary,
                        fontSize = 11.sp
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.Home) },
                    modifier = Modifier.testTag("join_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MinimalTextPrimary
                    )
                }
            },
            actions = {
                if (isConnected) {
                    IconButton(
                        onClick = { viewModel.exitPartyRoom() },
                        modifier = Modifier.testTag("exit_party_top_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Exit Room",
                            tint = StatusError
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MinimalBackground)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isConnected) {
                // Connected Client View
                item {
                    ConnectedClientSessionCard(
                        roomCode = uiState.roomCode,
                        syncDriftMs = uiState.syncDriftMs,
                        hostDeviceName = uiState.hostDeviceName,
                        onRefreshSync = { viewModel.requestSyncRefresh() },
                        onExitRoom = { viewModel.exitPartyRoom() }
                    )
                }

                // Synced Media Player Card
                item {
                    HeroMusicPlayerCard(
                        track = uiState.currentTrack,
                        isPlaying = uiState.isPlaying,
                        isBuffering = uiState.isBuffering,
                        currentPositionMs = uiState.currentPositionMs,
                        durationMs = uiState.durationMs,
                        volume = uiState.volume,
                        isHost = false,
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSkipPrevious = { viewModel.prevTrack() },
                        onSkipNext = { viewModel.nextTrack() },
                        onSeekTo = { viewModel.seekTo(it) },
                        onVolumeChange = { viewModel.setVolume(it) },
                        onOpenPlatform = { track, platform -> viewModel.openTrackInPlatform(track, platform) }
                    )
                }

                // Media Search Option
                item {
                    MediaSearchCard(
                        searchQuery = uiState.searchQuery,
                        selectedPlatformFilter = uiState.selectedPlatformFilter,
                        searchResults = uiState.searchResults,
                        isSearching = uiState.isSearching,
                        onQueryChange = { viewModel.updateSearchQuery(it) },
                        onSearchClick = { viewModel.searchMedia() },
                        onFilterSelect = { viewModel.setPlatformFilter(it) },
                        onPlayTrack = { viewModel.playTrack(it) },
                        onOpenPlatform = { track, platform -> viewModel.openTrackInPlatform(track, platform) }
                    )
                }

                // Launch App System
                item {
                    LaunchAppSection(
                        installedApps = uiState.installedApps,
                        onLaunchApp = { viewModel.launchMusicApp(it) }
                    )
                }

                item {
                    ClientReactionSignalBar(
                        onSendReaction = { emoji -> viewModel.sendListenerReaction(emoji) }
                    )
                }

                item {
                    ClientTelemetryCard(nearbyStatus = uiState.nearbyStatus)
                }
            } else {
                // Code Input & Connect Form View
                item {
                    JoinCodeFormCard(
                        codeInput = uiState.joinCodeInput,
                        errorMessage = uiState.joinErrorMessage,
                        isConnecting = uiState.connectionStatus == ConnectionStatus.CONNECTING,
                        onCodeChange = { viewModel.updateJoinCodeInput(it) },
                        onPasteCode = {
                            val pasted = getClipboardText(context)
                            if (pasted.isNotBlank()) viewModel.updateJoinCodeInput(pasted)
                        },
                        onClearCode = { viewModel.updateJoinCodeInput("") },
                        onConnectClicked = { viewModel.connectThroughCode() }
                    )
                }

                // Active Rooms Section
                if (uiState.activeRealTimeRooms.isNotEmpty()) {
                    item {
                        ActiveRealTimeRoomsListSection(
                            activeRooms = uiState.activeRealTimeRooms,
                            onSelectRoom = { code ->
                                viewModel.updateJoinCodeInput(code)
                                viewModel.connectThroughCode()
                            }
                        )
                    }
                }

                item {
                    HowRoomCodeSyncWorksCard()
                }
            }
        }
    }
}

@Composable
fun ConnectedClientSessionCard(
    roomCode: String,
    syncDriftMs: Long,
    hostDeviceName: String,
    onRefreshSync: () -> Unit,
    onExitRoom: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.5.dp, MinimalPurpleContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("connected_client_session_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(StatusActive)
                    )
                    Text(
                        text = "CONNECTED TO HOST",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusActive,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MinimalPurpleContainer)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "~${syncDriftMs}ms Latency",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalPurple,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Room $roomCode",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MinimalPurpleDark
            )

            Text(
                text = "Hosted by $hostDeviceName",
                style = MaterialTheme.typography.bodyMedium,
                color = MinimalTextSecondary
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onRefreshSync,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MinimalPurple),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("client_resync_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Resync",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Resync Session", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onExitRoom,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("client_exit_room_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                        contentDescription = "Exit",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Exit Room", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun ClientReactionSignalBar(
    onSendReaction: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "SEND SIGNAL TO HOST",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MinimalTextSecondary,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val emojis = listOf("🔥", "🎉", "🔊", "⚡", "❤️", "👏")
                emojis.forEach { emoji ->
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MinimalPurpleContainer)
                            .clickable { onSendReaction(emoji) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = emoji, fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ClientTelemetryCard(nearbyStatus: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Sensors,
                contentDescription = "Telemetry",
                tint = MinimalPurple,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = nearbyStatus,
                style = MaterialTheme.typography.bodySmall,
                color = MinimalTextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun JoinCodeFormCard(
    codeInput: String,
    errorMessage: String?,
    isConnecting: Boolean,
    onCodeChange: (String) -> Unit,
    onPasteCode: () -> Unit,
    onClearCode: () -> Unit,
    onConnectClicked: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, if (errorMessage != null) StatusError else MinimalPurpleContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("join_code_form_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MinimalPurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "Room Code",
                        tint = MinimalPurple,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Column {
                    Text(
                        text = "Enter Room Code",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = "Connect to an active host's group session",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Code Input Field
            OutlinedTextField(
                value = codeInput,
                onValueChange = onCodeChange,
                placeholder = {
                    Text(
                        text = "SYNC-4B9X",
                        color = MinimalTextMuted,
                        fontWeight = FontWeight.Medium
                    )
                },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (codeInput.isNotEmpty()) {
                            IconButton(onClick = onClearCode) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = MinimalTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        IconButton(onClick = onPasteCode) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = "Paste",
                                tint = MinimalPurple,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                isError = errorMessage != null,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { onConnectClicked() }
                ),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MinimalSurface,
                    unfocusedContainerColor = MinimalSurface,
                    focusedBorderColor = MinimalPurple,
                    unfocusedBorderColor = MinimalBorder,
                    focusedTextColor = MinimalTextPrimary,
                    unfocusedTextColor = MinimalTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("join_code_text_input")
            )

            // Error banner if invalid
            AnimatedVisibility(visible = errorMessage != null) {
                if (errorMessage != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(StatusError.copy(alpha = 0.12f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Error",
                            tint = StatusError,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = StatusError,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Connect button
            Button(
                onClick = onConnectClicked,
                enabled = !isConnecting,
                colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("join_connect_button")
            ) {
                if (isConnecting) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CastConnected,
                            contentDescription = "Connect",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "JOIN ROOM SESSION",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveRealTimeRoomsListSection(
    activeRooms: List<com.example.sync.ActiveRoomSession>,
    onSelectRoom: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "ACTIVE ROOMS IN AREA (${activeRooms.size})",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MinimalPurpleDark,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        activeRooms.forEach { room ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MinimalSurface),
                border = BorderStroke(1.dp, MinimalPurpleContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectRoom(room.roomCode) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(StatusActive)
                        )
                        Column {
                            Text(
                                text = room.roomCode,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MinimalTextPrimary
                            )
                            Text(
                                text = "${room.hostDeviceName} • ${room.hostIpAddress}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MinimalTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Text(
                        text = "Join",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalPurple,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun HowRoomCodeSyncWorksCard() {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "⚡ Real-time Multi-Device Sync",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MinimalTextPrimary
            )
            Text(
                text = "• Only active real-time generated codes can be joined.\n• Host devices broadcast over Wi-Fi and Bluetooth Nearby Connections API.\n• Enjoy seamless sub-15ms group room synchronization across all connected mobiles.",
                style = MaterialTheme.typography.bodySmall,
                color = MinimalTextSecondary,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}

private fun getClipboardText(context: Context): String {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    return clipboard?.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
}
