package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.StatusError

@Composable
fun RestrictedConnectivityDialog(
    isWifiEnabled: Boolean,
    isBluetoothEnabled: Boolean,
    reasonMessage: String = "",
    onOpenWifiSettings: () -> Unit,
    onOpenBluetoothSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MinimalSurface,
        shape = RoundedCornerShape(24.dp),
        icon = {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(StatusError.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Restricted Warning",
                    tint = StatusError,
                    modifier = Modifier.size(32.dp)
                )
            }
        },
        title = {
            Text(
                text = "Wi-Fi & Bluetooth Required",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MinimalTextPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = reasonMessage.ifBlank {
                        "To generate a room code or connect through a code, both Wi-Fi and Bluetooth must be turned ON for high-speed zero-latency local audio sync."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MinimalTextSecondary,
                    textAlign = TextAlign.Center,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Connectivity Indicators Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Wi-Fi Status Chip
                    HardwareStatusChip(
                        name = "Wi-Fi",
                        isEnabled = isWifiEnabled,
                        onIcon = Icons.Default.Wifi,
                        offIcon = Icons.Default.WifiOff,
                        onClick = onOpenWifiSettings
                    )

                    // Bluetooth Status Chip
                    HardwareStatusChip(
                        name = "Bluetooth",
                        isEnabled = isBluetoothEnabled,
                        onIcon = Icons.Default.Bluetooth,
                        offIcon = Icons.Default.BluetoothDisabled,
                        onClick = onOpenBluetoothSettings
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!isWifiEnabled) onOpenWifiSettings()
                    else if (!isBluetoothEnabled) onOpenBluetoothSettings()
                    else onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("restricted_dialog_action_btn")
            ) {
                Text(
                    text = when {
                        !isWifiEnabled -> "Turn On Wi-Fi Settings"
                        !isBluetoothEnabled -> "Turn On Bluetooth Settings"
                        else -> "Got It"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Dismiss", color = MinimalTextSecondary, fontWeight = FontWeight.Medium)
            }
        },
        modifier = Modifier.testTag("restricted_connectivity_dialog")
    )
}

@Composable
private fun HardwareStatusChip(
    name: String,
    isEnabled: Boolean,
    onIcon: androidx.compose.ui.graphics.vector.ImageVector,
    offIcon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .border(
                1.dp,
                if (isEnabled) MinimalPurpleContainer else StatusError.copy(alpha = 0.4f),
                RoundedCornerShape(14.dp)
            )
            .background(if (isEnabled) MinimalPurpleContainer.copy(alpha = 0.4f) else StatusError.copy(alpha = 0.08f))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = if (isEnabled) onIcon else offIcon,
                    contentDescription = name,
                    tint = if (isEnabled) MinimalPurple else StatusError,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MinimalTextPrimary,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isEnabled) "ACTIVE" else "DISABLED",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.ExtraBold,
                color = if (isEnabled) MinimalPurpleDark else StatusError,
                fontSize = 10.sp
            )
        }
    }
}
