package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalOnPurpleContainer
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusError
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MusicSyncUiState
import com.example.viewmodel.MusicSyncViewModel

import com.example.ui.components.LaunchAppSection
import com.example.ui.components.RestrictedConnectivityDialog

@Composable
fun HomeScreen(
    uiState: MusicSyncUiState,
    viewModel: MusicSyncViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Restricted Popup Dialog when Wi-Fi or Bluetooth is turned off
    if (uiState.isRestrictedDialogVisible) {
        RestrictedConnectivityDialog(
            isWifiEnabled = uiState.isWifiEnabled,
            isBluetoothEnabled = uiState.isBluetoothEnabled,
            reasonMessage = uiState.restrictedDialogReason,
            onOpenWifiSettings = { viewModel.openWifiSettings() },
            onOpenBluetoothSettings = { viewModel.openBluetoothSettings() },
            onDismiss = { viewModel.dismissRestrictedDialog() }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(bottom = 24.dp)
        ) {
            // App Header & status badges
            HomeTopHeader(
                isWifiEnabled = uiState.isWifiEnabled,
                isBluetoothEnabled = uiState.isBluetoothEnabled
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Hero Banner
            HeroCardBanner(
                connectedDevicesCount = uiState.connectedDevices.size
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Section: Main Actions
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // BUTTON 1: "Generate Code & Launch Music Player" (Host Mode)
                GenerateCodeCardButton(
                    onGenerateCode = { viewModel.onGenerateCodeClicked() }
                )

                // Launch App System
                LaunchAppSection(
                    installedApps = uiState.installedApps,
                    onLaunchApp = { viewModel.launchMusicApp(it) }
                )

                // BUTTON 2: "Connect Through Code" (Client Mode with code input & connect action)
                ConnectThroughCodeCard(
                    codeInput = uiState.joinCodeInput,
                    errorMessage = uiState.joinErrorMessage,
                    onCodeChange = { viewModel.updateJoinCodeInput(it) },
                    onConnectClicked = { viewModel.connectThroughCode() }
                )

                // Section: Active Real-time Rooms
                if (uiState.activeRealTimeRooms.isNotEmpty()) {
                    ActiveRealTimeRoomsSection(
                        activeRooms = uiState.activeRealTimeRooms,
                        onSelectRoom = { roomCode ->
                            viewModel.updateJoinCodeInput(roomCode)
                            viewModel.connectThroughCode()
                        }
                    )
                }

                // Section: Multi-Device Capabilities overview
                MultiDeviceNetworkOverviewCard(
                    nearbyStatus = uiState.nearbyStatus
                )
            }
        }
    }
}

@Composable
fun HomeTopHeader(
    isWifiEnabled: Boolean,
    isBluetoothEnabled: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "SyncBeat",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MinimalPurpleDark,
                    letterSpacing = (-0.5).sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MinimalPurpleContainer)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "ROOM SYNC",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalOnPurpleContainer,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
            }
            Text(
                text = "Multi-Device Room Synchronization",
                style = MaterialTheme.typography.bodySmall,
                color = MinimalTextSecondary,
                fontSize = 12.sp
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NetworkBadge(
                icon = Icons.Default.Wifi,
                label = "Wi-Fi",
                isActive = isWifiEnabled
            )
            NetworkBadge(
                icon = Icons.Default.Bluetooth,
                label = "BT",
                isActive = isBluetoothEnabled
            )
        }
    }
}

@Composable
fun NetworkBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isActive) MinimalPurpleContainer else MinimalSurface)
            .border(
                BorderStroke(1.dp, if (isActive) MinimalPurple else MinimalBorderLight),
                RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) MinimalPurple else MinimalTextMuted,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (isActive) MinimalOnPurpleContainer else MinimalTextMuted,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun HeroCardBanner(
    connectedDevicesCount: Int
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalPurpleContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag("hero_card_banner")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(StatusActive)
                    )
                    Text(
                        text = "REAL-TIME P2P SYNC",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusActive,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "$connectedDevicesCount Connected",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalTextSecondary,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Connect Nearby Mobiles",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MinimalTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Host a synchronized group session via Wi-Fi & Bluetooth Nearby Connections API with sub-15ms sync latency.",
                style = MaterialTheme.typography.bodyMedium,
                color = MinimalTextSecondary,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
fun GenerateCodeCardButton(
    onGenerateCode: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalPurpleContainer),
        border = BorderStroke(1.5.dp, MinimalPurple),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onGenerateCode)
            .testTag("generate_code_card_button")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MinimalPurple),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = "Generate Code",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = "Generate Code & Host Player",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalOnPurpleContainer
                    )
                    Text(
                        text = "Search Spotify/YouTube & play songs direct in room",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MinimalPurple)
                    .padding(10.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Go",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun ConnectThroughCodeCard(
    codeInput: String,
    errorMessage: String?,
    onCodeChange: (String) -> Unit,
    onConnectClicked: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, if (errorMessage != null) StatusError else MinimalBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("connect_through_code_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MinimalPurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = "Connect Through Code",
                        tint = MinimalPurple,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column {
                    Text(
                        text = "Connect Through Code",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = "Enter a Host's room code (e.g. SYNC-4B9X)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Text input field for Room Code
            OutlinedTextField(
                value = codeInput,
                onValueChange = onCodeChange,
                placeholder = {
                    Text(
                        text = "SYNC-4B9X",
                        color = MinimalTextMuted,
                        fontWeight = FontWeight.Medium
                    )
                },
                singleLine = true,
                isError = errorMessage != null,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { onConnectClicked() }
                ),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MinimalSurface,
                    unfocusedContainerColor = MinimalSurface,
                    focusedBorderColor = MinimalPurple,
                    unfocusedBorderColor = MinimalBorder,
                    focusedTextColor = MinimalTextPrimary,
                    unfocusedTextColor = MinimalTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_code_input_field")
            )

            // Error banner if invalid code
            AnimatedVisibility(visible = errorMessage != null) {
                if (errorMessage != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(StatusError.copy(alpha = 0.12f))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Error",
                            tint = StatusError,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusError,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Button: CONNECT
            Button(
                onClick = onConnectClicked,
                colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("connect_to_host_code_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CastConnected,
                        contentDescription = "Connect",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CONNECT TO ROOM",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun ActiveRealTimeRoomsSection(
    activeRooms: List<com.example.sync.ActiveRoomSession>,
    onSelectRoom: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "ACTIVE REAL-TIME HOST ROOMS (${activeRooms.size})",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MinimalPurpleDark,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        activeRooms.forEach { room ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MinimalSurface),
                border = BorderStroke(1.dp, MinimalPurpleContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectRoom(room.roomCode) }
                    .testTag("active_room_item_${room.roomCode}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(StatusActive)
                        )
                        Column {
                            Text(
                                text = room.roomCode,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MinimalTextPrimary
                            )
                            Text(
                                text = "${room.hostDeviceName} • ${room.hostIpAddress}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MinimalTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Text(
                        text = "Tap to Join",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalPurple,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun MultiDeviceNetworkOverviewCard(
    nearbyStatus: String
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Sensors,
                    contentDescription = "Nearby API",
                    tint = MinimalPurple,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Nearby Connections API Status",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MinimalTextPrimary
                )
            }

            Text(
                text = nearbyStatus,
                style = MaterialTheme.typography.bodySmall,
                color = MinimalTextSecondary,
                fontSize = 12.sp
            )
        }
    }
}
