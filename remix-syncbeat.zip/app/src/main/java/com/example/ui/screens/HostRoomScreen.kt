package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectedDevice
import com.example.model.ConnectionType
import com.example.ui.components.QrCodeDialog
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalOnPurpleContainer
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusError
import com.example.viewmodel.AppScreen
import com.example.ui.components.HeroMusicPlayerCard
import com.example.ui.components.LaunchAppSection
import com.example.ui.components.MediaSearchCard
import com.example.ui.components.RestrictedConnectivityDialog
import com.example.viewmodel.MusicSyncUiState
import com.example.viewmodel.MusicSyncViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HostRoomScreen(
    uiState: MusicSyncUiState,
    viewModel: MusicSyncViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    if (uiState.isRestrictedDialogVisible) {
        RestrictedConnectivityDialog(
            isWifiEnabled = uiState.isWifiEnabled,
            isBluetoothEnabled = uiState.isBluetoothEnabled,
            reasonMessage = uiState.restrictedDialogReason,
            onOpenWifiSettings = { viewModel.openWifiSettings() },
            onOpenBluetoothSettings = { viewModel.openBluetoothSettings() },
            onDismiss = { viewModel.dismissRestrictedDialog() }
        )
    }

    if (uiState.isQrDialogVisible) {
        QrCodeDialog(
            roomCode = uiState.roomCode,
            onDismiss = { viewModel.setQrDialogVisible(false) }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBackground)
    ) {
        // Top App Bar
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "Host Room Session",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = "Room ${uiState.roomCode} • ${uiState.connectedDevices.size} Mobiles Connected",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextSecondary,
                        fontSize = 11.sp
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.Home) },
                    modifier = Modifier.testTag("host_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MinimalTextPrimary
                    )
                }
            },
            actions = {
                IconButton(
                    onClick = { viewModel.setQrDialogVisible(true) },
                    modifier = Modifier.testTag("host_top_qr_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = "QR Code",
                        tint = MinimalPurple
                    )
                }
                IconButton(
                    onClick = { viewModel.stopHosting() },
                    modifier = Modifier.testTag("host_stop_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.StopCircle,
                        contentDescription = "Stop Hosting",
                        tint = StatusError
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MinimalBackground)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Room Code Header Card
            item {
                HostCodeHeaderCard(
                    roomCode = uiState.roomCode,
                    isSyncActive = uiState.isSyncActive,
                    onToggleSync = { viewModel.toggleSyncBroadcast(it) },
                    onRegenerateCode = { viewModel.regenerateHostCode() },
                    onShowQrCode = { viewModel.setQrDialogVisible(true) },
                    onCopyCode = { copyCodeToClipboard(context, uiState.roomCode) },
                    onShareCode = { shareCodeIntent(context, uiState.roomCode) },
                    onStopHosting = { viewModel.stopHosting() }
                )
            }

            // Hero Music Player Card (Direct in-app music playback)
            item {
                HeroMusicPlayerCard(
                    track = uiState.currentTrack,
                    isPlaying = uiState.isPlaying,
                    isBuffering = uiState.isBuffering,
                    currentPositionMs = uiState.currentPositionMs,
                    durationMs = uiState.durationMs,
                    volume = uiState.volume,
                    isHost = true,
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onSkipPrevious = { viewModel.prevTrack() },
                    onSkipNext = { viewModel.nextTrack() },
                    onSeekTo = { viewModel.seekTo(it) },
                    onVolumeChange = { viewModel.setVolume(it) },
                    onOpenPlatform = { track, platform -> viewModel.openTrackInPlatform(track, platform) }
                )
            }

            // Media Search Option (Spotify, YouTube, YouTube Music, iTunes APIs)
            item {
                MediaSearchCard(
                    searchQuery = uiState.searchQuery,
                    selectedPlatformFilter = uiState.selectedPlatformFilter,
                    searchResults = uiState.searchResults,
                    isSearching = uiState.isSearching,
                    onQueryChange = { viewModel.updateSearchQuery(it) },
                    onSearchClick = { viewModel.searchMedia() },
                    onFilterSelect = { viewModel.setPlatformFilter(it) },
                    onPlayTrack = { viewModel.playTrack(it) },
                    onOpenPlatform = { track, platform -> viewModel.openTrackInPlatform(track, platform) }
                )
            }

            // Launch App System
            item {
                LaunchAppSection(
                    installedApps = uiState.installedApps,
                    onLaunchApp = { viewModel.launchMusicApp(it) }
                )
            }

            // Quick Signal & Reactions Bar
            item {
                HostQuickSignalBar(
                    onSendSignal = { emoji -> viewModel.sendListenerReaction(emoji) }
                )
            }

            // Connected Mobiles Section
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CONNECTED MOBILES (${uiState.connectedDevices.size})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalPurpleDark,
                        letterSpacing = 1.sp
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(StatusActive)
                        )
                        Text(
                            text = "Real-time P2P Active",
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusActive,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            if (uiState.connectedDevices.isEmpty()) {
                item {
                    NoConnectedDevicesPlaceholderCard(
                        roomCode = uiState.roomCode,
                        onShowQrCode = { viewModel.setQrDialogVisible(true) }
                    )
                }
            } else {
                items(uiState.connectedDevices, key = { it.id }) { device ->
                    HostConnectedDeviceItemCard(device = device)
                }
            }

            // Network telemetry status card
            item {
                HostNearbyStatusCard(statusText = uiState.nearbyStatus)
            }
        }
    }
}

@Composable
fun HostCodeHeaderCard(
    roomCode: String,
    isSyncActive: Boolean,
    onToggleSync: (Boolean) -> Unit,
    onRegenerateCode: () -> Unit,
    onShowQrCode: () -> Unit,
    onCopyCode: () -> Unit,
    onShareCode: () -> Unit,
    onStopHosting: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalPurpleContainer),
        border = BorderStroke(1.5.dp, MinimalPurple),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("host_code_header_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isSyncActive) StatusActive else MinimalTextMuted)
                    )
                    Text(
                        text = if (isSyncActive) "HOSTING ACTIVE" else "HOSTING PAUSED",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSyncActive) StatusActive else MinimalTextMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Broadcasting",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextSecondary
                    )
                    Switch(
                        checked = isSyncActive,
                        onCheckedChange = onToggleSync,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MinimalPurple,
                            uncheckedThumbColor = MinimalTextMuted,
                            uncheckedTrackColor = MinimalSurface
                        ),
                        modifier = Modifier.testTag("host_broadcast_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Room Code Display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MinimalSurface)
                    .border(BorderStroke(1.dp, MinimalBorder), RoundedCornerShape(16.dp))
                    .padding(vertical = 16.dp, horizontal = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = roomCode,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MinimalPurpleDark,
                        letterSpacing = 3.sp
                    )

                    IconButton(
                        onClick = onRegenerateCode,
                        modifier = Modifier
                            .padding(start = 8.dp)
                            .testTag("regenerate_code_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Regenerate Code",
                            tint = MinimalPurple
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick actions row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCopyCode,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MinimalPurpleDark),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("copy_code_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Copy", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onShareCode,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MinimalPurpleDark),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("share_code_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Share", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onShowQrCode,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("show_qr_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = "QR",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "QR Code", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onStopHosting,
                colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("host_screen_stop_hosting_button")
            ) {
                Icon(
                    imageVector = Icons.Default.StopCircle,
                    contentDescription = "Stop Hosting",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CLOSE ROOM SESSION",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun HostQuickSignalBar(
    onSendSignal: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Text(
                text = "BROADCAST ROOM SIGNAL / REACTION",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MinimalTextSecondary,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val emojis = listOf("🔥", "🎉", "🔊", "⚡", "❤️", "👏")
                emojis.forEach { emoji ->
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MinimalPurpleContainer)
                            .clickable { onSendSignal(emoji) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = emoji, fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun NoConnectedDevicesPlaceholderCard(
    roomCode: String,
    onShowQrCode: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Devices,
                contentDescription = "Devices",
                tint = MinimalPurple,
                modifier = Modifier.size(40.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Waiting for Mobiles to Join...",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MinimalTextPrimary
            )

            Text(
                text = "Share Room Code $roomCode or show the QR code to nearby party members.",
                style = MaterialTheme.typography.bodySmall,
                color = MinimalTextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedButton(
                onClick = onShowQrCode,
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.QrCode,
                    contentDescription = "QR Code",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Show QR Code", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun HostConnectedDeviceItemCard(device: ConnectedDevice) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MinimalPurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (device.connectionType == ConnectionType.WIFI) Icons.Default.Wifi else Icons.Default.Bluetooth,
                        contentDescription = "Connection",
                        tint = MinimalPurple,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = device.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = "${device.connectionType.name} • ${device.ipAddress} • Ping ${device.pingMs}ms",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Synced",
                    tint = StatusActive,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "SYNCED",
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusActive,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun HostNearbyStatusCard(statusText: String) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Sensors,
                contentDescription = "Status",
                tint = MinimalPurple,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall,
                color = MinimalTextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

private fun copyCodeToClipboard(context: Context, code: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    val clip = ClipData.newPlainText("SyncBeat Room Code", code)
    clipboard?.setPrimaryClip(clip)
}

private fun shareCodeIntent(context: Context, code: String) {
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, "Join my SyncBeat multi-device room session! Room Code: $code")
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Share Room Code")
    context.startActivity(shareIntent)
}
