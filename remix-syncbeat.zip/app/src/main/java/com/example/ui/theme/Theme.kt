package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CleanMinimalColorScheme = lightColorScheme(
    primary = MinimalPurple,
    onPrimary = MinimalSurface,
    primaryContainer = MinimalPurpleContainer,
    onPrimaryContainer = MinimalOnPurpleContainer,
    secondary = MinimalPurpleLight,
    onSecondary = MinimalSurface,
    secondaryContainer = MinimalSurfaceVariant,
    onSecondaryContainer = MinimalTextPrimary,
    tertiary = MinimalPurpleDark,
    onTertiary = MinimalTextOnDark,
    background = MinimalBackground,
    onBackground = MinimalTextPrimary,
    surface = MinimalSurface,
    onSurface = MinimalTextPrimary,
    surfaceVariant = MinimalSurfaceVariant,
    onSurfaceVariant = MinimalTextSecondary,
    outline = MinimalBorder,
    outlineVariant = MinimalBorderLight,
    surfaceContainer = MinimalSurfaceElevated
)

@Composable
fun SyncBeatTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = MinimalBackground.toArgb()
                window.navigationBarColor = MinimalBackground.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = true
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = true
            }
        }
    }

    MaterialTheme(
        colorScheme = CleanMinimalColorScheme,
        typography = Typography,
        content = content
    )
}

// Compatibility alias
@Composable
fun MyApplicationTheme(content: @Composable () -> Unit) {
    SyncBeatTheme(content = content)
}
