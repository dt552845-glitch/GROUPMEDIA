package com.example.sync

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ActiveRoomSession(
    val roomCode: String,
    val hostDeviceName: String,
    val createdAtMs: Long = System.currentTimeMillis(),
    val isHosting: Boolean = true,
    val hostIpAddress: String = "192.168.1.1",
    val activeTrackTitle: String = "Live Party Stream"
)

object ActiveRoomRegistry {
    private val _activeRooms = MutableStateFlow<Map<String, ActiveRoomSession>>(emptyMap())
    val activeRooms: StateFlow<Map<String, ActiveRoomSession>> = _activeRooms.asStateFlow()

    fun normalizeCode(code: String): String {
        val clean = code.trim().uppercase().replace(" ", "")
        return if (clean.startsWith("SYNC-")) {
            clean
        } else if (clean.startsWith("SYNC")) {
            val suffix = clean.removePrefix("SYNC").removePrefix("-")
            "SYNC-$suffix"
        } else {
            "SYNC-$clean"
        }
    }

    fun registerRoom(
        code: String,
        hostName: String = "Host DJ Master",
        hostIp: String = "192.168.1.1",
        trackTitle: String = "Live Party Stream"
    ): ActiveRoomSession {
        val normalized = normalizeCode(code)
        val session = ActiveRoomSession(
            roomCode = normalized,
            hostDeviceName = hostName,
            createdAtMs = System.currentTimeMillis(),
            isHosting = true,
            hostIpAddress = hostIp,
            activeTrackTitle = trackTitle
        )
        _activeRooms.update { current ->
            current + (normalized to session)
        }
        return session
    }

    fun unregisterRoom(code: String) {
        val normalized = normalizeCode(code)
        _activeRooms.update { current ->
            current - normalized
        }
    }

    fun isRoomActive(code: String): Boolean {
        val normalized = normalizeCode(code)
        val session = _activeRooms.value[normalized]
        return session != null && session.isHosting
    }

    fun getRoom(code: String): ActiveRoomSession? {
        val normalized = normalizeCode(code)
        return _activeRooms.value[normalized]
    }

    fun getActiveRooms(): List<ActiveRoomSession> {
        return _activeRooms.value.values.filter { it.isHosting }
    }

    fun clearAll() {
        _activeRooms.value = emptyMap()
    }
}
