package com.example.model

enum class ConnectionType {
    WIFI,
    BLUETOOTH
}

enum class ConnectionStatus {
    IDLE,
    HOSTING,
    CONNECTING,
    CONNECTED_AS_CLIENT,
    ERROR
}

data class ConnectedDevice(
    val id: String,
    val name: String,
    val connectionType: ConnectionType = ConnectionType.WIFI,
    val pingMs: Long = 12L,
    val isSynced: Boolean = true,
    val ipAddress: String = "192.168.1.100"
)
