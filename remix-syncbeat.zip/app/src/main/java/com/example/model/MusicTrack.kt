package com.example.model

data class MusicTrack(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val albumArtUrl: String = "",
    val streamUrl: String = "",
    val durationMs: Long = 180000L,
    val source: String = "Spotify", // "Spotify", "YouTube", "YouTube Music", "iTunes"
    val externalUrl: String = ""
)

data class MusicAppInfo(
    val appName: String,
    val packageName: String,
    val deepLinkUri: String,
    val storeUrl: String,
    val isInstalled: Boolean = false
)

object MusicTrackCatalog {
    val defaultTracks = listOf(
        MusicTrack(
            id = "track_1",
            title = "Blinding Lights",
            artist = "The Weeknd",
            album = "After Hours",
            albumArtUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&auto=format&fit=crop",
            streamUrl = "https://audio-ssl.itunes.apple.com/itunes-assets/AudioVideo126/v4/08/94/a3/0894a363-2280-4df2-7067-152e04e902b4/mzaf_1001476901861788730.plus.aac.p.m4a",
            durationMs = 200000L,
            source = "Spotify",
            externalUrl = "https://open.spotify.com/search/Blinding%20Lights"
        ),
        MusicTrack(
            id = "track_2",
            title = "Levitating",
            artist = "Dua Lipa",
            album = "Future Nostalgia",
            albumArtUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500&auto=format&fit=crop",
            streamUrl = "https://audio-ssl.itunes.apple.com/itunes-assets/AudioVideo126/v4/e5/22/e7/e522e724-c104-58ff-845a-c6374f4b1d3d/mzaf_16035251642838562300.plus.aac.p.m4a",
            durationMs = 203000L,
            source = "YouTube Music",
            externalUrl = "https://music.youtube.com/search?q=Levitating+Dua+Lipa"
        ),
        MusicTrack(
            id = "track_3",
            title = "As It Was",
            artist = "Harry Styles",
            album = "Harry's House",
            albumArtUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop",
            streamUrl = "https://audio-ssl.itunes.apple.com/itunes-assets/AudioVideo112/v4/7c/ec/c0/7cecc0d2-bf1c-d760-40e8-0fb6fa369d72/mzaf_16383679116781204655.plus.aac.p.m4a",
            durationMs = 167000L,
            source = "YouTube",
            externalUrl = "https://www.youtube.com/results?search_query=As+It+Was+Harry+Styles"
        ),
        MusicTrack(
            id = "track_4",
            title = "Starboy",
            artist = "The Weeknd ft. Daft Punk",
            album = "Starboy",
            albumArtUrl = "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&auto=format&fit=crop",
            streamUrl = "https://audio-ssl.itunes.apple.com/itunes-assets/AudioVideo125/v4/91/33/c0/9133c09f-44eb-28f0-1563-0d3224b7520e/mzaf_12411995893478985161.plus.aac.p.m4a",
            durationMs = 230000L,
            source = "Spotify",
            externalUrl = "https://open.spotify.com/search/Starboy"
        ),
        MusicTrack(
            id = "track_5",
            title = "Shape of You",
            artist = "Ed Sheeran",
            album = "Divide",
            albumArtUrl = "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=500&auto=format&fit=crop",
            streamUrl = "https://audio-ssl.itunes.apple.com/itunes-assets/AudioVideo125/v4/21/5d/40/215d40db-9199-2a74-4b55-d36005c219ed/mzaf_1188372659103504381.plus.aac.p.m4a",
            durationMs = 233000L,
            source = "YouTube Music",
            externalUrl = "https://music.youtube.com/search?q=Shape+of+You+Ed+Sheeran"
        )
    )
}
