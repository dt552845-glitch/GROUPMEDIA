package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.example.model.MusicTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AudioPlaybackEngine(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var positionTickerJob: Job? = null

    private val _currentTrack = MutableStateFlow<MusicTrack?>(null)
    val currentTrack: StateFlow<MusicTrack?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(180000L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _volume = MutableStateFlow(0.85f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    var onPlaybackStateChanged: ((MusicTrack?, Boolean, Long) -> Unit)? = null
    var onTrackEnded: (() -> Unit)? = null

    init {
        initMediaPlayer()
    }

    private fun initMediaPlayer() {
        release()
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            setOnPreparedListener { mp ->
                _isBuffering.value = false
                _durationMs.value = mp.duration.toLong().coerceAtLeast(1000L)
                mp.start()
                _isPlaying.value = true
                startPositionTicker()
                notifyState()
            }
            setOnCompletionListener {
                _isPlaying.value = false
                _currentPositionMs.value = _durationMs.value
                stopPositionTicker()
                notifyState()
                onTrackEnded?.invoke()
            }
            setOnErrorListener { _, _, _ ->
                _isBuffering.value = false
                _isPlaying.value = false
                stopPositionTicker()
                true
            }
            setVolume(_volume.value, _volume.value)
        }
    }

    fun playTrack(track: MusicTrack) {
        _currentTrack.value = track
        _isBuffering.value = true
        _isPlaying.value = false
        _currentPositionMs.value = 0L

        try {
            if (mediaPlayer == null) {
                initMediaPlayer()
            } else {
                mediaPlayer?.reset()
            }

            mediaPlayer?.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            mediaPlayer?.setDataSource(track.streamUrl)
            mediaPlayer?.prepareAsync()
        } catch (e: Exception) {
            e.printStackTrace()
            _isBuffering.value = false
            _isPlaying.value = false
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: return
        if (_isPlaying.value) {
            pause()
        } else {
            resume()
        }
    }

    fun pause() {
        val player = mediaPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            _isPlaying.value = false
            stopPositionTicker()
            notifyState()
        }
    }

    fun resume() {
        val player = mediaPlayer ?: return
        if (!player.isPlaying && _currentTrack.value != null) {
            player.start()
            _isPlaying.value = true
            startPositionTicker()
            notifyState()
        } else if (_currentTrack.value == null) {
            // Play default track
            com.example.model.MusicTrackCatalog.defaultTracks.firstOrNull()?.let {
                playTrack(it)
            }
        }
    }

    fun seekTo(positionMs: Long) {
        val player = mediaPlayer ?: return
        try {
            player.seekTo(positionMs.toInt())
            _currentPositionMs.value = positionMs
            notifyState()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVolume(vol: Float) {
        val clamped = vol.coerceIn(0f, 1f)
        _volume.value = clamped
        mediaPlayer?.setVolume(clamped, clamped)
    }

    private fun startPositionTicker() {
        stopPositionTicker()
        positionTickerJob = scope.launch {
            while (isActive && _isPlaying.value) {
                mediaPlayer?.let { mp ->
                    if (mp.isPlaying) {
                        _currentPositionMs.value = mp.currentPosition.toLong()
                    }
                }
                delay(300L)
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    private fun notifyState() {
        onPlaybackStateChanged?.invoke(_currentTrack.value, _isPlaying.value, _currentPositionMs.value)
    }

    fun release() {
        stopPositionTicker()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaPlayer = null
    }
}
