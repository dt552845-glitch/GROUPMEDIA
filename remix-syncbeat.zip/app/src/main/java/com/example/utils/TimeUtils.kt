package com.example.utils

import java.util.concurrent.TimeUnit

object TimeUtils {
    fun formatMs(ms: Long): String {
        if (ms <= 0L) return "0:00"
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
        return String.format("%d:%02d", minutes, seconds)
    }
}
