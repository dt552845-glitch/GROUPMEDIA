package com.example.utils

import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ConnectivityState(
    val isWifiEnabled: Boolean = false,
    val isBluetoothEnabled: Boolean = false
) {
    val isBothEnabled: Boolean get() = isWifiEnabled && isBluetoothEnabled
}

class NetworkHardwareManager(private val context: Context) {

    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val bluetoothAdapter: BluetoothAdapter? = try {
        BluetoothAdapter.getDefaultAdapter()
    } catch (e: Exception) {
        null
    }

    private val _connectivityState = MutableStateFlow(checkCurrentState())
    val connectivityState: StateFlow<ConnectivityState> = _connectivityState.asStateFlow()

    private var receiver: BroadcastReceiver? = null

    fun checkCurrentState(): ConnectivityState {
        val wifiOn = wifiManager?.isWifiEnabled == true
        val btOn = bluetoothAdapter?.isEnabled == true
        return ConnectivityState(isWifiEnabled = wifiOn, isBluetoothEnabled = btOn)
    }

    fun startMonitoring(onHardwareStateChanged: (ConnectivityState) -> Unit) {
        stopMonitoring()
        
        // Initial state update
        val initialState = checkCurrentState()
        _connectivityState.value = initialState
        onHardwareStateChanged(initialState)

        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val newState = checkCurrentState()
                _connectivityState.value = newState
                onHardwareStateChanged(newState)
            }
        }

        val filter = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }

        try {
            context.applicationContext.registerReceiver(receiver, filter)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopMonitoring() {
        receiver?.let {
            try {
                context.applicationContext.unregisterReceiver(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        receiver = null
    }

    fun openWifiSettings() {
        try {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    fun openBluetoothSettings() {
        try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }
}
