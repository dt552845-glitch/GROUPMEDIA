package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MusicAppInfo
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary

@Composable
fun LaunchAppSection(
    installedApps: List<MusicAppInfo>,
    onLaunchApp: (MusicAppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("launch_app_system_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MinimalPurpleContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = "Apps",
                            tint = MinimalPurple,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "LAUNCH INSTALLED APP SYSTEM",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MinimalPurpleDark,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Open external music apps directly",
                            style = MaterialTheme.typography.bodySmall,
                            color = MinimalTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(installedApps) { app ->
                    MusicAppItemChip(
                        appInfo = app,
                        onLaunch = { onLaunchApp(app) }
                    )
                }
            }
        }
    }
}

@Composable
fun MusicAppItemChip(
    appInfo: MusicAppInfo,
    onLaunch: () -> Unit
) {
    val (appColor, iconVector) = when (appInfo.appName.lowercase()) {
        "spotify" -> Color(0xFF1DB954) to Icons.Default.MusicNote
        "youtube" -> Color(0xFFFF0000) to Icons.Default.SmartDisplay
        "youtube music" -> Color(0xFFFF0000) to Icons.Default.MusicNote
        "apple music" -> Color(0xFFFA2420) to Icons.Default.MusicNote
        else -> MinimalPurple to Icons.Default.Launch
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(MinimalPurpleContainer.copy(alpha = 0.5f))
            .clickable { onLaunch() }
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("launch_app_chip_${appInfo.appName}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(appColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = iconVector,
                    contentDescription = appInfo.appName,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }

            Column {
                Text(
                    text = appInfo.appName,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MinimalTextPrimary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    softWrap = false
                )
                Text(
                    text = if (appInfo.isInstalled) "Installed • Tap to Launch" else "Available • Tap to Open",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (appInfo.isInstalled) appColor else MinimalTextMuted,
                    fontSize = 9.sp,
                    maxLines = 1,
                    softWrap = false
                )
            }

            Icon(
                imageVector = Icons.Default.OpenInNew,
                contentDescription = "Open",
                tint = MinimalTextSecondary,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}
