package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.PersistentPlaybackControlBar
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HostRoomScreen
import com.example.ui.screens.JoinRoomScreen
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.SyncBeatTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MusicSyncViewModel

class MainActivity : ComponentActivity() {

    private var viewModelRef: MusicSyncViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleSpotifyIntent(intent)
        setContent {
            SyncBeatTheme {
                val context = LocalContext.current
                val viewModel: MusicSyncViewModel = viewModel()
                viewModelRef = viewModel
                val uiState by viewModel.uiState.collectAsState()
                val snackbarHostState = remember { SnackbarHostState() }

                // Request Permissions on launch (Notification for background audio, BT for sync)
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { /* permissions handled gracefully */ }

                LaunchedEffect(Unit) {
                    val permissionsToRequest = mutableListOf<String>()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                            permissionsToRequest.add(Manifest.permission.NEARBY_WIFI_DEVICES)
                        }
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                            permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
                        }
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) {
                            permissionsToRequest.add(Manifest.permission.BLUETOOTH_ADVERTISE)
                        }
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                            permissionsToRequest.add(Manifest.permission.BLUETOOTH_SCAN)
                        }
                    }
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
                    }
                    if (permissionsToRequest.isNotEmpty()) {
                        permissionLauncher.launch(permissionsToRequest.toTypedArray())
                    }
                }

                // Toast/Snackbar notifications
                LaunchedEffect(uiState.toastMessage) {
                    uiState.toastMessage?.let { msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        viewModel.clearToast()
                    }
                }

                // Handle Back Button
                BackHandler(enabled = uiState.currentScreen != AppScreen.Home) {
                    viewModel.navigateTo(AppScreen.Home)
                }

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    bottomBar = {
                        PersistentPlaybackControlBar(
                            track = uiState.currentTrack,
                            isPlaying = uiState.isPlaying,
                            currentPositionMs = uiState.currentPositionMs,
                            durationMs = uiState.durationMs,
                            isHost = uiState.isHost,
                            connectedDeviceCount = uiState.connectedDevices.size,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onSkipPrevious = { viewModel.prevTrack() },
                            onSkipNext = { viewModel.nextTrack() },
                            onBarClicked = {
                                if (uiState.isHost) viewModel.navigateTo(AppScreen.HostRoom)
                                else if (uiState.roomCode.isNotBlank()) viewModel.navigateTo(AppScreen.JoinRoom)
                            }
                        )
                    },
                    containerColor = MinimalBackground,
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    AnimatedContent(
                        targetState = uiState.currentScreen,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "screen_transition",
                        modifier = Modifier.padding(innerPadding)
                    ) { screen ->
                        when (screen) {
                            AppScreen.Home -> {
                                HomeScreen(
                                    uiState = uiState,
                                    viewModel = viewModel
                                )
                            }
                            AppScreen.HostRoom -> {
                                HostRoomScreen(
                                    uiState = uiState,
                                    viewModel = viewModel
                                )
                            }
                            AppScreen.JoinRoom -> {
                                JoinRoomScreen(
                                    uiState = uiState,
                                    viewModel = viewModel
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSpotifyIntent(intent)
    }

    private fun handleSpotifyIntent(intent: android.content.Intent?) {
        val uri = intent?.data ?: return
        viewModelRef?.audioEngine?.spotifyRemoteManager?.handleAuthCallback(uri)
    }
}
