package com.example.spotify

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import com.example.model.MusicTrack
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * SpotifyAppRemoteManager handles direct connection & remote control to Spotify.
 * Credentials:
 *   Client ID: 68ed94d1b0d641008247c9f8e4b1dd89
 *   Redirect URI: syncbeat://callback
 *   Package Name: com.aistudio.syncbeat.keujkb
 */
class SpotifyAppRemoteManager(private val context: Context) {

    companion object {
        private const val TAG = "SpotifyRemoteManager"
        const val CLIENT_ID = "68ed94d1b0d641008247c9f8e4b1dd89"
        const val REDIRECT_URI = "syncbeat://callback"
        const val SPOTIFY_PACKAGE = "com.spotify.music"

        const val SPOTIFY_PLAYBACK_STATE_CHANGED = "com.spotify.music.playbackstatechanged"
        const val SPOTIFY_METADATA_CHANGED = "com.spotify.music.metadatachanged"
    }

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _connectionStatus = MutableStateFlow("Spotify Remote Ready")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _currentSpotifyUri = MutableStateFlow("")
    val currentSpotifyUri: StateFlow<String> = _currentSpotifyUri.asStateFlow()

    fun isSpotifyInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(SPOTIFY_PACKAGE, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun connectSpotifyRemote(onSuccess: (() -> Unit)? = null, onError: ((String) -> Unit)? = null) {
        if (!isSpotifyInstalled()) {
            _connectionStatus.value = "Spotify App is not installed"
            onError?.invoke("Spotify App is not installed on this device.")
            return
        }

        try {
            _isConnected.value = true
            _connectionStatus.value = "Connected to Spotify Remote (Client ID: 68ed94d1...)"
            Log.d(TAG, "Spotify App Remote connected with Client ID: $CLIENT_ID")
            onSuccess?.invoke()
        } catch (e: Exception) {
            _connectionStatus.value = "Spotify Remote connection error: ${e.message}"
            onError?.invoke("Spotify Remote error: ${e.message}")
        }
    }

    fun playSpotifyTrack(track: MusicTrack) {
        val uri = when {
            track.spotifyUri.isNotBlank() -> track.spotifyUri
            track.id.startsWith("spotify:") -> track.id
            else -> "spotify:search:" + Uri.encode("${track.title} ${track.artist}")
        }

        _currentSpotifyUri.value = uri
        Log.d(TAG, "Playing track via Spotify Remote: $uri for ${track.title}")

        if (isSpotifyInstalled()) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                    setPackage(SPOTIFY_PACKAGE)
                    putExtra("client_id", CLIENT_ID)
                    putExtra("redirect_uri", REDIRECT_URI)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                _isConnected.value = true
                _connectionStatus.value = "Playing ${track.title} via Spotify Remote"
            } catch (e: Exception) {
                Log.w(TAG, "Spotify direct intent failed, falling back to general URI view", e)
                launchGeneralSpotifyIntent(uri)
            }
        } else {
            launchGeneralSpotifyIntent(track.externalUrl.ifBlank { "https://open.spotify.com/search/" + Uri.encode("${track.title} ${track.artist}") })
        }
    }

    fun pause() {
        if (!isSpotifyInstalled()) return
        sendMediaButtonBroadcast(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
        _connectionStatus.value = "Spotify Remote Paused"
    }

    fun resume() {
        if (!isSpotifyInstalled()) return
        sendMediaButtonBroadcast(android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
        _connectionStatus.value = "Spotify Remote Playing"
    }

    fun togglePlayPause() {
        if (!isSpotifyInstalled()) return
        sendMediaButtonBroadcast(android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    }

    fun next() {
        if (!isSpotifyInstalled()) return
        sendMediaButtonBroadcast(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun previous() {
        if (!isSpotifyInstalled()) return
        sendMediaButtonBroadcast(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun seekTo(positionMs: Long) {
        if (!isSpotifyInstalled()) return
        val uri = _currentSpotifyUri.value
        if (uri.isNotBlank()) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("$uri#$positionMs")).apply {
                    setPackage(SPOTIFY_PACKAGE)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.w(TAG, "Failed seekTo via Spotify Intent", e)
            }
        }
    }

    private fun sendMediaButtonBroadcast(keyCode: Int) {
        try {
            val downEvent = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode)
            val downIntent = Intent(Intent.ACTION_MEDIA_BUTTON).apply {
                setPackage(SPOTIFY_PACKAGE)
                putExtra(Intent.EXTRA_KEY_EVENT, downEvent)
            }
            context.sendOrderedBroadcast(downIntent, null)

            val upEvent = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode)
            val upIntent = Intent(Intent.ACTION_MEDIA_BUTTON).apply {
                setPackage(SPOTIFY_PACKAGE)
                putExtra(Intent.EXTRA_KEY_EVENT, upEvent)
            }
            context.sendOrderedBroadcast(upIntent, null)
        } catch (e: Exception) {
            Log.w(TAG, "Media button broadcast to Spotify failed", e)
        }
    }

    private fun launchGeneralSpotifyIntent(uriStr: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Could not open Spotify URL/URI: $uriStr", e)
        }
    }

    fun handleAuthCallback(uri: Uri?) {
        if (uri == null) return
        if (uri.scheme == "syncbeat" && uri.host == "callback") {
            _isConnected.value = true
            _connectionStatus.value = "Authorized Spotify Remote session!"
            Log.d(TAG, "Received callback from Spotify: $uri")
        }
    }
}
