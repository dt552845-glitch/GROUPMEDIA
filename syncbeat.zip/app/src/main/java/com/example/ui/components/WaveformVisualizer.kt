package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleLight
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun WaveformVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 28,
    activeColor: Color = MinimalPurple,
    inactiveColor: Color = MinimalPurpleLight.copy(alpha = 0.3f)
) {
    val barHeights = remember { List(barCount) { Animatable(if (isPlaying) Random.nextFloat() * 0.8f + 0.2f else 0.15f) } }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            barHeights.forEachIndexed { index, animatable ->
                launch {
                    val target = Random.nextFloat() * 0.85f + 0.15f
                    animatable.animateTo(
                        targetValue = target,
                        animationSpec = infiniteRepeatable(
                            animation = tween(
                                durationMillis = 250 + (index % 5) * 60,
                                easing = FastOutSlowInEasing
                            ),
                            repeatMode = RepeatMode.Reverse
                        )
                    )
                }
            }
        } else {
            barHeights.forEach { animatable ->
                launch {
                    animatable.animateTo(0.12f, animationSpec = tween(300))
                }
            }
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(36.dp)
    ) {
        val width = size.width
        val height = size.height
        val totalSpacing = width * 0.25f
        val barWidth = (width - totalSpacing) / barCount
        val spacing = totalSpacing / (barCount - 1).coerceAtLeast(1)

        barHeights.forEachIndexed { i, anim ->
            val h = height * anim.value
            val x = i * (barWidth + spacing)
            val y = (height - h) / 2f
            drawRoundRect(
                color = if (isPlaying) activeColor else inactiveColor,
                topLeft = Offset(x, y),
                size = Size(barWidth, h),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
