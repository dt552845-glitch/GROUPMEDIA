package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Default template colors
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Modern Minimalist Violet/Purple Palette for SyncBeat
val MinimalBackground = Color(0xFFFAF8FF)
val MinimalSurface = Color(0xFFFFFFFF)
val MinimalPurple = Color(0xFF7C3AED)
val MinimalPurpleDark = Color(0xFF5B21B6)
val MinimalPurpleLight = Color(0xFFA78BFA)
val MinimalPurpleContainer = Color(0xFFF3E8FF)
val MinimalOnPurpleContainer = Color(0xFF4C1D95)

val MinimalTextPrimary = Color(0xFF1E1B4B)
val MinimalTextSecondary = Color(0xFF6B7280)
val MinimalTextMuted = Color(0xFF9CA3AF)

val MinimalBorder = Color(0xFFE9D5FF)
val MinimalBorderLight = Color(0xFFF3F4F6)

val StatusActive = Color(0xFF10B981)
val StatusError = Color(0xFFEF4444)
