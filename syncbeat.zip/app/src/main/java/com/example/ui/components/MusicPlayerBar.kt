package com.example.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.model.MusicTrack

@Composable
fun MusicPlayerBar(
    track: MusicTrack?,
    isPlaying: Boolean,
    isBuffering: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    volume: Float,
    isHost: Boolean = true,
    onTogglePlayPause: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSkipNext: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onOpenPlatform: (MusicTrack, String) -> Unit,
    modifier: Modifier = Modifier
) {
    HeroMusicPlayerCard(
        track = track,
        isPlaying = isPlaying,
        isBuffering = isBuffering,
        currentPositionMs = currentPositionMs,
        durationMs = durationMs,
        volume = volume,
        isHost = isHost,
        onTogglePlayPause = onTogglePlayPause,
        onSkipPrevious = onSkipPrevious,
        onSkipNext = onSkipNext,
        onSeekTo = onSeekTo,
        onVolumeChange = onVolumeChange,
        onOpenPlatform = onOpenPlatform,
        modifier = modifier
    )
}
