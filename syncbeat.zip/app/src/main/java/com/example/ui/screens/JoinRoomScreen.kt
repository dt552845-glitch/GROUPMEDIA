package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConnectionStatus
import com.example.ui.components.HeroMusicPlayerCard
import com.example.ui.components.LaunchAppSection
import com.example.ui.components.MediaSearchCard
import com.example.ui.components.RestrictedConnectivityDialog
import com.example.ui.components.VolumeControllerCard
import com.example.ui.theme.MinimalBackground
import com.example.ui.theme.MinimalBorder
import com.example.ui.theme.MinimalBorderLight
import com.example.ui.theme.MinimalPurple
import com.example.ui.theme.MinimalPurpleContainer
import com.example.ui.theme.MinimalPurpleDark
import com.example.ui.theme.MinimalSurface
import com.example.ui.theme.MinimalTextMuted
import com.example.ui.theme.MinimalTextPrimary
import com.example.ui.theme.MinimalTextSecondary
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusError
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MusicSyncUiState
import com.example.viewmodel.MusicSyncViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JoinRoomScreen(
    uiState: MusicSyncUiState,
    viewModel: MusicSyncViewModel,
    modifier: Modifier = Modifier
) {
    if (uiState.isRestrictedDialogVisible) {
        RestrictedConnectivityDialog(
            isWifiEnabled = uiState.isWifiEnabled,
            isBluetoothEnabled = uiState.isBluetoothEnabled,
            reasonMessage = uiState.restrictedDialogReason,
            onOpenWifiSettings = { viewModel.openWifiSettings() },
            onOpenBluetoothSettings = { viewModel.openBluetoothSettings() },
            onDismiss = { viewModel.dismissRestrictedDialog() }
        )
    }

    val isConnected = uiState.connectionStatus == ConnectionStatus.CONNECTED_AS_CLIENT || uiState.roomCode.isNotBlank()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MinimalBackground)
    ) {
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = if (isConnected) "Connected Party Room" else "Join Party Room",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = if (isConnected) "Room ${uiState.roomCode}   Latency ${uiState.syncDriftMs}ms" else "Enter a live host's generated room code",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalTextSecondary,
                        fontSize = 11.sp
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.Home) },
                    modifier = Modifier.testTag("join_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MinimalTextPrimary
                    )
                }
            },
            actions = {
                if (isConnected) {
                    IconButton(
                        onClick = { viewModel.exitPartyRoom() },
                        modifier = Modifier.testTag("join_exit_top_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Exit Room",
                            tint = StatusError
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MinimalBackground)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // IF CONNECTED: Connected Room Status Card
            if (isConnected) {
                item {
                    ConnectedClientSessionCard(
                        roomCode = uiState.roomCode,
                        hostName = uiState.hostDeviceName,
                        latencyMs = uiState.syncDriftMs,
                        onResync = { viewModel.requestSyncRefresh() },
                        onExitRoom = { viewModel.exitPartyRoom() }
                    )
                }

                // Client Hero Music Player Card (Receives and plays synced audio stream)
                item {
                    HeroMusicPlayerCard(
                        track = uiState.currentTrack,
                        isPlaying = uiState.isPlaying,
                        isBuffering = uiState.isBuffering,
                        currentPositionMs = uiState.currentPositionMs,
                        durationMs = uiState.durationMs,
                        volume = uiState.volume,
                        isHost = false,
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSkipPrevious = { viewModel.prevTrack() },
                        onSkipNext = { viewModel.nextTrack() },
                        onSeekTo = { viewModel.seekTo(it) },
                        onVolumeChange = { viewModel.setVolume(it) },
                        onOpenPlatform = { track, platform -> viewModel.openTrackInPlatform(track, platform) }
                    )
                }

                // Volume Controller Card (Client mode)
                item {
                    VolumeControllerCard(
                        volume = uiState.volume,
                        isHost = false,
                        onVolumeChange = { viewModel.setVolume(it) }
                    )
                }

                // Listener Reactions Bar
                item {
                    ClientListenerReactionsBar(
                        onSendReaction = { emoji -> viewModel.sendListenerReaction(emoji) }
                    )
                }
            } else {
                // IF NOT CONNECTED: Code Entry Card
                item {
                    JoinCodeInputCard(
                        codeInput = uiState.joinCodeInput,
                        connectionStatus = uiState.connectionStatus,
                        errorMessage = uiState.joinErrorMessage,
                        onCodeChange = { viewModel.updateJoinCodeInput(it) },
                        onConnect = { viewModel.connectThroughCode() }
                    )
                }
            }

            // Media Search (In-App Search & Play)
            item {
                MediaSearchCard(
                    searchQuery = uiState.searchQuery,
                    selectedPlatformFilter = uiState.selectedPlatformFilter,
                    searchResults = uiState.searchResults,
                    isSearching = uiState.isSearching,
                    onQueryChange = { viewModel.updateSearchQuery(it) },
                    onSearchClick = { viewModel.searchMedia() },
                    onFilterSelect = { viewModel.setPlatformFilter(it) },
                    onPlayTrack = { viewModel.playTrack(it) },
                    onOpenPlatform = { track, platform -> viewModel.openTrackInPlatform(track, platform) },
                    onAddToQueue = { viewModel.addToQueue(it) }
                )
            }

            // Launch App System
            item {
                LaunchAppSection(
                    installedApps = uiState.installedApps,
                    onLaunchApp = { viewModel.launchMusicApp(it) }
                )
            }

            // Telemetry Card
            item {
                ClientNearbyStatusCard(
                    statusText = uiState.nearbyStatus,
                    driftMs = uiState.syncDriftMs
                )
            }
        }
    }
}

@Composable
fun ConnectedClientSessionCard(
    roomCode: String,
    hostName: String,
    latencyMs: Long,
    onResync: () -> Unit,
    onExitRoom: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalPurpleContainer),
        border = BorderStroke(1.5.dp, MinimalPurple),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("connected_client_session_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(StatusActive)
                    )
                    Text(
                        text = "CONNECTED TO ROOM",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusActive,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MinimalSurface)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Latency $latencyMs ms",
                        style = MaterialTheme.typography.labelSmall,
                        color = MinimalPurpleDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Room $roomCode",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MinimalPurpleDark,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "Host Master: $hostName",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        fontSize = 12.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Connected",
                    tint = StatusActive,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onResync,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MinimalPurpleDark),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("resync_audio_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Resync",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Resync Audio", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onExitRoom,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("exit_party_room_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "Exit",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Exit Room", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun JoinCodeInputCard(
    codeInput: String,
    connectionStatus: ConnectionStatus,
    errorMessage: String?,
    onCodeChange: (String) -> Unit,
    onConnect: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, if (errorMessage != null) StatusError else MinimalBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("join_code_input_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MinimalPurpleContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = "Room Code",
                        tint = MinimalPurple,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Column {
                    Text(
                        text = "Enter Real-Time Room Code",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MinimalTextPrimary
                    )
                    Text(
                        text = "Ask the Host DJ for their generated 4-character code",
                        style = MaterialTheme.typography.bodySmall,
                        color = MinimalTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = codeInput,
                onValueChange = onCodeChange,
                placeholder = {
                    Text("SYNC-4B9X", color = MinimalTextMuted, fontWeight = FontWeight.Bold)
                },
                singleLine = true,
                isError = errorMessage != null,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { onConnect() }),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MinimalSurface,
                    unfocusedContainerColor = MinimalSurface,
                    focusedBorderColor = MinimalPurple,
                    unfocusedBorderColor = MinimalBorder,
                    focusedTextColor = MinimalTextPrimary,
                    unfocusedTextColor = MinimalTextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("join_screen_code_input_field")
            )

            AnimatedVisibility(visible = errorMessage != null) {
                if (errorMessage != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(StatusError.copy(alpha = 0.12f))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Error",
                            tint = StatusError,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusError,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onConnect,
                enabled = connectionStatus != ConnectionStatus.CONNECTING,
                colors = ButtonDefaults.buttonColors(containerColor = MinimalPurple),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("join_screen_connect_button")
            ) {
                if (connectionStatus == ConnectionStatus.CONNECTING) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Connecting to Host...", color = Color.White, fontWeight = FontWeight.Bold)
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CastConnected,
                            contentDescription = "Connect",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CONNECT TO PARTY ROOM",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ClientListenerReactionsBar(
    onSendReaction: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "SEND REACTION SIGNAL TO ROOM",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MinimalPurpleDark,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val reactions = listOf("🔥", "🎵", "❤️", "⚡", "🙌", "🎉")
                reactions.forEach { emoji ->
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MinimalPurpleContainer)
                            .clickable { onSendReaction(emoji) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = emoji, fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ClientNearbyStatusCard(
    statusText: String,
    driftMs: Long
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MinimalSurface),
        border = BorderStroke(1.dp, MinimalBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Sensors,
                contentDescription = "Nearby",
                tint = MinimalPurple,
                modifier = Modifier.size(20.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MinimalTextSecondary,
                    fontSize = 11.sp
                )
                Text(
                    text = "Clock Drift Compensation: $driftMs ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = MinimalTextMuted,
                    fontSize = 10.sp
                )
            }
        }
    }
}
