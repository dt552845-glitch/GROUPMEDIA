package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.PowerManager
import android.util.Log
import com.example.model.MusicTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AudioPlaybackEngine(private val context: Context) {
    companion object {
        private const val TAG = "AudioPlaybackEngine"
    }

    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var positionTickerJob: Job? = null

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    private val _currentTrack = MutableStateFlow<MusicTrack?>(null)
    val currentTrack: StateFlow<MusicTrack?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(180000L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _volume = MutableStateFlow(0.85f)
    val volume: StateFlow<Float> = _volume.asStateFlow()

    var onPlaybackStateChanged: ((MusicTrack?, Boolean, Long) -> Unit)? = null
    var onTrackEnded: (() -> Unit)? = null

    val spotifyRemoteManager = com.example.spotify.SpotifyAppRemoteManager(context)

    private val audioFocusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                Log.d(TAG, "Audio focus lost permanently")
                pause()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                Log.d(TAG, "Audio focus lost transiently")
                pause()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                Log.d(TAG, "Audio focus ducking")
                mediaPlayer?.setVolume(0.2f, 0.2f)
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                Log.d(TAG, "Audio focus gained")
                mediaPlayer?.setVolume(_volume.value, _volume.value)
                resume()
            }
        }
    }

    init {
        initMediaPlayer()
    }

    private fun requestAudioFocus(): Boolean {
        if (audioManager == null) return true
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(playbackAttributes)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(audioFocusChangeListener)
                .build()
            audioFocusRequest = focusRequest
            audioManager.requestAudioFocus(focusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                audioFocusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }

    private fun abandonAudioFocus() {
        if (audioManager == null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(audioFocusChangeListener)
        }
    }

    private fun initMediaPlayer() {
        release()
        mediaPlayer = MediaPlayer().apply {
            try {
                setWakeMode(context.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            } catch (e: Exception) {
                Log.w(TAG, "Could not set wake mode on MediaPlayer: ${e.message}")
            }
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            setOnPreparedListener { mp ->
                _isBuffering.value = false
                _durationMs.value = mp.duration.toLong().coerceAtLeast(1000L)
                if (requestAudioFocus()) {
                    mp.start()
                    _isPlaying.value = true
                    startPositionTicker()
                    notifyState()
                }
            }
            setOnCompletionListener {
                _isPlaying.value = false
                _currentPositionMs.value = _durationMs.value
                stopPositionTicker()
                abandonAudioFocus()
                notifyState()
                onTrackEnded?.invoke()
            }
            setOnErrorListener { _, _, _ ->
                _isBuffering.value = false
                _isPlaying.value = false
                stopPositionTicker()
                abandonAudioFocus()
                true
            }
            setVolume(_volume.value, _volume.value)
        }
    }

    fun playTrack(track: MusicTrack) {
        _currentTrack.value = track
        _isBuffering.value = true
        _isPlaying.value = false
        _currentPositionMs.value = 0L

        if (track.source.equals("Spotify", ignoreCase = true) || track.spotifyUri.isNotBlank()) {
            try {
                spotifyRemoteManager.playSpotifyTrack(track)
            } catch (e: Exception) {
                Log.w(TAG, "Spotify Remote playback launch failed: ${e.message}")
            }
        }

        try {
            if (mediaPlayer == null) {
                initMediaPlayer()
            } else {
                mediaPlayer?.reset()
            }
            try {
                mediaPlayer?.setWakeMode(context.applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            } catch (_: Exception) {}

            mediaPlayer?.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )

            val streamUrlToUse = when {
                track.streamUrl.isNotBlank() -> track.streamUrl
                else -> "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
            }
            mediaPlayer?.setDataSource(streamUrlToUse)
            mediaPlayer?.prepareAsync()
        } catch (e: Exception) {
            Log.e(TAG, "MediaPlayer setDataSource error: ${e.message}")
            _isBuffering.value = false
            _isPlaying.value = false
        }
    }

    fun togglePlayPause() {
        if (_isPlaying.value) {
            pause()
        } else {
            resume()
        }
    }

    fun pause() {
        _currentTrack.value?.let { track ->
            if (track.source.equals("Spotify", ignoreCase = true) || track.spotifyUri.isNotBlank()) {
                spotifyRemoteManager.pause()
            }
        }
        val player = mediaPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            _isPlaying.value = false
            stopPositionTicker()
            abandonAudioFocus()
            notifyState()
        }
    }

    fun resume() {
        _currentTrack.value?.let { track ->
            if (track.source.equals("Spotify", ignoreCase = true) || track.spotifyUri.isNotBlank()) {
                spotifyRemoteManager.resume()
            }
        }
        val player = mediaPlayer ?: return
        if (!player.isPlaying && _currentTrack.value != null) {
            if (requestAudioFocus()) {
                player.start()
                _isPlaying.value = true
                startPositionTicker()
                notifyState()
            }
        } else if (_currentTrack.value == null) {
            com.example.model.MusicTrackCatalog.defaultTracks.firstOrNull()?.let {
                playTrack(it)
            }
        }
    }

    fun seekTo(positionMs: Long) {
        _currentTrack.value?.let { track ->
            if (track.source.equals("Spotify", ignoreCase = true) || track.spotifyUri.isNotBlank()) {
                spotifyRemoteManager.seekTo(positionMs)
            }
        }
        val player = mediaPlayer ?: return
        try {
            player.seekTo(positionMs.toInt())
            _currentPositionMs.value = positionMs
            notifyState()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVolume(vol: Float) {
        val clamped = vol.coerceIn(0f, 1f)
        _volume.value = clamped
        mediaPlayer?.setVolume(clamped, clamped)
    }

    private fun startPositionTicker() {
        stopPositionTicker()
        positionTickerJob = scope.launch {
            while (isActive && _isPlaying.value) {
                mediaPlayer?.let { mp ->
                    if (mp.isPlaying) {
                        _currentPositionMs.value = mp.currentPosition.toLong()
                    }
                }
                delay(300L)
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    private fun notifyState() {
        onPlaybackStateChanged?.invoke(_currentTrack.value, _isPlaying.value, _currentPositionMs.value)
    }

    fun release() {
        stopPositionTicker()
        abandonAudioFocus()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaPlayer = null
    }
}
