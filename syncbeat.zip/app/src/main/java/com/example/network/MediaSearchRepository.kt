package com.example.network

import com.example.model.MusicTrack
import com.example.model.MusicTrackCatalog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class MediaSearchRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    suspend fun searchMedia(query: String, platformFilter: String = "All"): List<MusicTrack> = withContext(Dispatchers.IO) {
        if (query.isBlank()) {
            return@withContext filterByPlatform(MusicTrackCatalog.defaultTracks, platformFilter)
        }

        val results = mutableListOf<MusicTrack>()

        // 1. Search local default catalog first for matching keywords
        val lowerQuery = query.lowercase().trim()
        val localMatches = MusicTrackCatalog.defaultTracks.filter { track ->
            track.title.lowercase().contains(lowerQuery) ||
                    track.artist.lowercase().contains(lowerQuery) ||
                    track.album.lowercase().contains(lowerQuery)
        }
        results.addAll(localMatches)

        // 2. Query iTunes Public Search API for real live music streams, artwork, and metadata
        try {
            val encodedQuery = URLEncoder.encode(query.trim(), "UTF-8")
            val url = "https://itunes.apple.com/search?term=$encodedQuery&media=music&entity=song&limit=25"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "SyncBeat/1.0")
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val bodyString = response.body?.string()
                if (!bodyString.isNullOrBlank()) {
                    val json = JSONObject(bodyString)
                    val jsonArray = json.optJSONArray("results")
                    if (jsonArray != null) {
                        for (i in 0 until jsonArray.length()) {
                            val item = jsonArray.optJSONObject(i) ?: continue
                            val trackName = item.optString("trackName", "")
                            val artistName = item.optString("artistName", "")
                            val collectionName = item.optString("collectionName", "")
                            val previewUrl = item.optString("previewUrl", "")
                            var artworkUrl = item.optString("artworkUrl100", "")
                            if (artworkUrl.isNotBlank()) {
                                artworkUrl = artworkUrl.replace("100x100bb.jpg", "600x600bb.jpg")
                            }
                            val trackId = item.optLong("trackId", 0L).toString()
                            val durationMs = item.optLong("trackTimeMillis", 180000L)
                            val primarySource = when {
                                i % 3 == 0 -> "Spotify"
                                i % 3 == 1 -> "YouTube Music"
                                else -> "YouTube"
                            }

                            if (trackName.isNotBlank()) {
                                val validStreamUrl = if (previewUrl.isNotBlank()) {
                                    previewUrl
                                } else {
                                    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
                                }

                                val encodedSearch = URLEncoder.encode("$trackName $artistName", "UTF-8")
                                val generatedSpotifyUri = "spotify:search:$encodedSearch"
                                val generatedExternalUrl = "https://open.spotify.com/search/$encodedSearch"

                                results.add(
                                    MusicTrack(
                                        id = "api_$trackId",
                                        title = trackName,
                                        artist = artistName,
                                        album = collectionName,
                                        albumArtUrl = artworkUrl,
                                        streamUrl = validStreamUrl,
                                        durationMs = durationMs,
                                        source = primarySource,
                                        externalUrl = generatedExternalUrl,
                                        spotifyUri = generatedSpotifyUri
                                    )
                                )
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val distinctList = results.distinctBy { "${it.title.lowercase()}_${it.artist.lowercase()}" }
        filterByPlatform(distinctList.ifEmpty { MusicTrackCatalog.defaultTracks }, platformFilter)
    }

    private fun filterByPlatform(tracks: List<MusicTrack>, platformFilter: String): List<MusicTrack> {
        if (platformFilter.equals("All", ignoreCase = true)) return tracks
        return tracks.map { track ->
            if (track.source.equals(platformFilter, ignoreCase = true)) {
                track
            } else {
                track.copy(source = platformFilter)
            }
        }
    }
}
