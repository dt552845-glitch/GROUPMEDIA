package com.example.utils

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.example.model.MusicAppInfo
import com.example.model.MusicTrack

object MusicAppLauncher {
    val supportedMusicApps = listOf(
        MusicAppInfo(
            appName = "Spotify",
            packageName = "com.spotify.music",
            deepLinkUri = "spotify://",
            storeUrl = "https://play.google.com/store/apps/details?id=com.spotify.music"
        ),
        MusicAppInfo(
            appName = "YouTube",
            packageName = "com.google.android.youtube",
            deepLinkUri = "https://www.youtube.com",
            storeUrl = "https://play.google.com/store/apps/details?id=com.google.android.youtube"
        ),
        MusicAppInfo(
            appName = "YouTube Music",
            packageName = "com.google.android.apps.youtube.music",
            deepLinkUri = "https://music.youtube.com",
            storeUrl = "https://play.google.com/store/apps/details?id=com.google.android.apps.youtube.music"
        ),
        MusicAppInfo(
            appName = "Apple Music",
            packageName = "com.apple.android.music",
            deepLinkUri = "https://music.apple.com",
            storeUrl = "https://play.google.com/store/apps/details?id=com.apple.android.music"
        ),
        MusicAppInfo(
            appName = "SoundCloud",
            packageName = "com.soundcloud.android",
            deepLinkUri = "soundcloud://",
            storeUrl = "https://play.google.com/store/apps/details?id=com.soundcloud.android"
        ),
        MusicAppInfo(
            appName = "Amazon Music",
            packageName = "com.amazon.mp3",
            deepLinkUri = "https://music.amazon.com",
            storeUrl = "https://play.google.com/store/apps/details?id=com.amazon.mp3"
        )
    )

    fun getInstalledApps(context: Context): List<MusicAppInfo> {
        val pm = context.packageManager
        return supportedMusicApps.map { app ->
            val isInstalled = isPackageInstalled(pm, app.packageName)
            app.copy(isInstalled = isInstalled)
        }
    }

    private fun isPackageInstalled(pm: PackageManager, packageName: String): Boolean {
        return try {
            pm.getPackageInfo(packageName, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun launchApp(context: Context, appInfo: MusicAppInfo) {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(appInfo.deepLinkUri.ifBlank { appInfo.storeUrl }))
            webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(webIntent)
            } catch (e: Exception) {
                val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse(appInfo.storeUrl))
                storeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(storeIntent)
            }
        }
    }

    fun openTrackInPlatform(context: Context, track: MusicTrack, platform: String) {
        val searchQuery = Uri.encode("${track.title} ${track.artist}")
        val url = when (platform.lowercase()) {
            "spotify" -> "https://open.spotify.com/search/$searchQuery"
            "youtube" -> "https://www.youtube.com/results?search_query=$searchQuery"
            "youtube music" -> "https://music.youtube.com/search?q=$searchQuery"
            "apple music", "itunes" -> "https://music.apple.com/us/search?term=$searchQuery"
            else -> track.externalUrl.ifBlank { "https://open.spotify.com/search/$searchQuery" }
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback
        }
    }
}
