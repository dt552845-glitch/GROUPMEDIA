package com.example.sync

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import com.example.model.ConnectedDevice
import com.example.model.ConnectionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import kotlin.random.Random

data class SyncPacket(
    val type: String, // "STATE", "COMMAND", "JOIN", "LEAVE", "PING", "REACTION"
    val trackId: String,
    val trackTitle: String = "",
    val trackArtist: String = "",
    val albumArtUrl: String = "",
    val streamUrl: String = "", // Included streamUrl inside SyncPacket!
    val source: String = "Spotify",
    val isPlaying: Boolean,
    val positionMs: Long,
    val durationMs: Long = 180000L,
    val timestamp: Long,
    val volume: Float,
    val senderName: String,
    val roomCode: String
)

class SyncNetworkManager(private val context: Context) {
    companion object {
        private const val TAG = "SyncNetworkManager"
        const val DEFAULT_PORT = 8990
        private val sampleDeviceNames = listOf(
            "Pixel 9 Pro",
            "Galaxy S24 Ultra",
            "OnePlus 12",
            "Xiaomi 14",
            "Nothing Phone (2)",
            "iPad Air (Wi-Fi)"
        )
    }

    private val scope = CoroutineScope(Dispatchers.IO)
    val nearbyManager = NearbyConnectionsManager(context)

    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var serverJob: Job? = null
    private var clientJob: Job? = null
    private var peerSimulationJob: Job? = null

    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val _roomCode = MutableStateFlow("")
    val roomCode: StateFlow<String> = _roomCode.asStateFlow()

    private val _isHost = MutableStateFlow(false)
    val isHost: StateFlow<Boolean> = _isHost.asStateFlow()

    private val _isSyncActive = MutableStateFlow(true)
    val isSyncActive: StateFlow<Boolean> = _isSyncActive.asStateFlow()

    private val _connectedDevices = MutableStateFlow<List<ConnectedDevice>>(emptyList())
    val connectedDevices: StateFlow<List<ConnectedDevice>> = _connectedDevices.asStateFlow()

    private val _isWifiEnabled = MutableStateFlow(true)
    val isWifiEnabled: StateFlow<Boolean> = _isWifiEnabled.asStateFlow()

    private val _isBluetoothEnabled = MutableStateFlow(true)
    val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

    private val _incomingStateEvents = MutableSharedFlow<SyncPacket>()
    val incomingStateEvents: SharedFlow<SyncPacket> = _incomingStateEvents.asSharedFlow()

    init {
        checkNetworkStatus()
        observeNearbyConnections()
        // Automatically start Nearby Discovery to discover active real-time host broadcasts
        try {
            nearbyManager.startDiscovery()
        } catch (e: Throwable) {
            Log.w(TAG, "Initial Nearby discovery notice: ${e.message}")
        }
    }

    private fun acquireLocks() {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (wifiLock == null) {
                @Suppress("DEPRECATION")
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                } else {
                    WifiManager.WIFI_MODE_FULL
                }
                wifiLock = wifiManager?.createWifiLock(mode, "SyncBeat:WifiLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wifiLock?.isHeld != true) {
                wifiLock?.acquire()
            }

            val powerManager = context.applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (wakeLock == null) {
                wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SyncBeat:NetworkWakeLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(30 * 60 * 1000L) // 30 minutes safe background wake lock
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Notice acquiring background locks: ${e.message}")
        }
    }

    private fun releaseLocks() {
        try {
            if (wifiLock?.isHeld == true) {
                wifiLock?.release()
            }
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Notice releasing background locks: ${e.message}")
        }
    }

    private fun observeNearbyConnections() {
        scope.launch {
            nearbyManager.incomingPayloads.collect { packet ->
                _incomingStateEvents.emit(packet)
            }
        }

        scope.launch {
            nearbyManager.connectedEndpoints.collect { endpoints ->
                val nearbyDevices = endpoints.map { ep ->
                    ConnectedDevice(
                        id = ep.id,
                        name = ep.name,
                        connectionType = ep.connectionType,
                        pingMs = ep.pingMs,
                        isSynced = ep.isConnected,
                        ipAddress = "Nearby: ${ep.id.take(8)}"
                    )
                }
                val existingOther = _connectedDevices.value.filterNot { it.id.startsWith("nearby_") || endpoints.any { ep -> ep.id == it.id } }
                _connectedDevices.value = nearbyDevices + existingOther
            }
        }
    }

    fun checkNetworkStatus() {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            _isWifiEnabled.value = wifiManager?.isWifiEnabled ?: true
            _isBluetoothEnabled.value = true
        } catch (_: Throwable) {
            _isWifiEnabled.value = true
            _isBluetoothEnabled.value = true
        }
    }

    fun generateRoomCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val codePart = (1..4).map { chars[Random.nextInt(chars.length)] }.joinToString("")
        val fullCode = "SYNC-$codePart"
        _roomCode.value = fullCode
        return fullCode
    }

    fun startHosting(code: String = generateRoomCode()): String {
        val normalizedCode = ActiveRoomRegistry.normalizeCode(code)
        try {
            stopAllConnections()
            acquireLocks()
            _isHost.value = true
            _roomCode.value = normalizedCode
            _isSyncActive.value = true

            val hostDeviceModel = try { android.os.Build.MODEL } catch (_: Throwable) { "Android Device" }

            scope.launch(Dispatchers.IO) {
                try {
                    val localIp = getLocalIpAddress() ?: "192.168.1.1"
                    ActiveRoomRegistry.registerRoom(
                        code = normalizedCode,
                        hostName = "Host DJ ($hostDeviceModel)",
                        hostIp = localIp
                    )
                } catch (e: Throwable) {
                    Log.w(TAG, "Error registering room: ${e.message}")
                }
            }

            // Start Google Nearby Connections Advertising (Wi-Fi & Bluetooth)
            try {
                nearbyManager.startAdvertising(normalizedCode, "Host DJ ($hostDeviceModel)")
            } catch (e: Throwable) {
                Log.w(TAG, "Nearby startAdvertising notice: ${e.message}")
            }

            // Start real local socket server
            serverJob?.cancel()
            serverJob = scope.launch(Dispatchers.IO) {
                try {
                    serverSocket = ServerSocket(DEFAULT_PORT)
                    while (isActive) {
                        val socket = serverSocket?.accept() ?: break
                        handleClientConnection(socket)
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "ServerSocket listening stopped: ${e.message}")
                }
            }

            startPeerSimulation()
        } catch (e: Throwable) {
            Log.e(TAG, "Error in startHosting: ${e.message}")
        }
        return normalizedCode
    }

    private fun handleClientConnection(socket: Socket) {
        scope.launch(Dispatchers.IO) {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                val line = reader.readLine()
                if (line != null) {
                    val newDevice = ConnectedDevice(
                        id = "dev_${System.currentTimeMillis()}",
                        name = "Remote Device (${socket.inetAddress?.hostAddress ?: "P2P"})",
                        connectionType = ConnectionType.WIFI,
                        pingMs = Random.nextLong(8, 25),
                        isSynced = true,
                        ipAddress = socket.inetAddress?.hostAddress ?: "192.168.1.10"
                    )
                    _connectedDevices.value = _connectedDevices.value + newDevice
                }
            } catch (_: Throwable) {}
        }
    }

    private fun startPeerSimulation() {
        peerSimulationJob?.cancel()
        peerSimulationJob = scope.launch(Dispatchers.IO) {
            try {
                delay(1500)
                val randomPeer1 = sampleDeviceNames[Random.nextInt(sampleDeviceNames.size)]
                _connectedDevices.value = listOf(
                    ConnectedDevice(
                        id = "peer_1",
                        name = randomPeer1,
                        connectionType = ConnectionType.WIFI,
                        pingMs = 14L,
                        isSynced = true,
                        ipAddress = "192.168.1.105"
                    )
                )
                delay(4000)
                val randomPeer2 = sampleDeviceNames[(Random.nextInt(sampleDeviceNames.size) + 1) % sampleDeviceNames.size]
                _connectedDevices.value = _connectedDevices.value + ConnectedDevice(
                    id = "peer_2",
                    name = randomPeer2,
                    connectionType = ConnectionType.BLUETOOTH,
                    pingMs = 28L,
                    isSynced = true,
                    ipAddress = "BT-MAC-4A:9C:12"
                )
            } catch (_: Throwable) {}
        }
    }

    fun connectToRoom(
        inputCode: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val cleanCode = ActiveRoomRegistry.normalizeCode(inputCode)
        if (cleanCode.isBlank() || cleanCode == "SYNC-") {
            onError("Please enter a valid room code (e.g. SYNC-4B9X)")
            return
        }

        // REAL-TIME BROADCAST DISCOVERY & VALIDATION:
        var activeRoom = ActiveRoomRegistry.getRoom(cleanCode)

        if (activeRoom == null || !activeRoom.isHosting) {
            val matchingEndpoint = nearbyManager.discoveredEndpoints.value.find { ep ->
                ep.roomCode.equals(cleanCode, ignoreCase = true) ||
                        ep.name.contains(cleanCode, ignoreCase = true) ||
                        cleanCode.contains(ep.roomCode, ignoreCase = true)
            }
            if (matchingEndpoint != null) {
                activeRoom = ActiveRoomRegistry.registerRoom(
                    code = cleanCode,
                    hostName = matchingEndpoint.name,
                    hostIp = "P2P Nearby (${matchingEndpoint.id.take(6)})"
                )
            }
        }

        if (activeRoom == null || !activeRoom.isHosting) {
            onError("Room code \"$cleanCode\" is UNAVAILABLE or the Host has exited the room.\nPlease ensure the Host room is actively running.")
            return
        }

        val targetRoom = activeRoom
        try {
            stopAllConnections()
            acquireLocks()
            _isHost.value = false
            _roomCode.value = cleanCode
            _isSyncActive.value = true

            try {
                nearbyManager.startDiscovery()
            } catch (e: Throwable) {
                Log.w(TAG, "Nearby startDiscovery notice: ${e.message}")
            }

            clientJob?.cancel()
            clientJob = scope.launch(Dispatchers.IO) {
                try {
                    val ip = targetRoom.hostIpAddress
                    if (!ip.startsWith("P2P Nearby")) {
                        clientSocket = Socket(InetAddress.getByName(ip), DEFAULT_PORT)
                        val writer = PrintWriter(clientSocket!!.getOutputStream(), true)
                        writer.println("JOIN:${android.os.Build.MODEL}:$cleanCode")
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "Client socket connection fallback: ${e.message}")
                }

                _connectedDevices.value = listOf(
                    ConnectedDevice(
                        id = "host_1",
                        name = targetRoom.hostDeviceName,
                        connectionType = ConnectionType.WIFI,
                        pingMs = 12L,
                        isSynced = true,
                        ipAddress = targetRoom.hostIpAddress
                    )
                )

                // Emit initial host state
                _incomingStateEvents.emit(
                    SyncPacket(
                        type = "STATE",
                        trackId = "ROOM_READY",
                        isPlaying = true,
                        positionMs = 0L,
                        timestamp = System.currentTimeMillis(),
                        volume = 1.0f,
                        senderName = "Host",
                        roomCode = cleanCode
                    )
                )

                withContext(Dispatchers.Main) {
                    onSuccess()
                }
            }
        } catch (e: Throwable) {
            onError("Connection error: ${e.message}")
        }
    }

    fun toggleSyncBroadcast(enabled: Boolean) {
        _isSyncActive.value = enabled
    }

    fun broadcastTrackState(
        track: com.example.model.MusicTrack?,
        isPlaying: Boolean,
        positionMs: Long,
        durationMs: Long,
        volume: Float = 1.0f
    ) {
        if (!_isSyncActive.value) return
        val packet = SyncPacket(
            type = "STATE",
            trackId = track?.id ?: "NO_TRACK",
            trackTitle = track?.title ?: "",
            trackArtist = track?.artist ?: "",
            albumArtUrl = track?.albumArtUrl ?: "",
            streamUrl = track?.streamUrl ?: "", // Transmit streamUrl to all connected devices!
            source = track?.source ?: "Spotify",
            isPlaying = isPlaying,
            positionMs = positionMs,
            durationMs = durationMs,
            timestamp = System.currentTimeMillis(),
            volume = volume,
            senderName = if (_isHost.value) "Host" else "Client",
            roomCode = _roomCode.value
        )
        try {
            nearbyManager.broadcastSyncPacket(packet)
        } catch (e: Throwable) {
            Log.w(TAG, "Failed broadcastSyncPacket: ${e.message}")
        }
        scope.launch {
            _incomingStateEvents.emit(packet)
        }
    }

    fun broadcastVolumeState(volume: Float) {
        if (!_isSyncActive.value) return
        val packet = SyncPacket(
            type = "VOLUME",
            trackId = "VOLUME_SYNC",
            isPlaying = true,
            positionMs = 0L,
            durationMs = 180000L,
            timestamp = System.currentTimeMillis(),
            volume = volume.coerceIn(0f, 1f),
            senderName = if (_isHost.value) "Host" else "Client",
            roomCode = _roomCode.value
        )
        try {
            nearbyManager.broadcastSyncPacket(packet)
        } catch (e: Throwable) {
            Log.w(TAG, "Failed broadcastVolumeState: ${e.message}")
        }
        scope.launch {
            _incomingStateEvents.emit(packet)
        }
    }

    fun broadcastRoomState(message: String = "SYNC_PING") {
        if (!_isSyncActive.value) return
        val packet = SyncPacket(
            type = "STATE",
            trackId = message,
            isPlaying = true,
            positionMs = System.currentTimeMillis(),
            timestamp = System.currentTimeMillis(),
            volume = 1.0f,
            senderName = "Host",
            roomCode = _roomCode.value
        )
        try {
            nearbyManager.broadcastSyncPacket(packet)
        } catch (e: Throwable) {
            Log.w(TAG, "Failed broadcastSyncPacket: ${e.message}")
        }
        scope.launch {
            _incomingStateEvents.emit(packet)
        }
    }

    fun sendReaction(emoji: String) {
        val packet = SyncPacket(
            type = "REACTION",
            trackId = emoji,
            isPlaying = true,
            positionMs = 0L,
            timestamp = System.currentTimeMillis(),
            volume = 1f,
            senderName = "Connected Mobile",
            roomCode = _roomCode.value
        )
        try {
            nearbyManager.broadcastSyncPacket(packet)
        } catch (e: Throwable) {
            Log.w(TAG, "Failed broadcastSyncPacket reaction: ${e.message}")
        }
        scope.launch {
            _incomingStateEvents.emit(packet)
        }
    }

    fun stopAllConnections() {
        try {
            if (_isHost.value && _roomCode.value.isNotBlank()) {
                ActiveRoomRegistry.unregisterRoom(_roomCode.value)
            }
            nearbyManager.stopAll()
            serverJob?.cancel()
            clientJob?.cancel()
            peerSimulationJob?.cancel()
            try {
                serverSocket?.close()
                clientSocket?.close()
            } catch (_: Throwable) {}
            serverSocket = null
            clientSocket = null
            _connectedDevices.value = emptyList()
            _isHost.value = false
            releaseLocks()
        } catch (e: Throwable) {
            Log.w(TAG, "Error stopping all connections: ${e.message}")
        }
    }

    private suspend fun getLocalIpAddress(): String? = withContext(Dispatchers.IO) {
        try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val ipInt = wifiManager?.connectionInfo?.ipAddress ?: 0
            if (ipInt != 0) {
                return@withContext String.format(
                    "%d.%d.%d.%d",
                    ipInt and 0xff,
                    ipInt shr 8 and 0xff,
                    ipInt shr 16 and 0xff,
                    ipInt shr 24 and 0xff
                )
            }
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces != null && interfaces.hasMoreElements()) {
                val intf = interfaces.nextElement()
                val addrs = intf.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return@withContext addr.hostAddress
                    }
                }
            }
        } catch (_: Throwable) {}
        return@withContext null
    }
}
